/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * Autor: Alexandre J. C. <alexandre.correa@quod.com.br>
 *
 * Script que contem funções utilizadas pela criação do estorno de provisão
 */

define(["N/log", "N/ui/message"], function (log, message) {
    /**
     * function confirmBox - exibe popup para confirmação de criação do estorno
     * @returns boolean - confirmação (true) ou cancelamento (false)
     */
    const confirmBox = function () {
        try {
            return confirm('Esta transação já foi total ou parcialmente reembolsada. Se você criar outro reembolso, talvez tenha um reembolso excedente da venda. \n Clique em OK para continuar.');
        }
        catch (error) {
            log.error('confirmBox error', error);
            return false;
        }
    };

    /**
     * function showMsg(msg: string, title: string)
     * Exibe a mensagem por meio de ui/serverWidget
     * @param msg - string contendo a mensagem
     * @param title - string contendo o título
     */
    const showMsg = function (msg, title) {
        try {
            message.create({
                type: message.Type.INFORMATION,
                duration: 3000,
                message: msg,
                title: title
            }).show();
        }
        catch (error) {
            log.error('showMsg error', error);
            throw error;
        }
    };

    /**
     * function isPaid() - Verifica se a fatura já está paga
     * @returns boolean - pago (true) ou não pago (false)
     */
    const isPaid = function () {
        try {
            //@ts-ignore
            return document.forms['main_form'].elements['balreadyrefunded'].value == 'T';
        }
        catch (error) {
            log.error('isPaid error', error);
            throw error;
        }
    };

    return{
        confirmBox:confirmBox,
        showMsg:showMsg,
        isPaid:isPaid
    }
});
