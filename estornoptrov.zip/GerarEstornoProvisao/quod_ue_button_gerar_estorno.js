/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType UserEventScript
 * Autor: Alexandre J. C. <alexandre.correa@quod.com.br>
 *
 * Script responsável pelo botão de geração de estorno de provisão
 */
define(["N/log"], function (log) {
    function beforeLoad(context) {
        try {
            //Caso não tenha o campo provisão de receita 
            //ou seja falso não executa o código.
            if (!context.newRecord.getValue({ fieldId: 'custbody_quod_provisao_receita' }))
                return;
            //Referência do clientScript com função do botão
            context.form.clientScriptModulePath = './GerarEstornoProvisao/quod_create_estorno.js';
            //Adição do botão
            context.form.addButton({
                label: 'Gerar estorno de provisão',
                functionName: 'createEstornoAndPayInvoice',
                id: 'custpage_quod_cred_memo',
            });
        }
        //Tratamento de erro
        catch (error) {
            log.error('beforeLoad error', error);
            throw error;
        }
    }
    exports.beforeLoad = beforeLoad;
});
