/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public  
 * Autor: Alexandre J. C. <alexandre.correa@quod.com.br>
 *
 * Script que contem funções utilizadas pelo botão de geração de estorno de provisão
 */

define(["N/log", "N/record", "N/currentRecord", "N/search", "./quod_estorno_fn"], function (log, record, currentRecord, search, ueFn) {
    var alreadyRunning = false;
    /**
     * function createEstornoAndPayInvoice(transacao?:record | currentRecord)
     * Função para criação de estorno e aplicação de pagamento
     * @param transacao - objeto tipo record ou currentRecord
     */
    function createEstornoAndPayInvoice(transacao) {
        try {
            //Caso esteja pago ou caso o retorno da confirmBox seja cancelar
            //cancela a execução do processo.
            if (alreadyRunning) {
                alert("Geraçao de estorno em andamento, aguarde.");
                return;
            }
            if (ueFn.isPaid() || !ueFn.confirmBox()) return;

            alreadyRunning = true;
            //Instância de variáveis a serem utilizadas posteriormente
            var idRet = 0, lancamento;

            //Verificação do recebimento do parâmetro
            //Caso não tenha sido informado o parâmetro, 
            //é obtido o registro atual (currentRecord) 
            transacao = transacao ? transacao : currentRecord.get();

            //Exibe a mensagem de andamento do processo de geração de estorno
            ueFn.showMsg("Aguarde a geração do estorno.", "Geração de estorno");

            //Necessário atrasar a execução da busca para criação do estorno
            //devido conflito com o módulo ui/serverWiget ao mostrar a mensagem
            setTimeout(function () {
                var sublistId = "line";
                //Busca das transações para o estorno
                search.create({
                    type: "transaction",
                    filters: [
                        ["posting", "is", "T"],
                        "AND",
                        ["custbody_quod_provisao_receita", "is", "T"],
                        "AND",
                        ["formulanumeric: NVL({creditamount}, 0) + NVL({debitamount}, 0)", "notequalto", "0"],
                        "AND",
                        ["internalid", "anyof", "" + transacao.id]
                    ],
                    columns: [
                        "trandate",
                        "account",
                        "debitamount",
                        "creditamount",
                        "memomain",
                        "memo",
                        "memo",
                        "item",
                        { name: "internalid", join: "customerMain" },
                        { name: "isinactive", join: "item" },
                    ]
                }).run().each(function (resultado) {
                    //Caso o objeto de lançamento não tenha sido criado,
                    //é executado o record.create e setado os valores padrão
                    if (!lancamento) {
                        lancamento = record.create({
                            type: "customtransaction_quod_estornoprov",
                            isDynamic: true
                        })
                            .setValue({
                                fieldId: "subsidiary",
                                value: 2,
                            })
                            .setValue({
                                fieldId: "currency",
                                value: 1,
                            })
                            .setValue({
                                fieldId: "exchangerate",
                                value: 1.0,
                            })
                            .setValue({
                                fieldId: "trandate",
                                value: new Date(),
                            })
                            .setValue({
                                fieldId: "memo",
                                value: "ESTORNO DE " + resultado.getValue({ name: "memomain" }),
                            })
                            .setValue({
                                fieldId: "custbody_quod_journal_transacao",
                                value: transacao.id,
                            });
                    }
                    //Definição das linhas da sublista do estorno
                    lancamento.setCurrentSublistValue({
                        sublistId: sublistId,
                        fieldId: "account",
                        value: resultado.getValue("account"),
                    })
                        .setCurrentSublistValue({
                            sublistId: sublistId,
                            fieldId: "debit",
                            value: resultado.getValue("creditamount"),
                        })
                        .setCurrentSublistValue({
                            sublistId: sublistId,
                            fieldId: "credit",
                            value: resultado.getValue("debitamount"),
                        })
                        .setCurrentSublistValue({
                            sublistId: sublistId,
                            fieldId: "memo",
                            value: "ESTORNO DE " + resultado.getValue({ name: "memo", }),
                        })
                        .setCurrentSublistValue({
                            sublistId: sublistId,
                            fieldId: "entity",
                            value: resultado.getValue({
                                name: "internalid",
                                join: "customerMain",
                            }),
                        })
                        .setCurrentSublistValue({
                            sublistId: sublistId,
                            fieldId: "custcol_quod_prov_item",
                            value: !resultado.getValue({ name: "isinactive" }) ? +resultado.getValue({ name: "item" }) > 0 ? +resultado.getValue({ name: "item" }) : null : null,
                        })
                        .commitLine({
                            sublistId: sublistId,
                        });
                    return true;
                });
                //Salva o gistro de lançamento
                idRet = lancamento.save();
                //Caso tenha ocorrido erro, cancela o processo
                if (!(idRet > 0)) {
                    alert("Não foi possível salvar o estorno. Verifique as informações do sistema.");
                    log.error("Erro ao gerar estorno", idRet);
                    return;
                }
                log.error("Lançamento criado com ID: " + idRet, JSON.stringify(lancamento));
                //É informado ao usuário o sucesso da geração do estorno
                //e solicitado que aguarde a aplicação do pagamento
                alert("Estorno gerado com sucesso, aguarde a aplicação do crédito.");
                //Efetua a criação a aplicação do pagamento
                var trsnRec = transformRec(transacao, idRet);
                //Caso tenha ocorrido erro, cancela o processo
                if (!trsnRec) {
                    alert("Não foi possível salvar o pagamento. Verifique as informações do sistema.");
                    log.error("Erro ao gerar pagamento", transacao);
                    return;
                }
                trsnRec.save();
                //Informa a conclusão do processo
                alert("Pagamento aplicado com sucesso!");
                //Recarrega a página de fatura
                window.location.reload();
            }, 500);
        }
        //Tratamento de erro
        catch (error) {
            log.error("Erro ao gerar Lançamento", error);
            alert("Erro ao gerar Lançamento: " + error.message);
        }
    };
    /**
     * function createLancamento(transacao?:record | currentRecord)
     * Função para criação de estorno e aplicação de pagamento
     * @param transacao - objeto tipo record ou currentRecord
     */
    function createEstornoAndPayInvoiceSL(transacao) {
        try {
            //Instância de variáveis a serem utilizadas posteriormente
            var idRet = 0, lancamento, sublistId = "line";
            //Verificação do recebimento do parâmetro
            //Caso não tenha sido informado o parâmetro, 
            //é obtido o registro atual (currentRecord) 
            transacao = transacao ? transacao : currentRecord.get();

            //Busca das transações para o estorno
            search.create({
                type: "transaction",
                filters: [
                    ["posting", "is", "T"],
                    "AND",
                    ["custbody_quod_provisao_receita", "is", "T"],
                    "AND",
                    ["formulanumeric: NVL({creditamount}, 0) + NVL({debitamount}, 0)", "notequalto", "0"],
                    "AND",
                    ["internalid", "anyof", "" + transacao.id]
                ],
                columns: [
                    "trandate",
                    "account",
                    "debitamount",
                    "creditamount",
                    "memomain",
                    "memo",
                    "memo",
                    "item",
                    { name: "internalid", join: "customerMain" },
                    { name: "isinactive", join: "item" },
                ]
            }).run().each(function (resultado) {
                //Caso o objeto de lançamento não tenha sido criado,
                //é executado o record.create e setado os valores padrão
                if (!lancamento) {
                    lancamento = record.create({
                        type: "customtransaction_quod_estornoprov",
                        isDynamic: true
                    })
                        .setValue({
                            fieldId: "subsidiary",
                            value: 2,
                        })
                        .setValue({
                            fieldId: "currency",
                            value: 1,
                        })
                        .setValue({
                            fieldId: "exchangerate",
                            value: 1.0,
                        })
                        .setValue({
                            fieldId: "trandate",
                            value: new Date(),
                        })
                        .setValue({
                            fieldId: "memo",
                            value: "ESTORNO DE " + resultado.getValue({ name: "memomain" }),
                        })
                        .setValue({
                            fieldId: "custbody_quod_journal_transacao",
                            value: transacao.id,
                        });
                }
                //Definição das linhas da sublista do estorno
                lancamento.setCurrentSublistValue({
                    sublistId: sublistId,
                    fieldId: "account",
                    value: resultado.getValue("account"),
                })
                    .setCurrentSublistValue({
                        sublistId: sublistId,
                        fieldId: "debit",
                        value: resultado.getValue("creditamount"),
                    })
                    .setCurrentSublistValue({
                        sublistId: sublistId,
                        fieldId: "credit",
                        value: resultado.getValue("debitamount"),
                    })
                    .setCurrentSublistValue({
                        sublistId: sublistId,
                        fieldId: "memo",
                        value: "ESTORNO DE " + resultado.getValue({ name: "memo", }),
                    })
                    .setCurrentSublistValue({
                        sublistId: sublistId,
                        fieldId: "entity",
                        value: resultado.getValue({
                            name: "internalid",
                            join: "customerMain",
                        }),
                    })
                    .setCurrentSublistValue({
                        sublistId: sublistId,
                        fieldId: "custcol_quod_prov_item",
                        value: !resultado.getValue({ name: "isinactive" }) ? +resultado.getValue({ name: "item" }) > 0 ? +resultado.getValue({ name: "item" }) : null : null,
                    })
                    .commitLine({
                        sublistId: sublistId,
                    });
                return true;
            });
            //Salva o gistro de lançamento
            idRet = lancamento.save();
            //Caso tenha ocorrido erro, cancela o processo
            if (!(idRet > 0)) {
                log.error("Erro ao gerar estorno", idRet);
                return;
            }
            log.error("Lançamento criado com ID: " + idRet, JSON.stringify(lancamento));

            //Efetua a criação a aplicação do pagamento
            var trsnRec = transformRec(transacao, idRet);
            //Caso tenha ocorrido erro, cancela o processo
            if (!trsnRec) {
                log.error("Erro ao gerar pagamento", transacao);
                return;
            }
            trsnRec.save();
        }
        //Tratamento de erro
        catch (error) {
            log.error("Erro ao gerar Lançamento", error);
        }
    };

    /**
     * function transformRec(transacao?:record | currentRecord, idLancamento: any)
     * Função para transformação e criação da aplicação de pagamento
     * @param transacao - objeto tipo record ou currentRecord
     * @param idLancamento - Id do registro de estorno de provisão
     */
    const transformRec = function (transacao, idLancamento) {
        try {
            //Efetua a transformação da fatura em pagamento
            var rec = record.transform({
                fromId: currentRecord.get().id,
                fromType: currentRecord.get().type,
                toType: record.Type.CUSTOMER_PAYMENT,
                isDynamic: true
            }),
                //Variáveis a serem utilizadas posteriormente
                pagamentoSubLine, estornoSubLine;
            //Obtem o número da linha onde a fatura esta presente
            pagamentoSubLine = rec.findSublistLineWithValue({ fieldId: "refnum", sublistId: "apply", value: Number(search.lookupFields({ id: transacao.id, type: transacao.type, columns: "tranid" }).tranid) });
            //Obtem o número da linha onde o estorno esta presente
            estornoSubLine = rec.findSublistLineWithValue({ fieldId: "internalid", sublistId: "credit", value: idLancamento });
            log.debug("pagamentoSubLine", pagamentoSubLine);
            log.debug("estornoSubLine", estornoSubLine);
            //Aplica a linha selecionada na sublista onde está a fatura
            rec.selectLine({ line: pagamentoSubLine, sublistId: "apply" })
                .setCurrentSublistValue({ fieldId: "apply", sublistId: "apply", value: true })
                .commitLine({ sublistId: "apply" });
            //Aplica a linha selecionada onde está presente o estorno
            rec.selectLine({ line: estornoSubLine, sublistId: "credit" })
                .setCurrentSublistValue({ fieldId: "apply", sublistId: "credit", value: true })
                .commitLine({ sublistId: "credit" });
            //Retorna o obj record para ser salvo e aplicar o estorno à fatura
            return rec;
        }
        catch (e) {
            log.error("Erro getRec", e);
            throw e;
        }
    };
    return {
        createEstornoAndPayInvoice: createEstornoAndPayInvoice,
        createEstornoAndPayInvoiceSL: createEstornoAndPayInvoiceSL
    }
});
