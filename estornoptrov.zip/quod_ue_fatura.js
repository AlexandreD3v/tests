/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType UserEventScript
 */

define(["./GerarEstornoProvisao/quod_ue_button_gerar_estorno.js", "N/log"], function (estornoBtn, log) {
    function beforeLoad(context) {
        try {
            estornoBtn.beforeLoad(context)
        } catch (error) {
            log.error("Erro UE Fatura", error)
        }
    }
    return {
        beforeLoad: beforeLoad
    }
});