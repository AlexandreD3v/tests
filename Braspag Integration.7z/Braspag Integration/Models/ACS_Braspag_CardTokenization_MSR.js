/**
 * ACS_Braspag_CardTokenization_MSR.js
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @author felipema90
 */
/**
* @class ACS_Braspag_CardTokenization_MSR
* @returns {ACS_Braspag_CardTokenization_MSR} models
*/
define ([
    'N/ui/serverWidget',
    'N/ui/message',
    'N/file',
    'N/runtime',
    '../Api/ACS_Braspag_API',
    './ACS_Braspag_Integration_MSR',
    './ACS_Braspag_Integration_CTS',
    'N/redirect'
],
function (ui, message, file, runtime, braspag_api, msr, cts, redirect)
{
function handleGetForm(context){

var invoiceId       = context.request.parameters['invoice'];
var formTitle       = invoiceId > 0 ? "Pagamento via Braspag" : "Pré-Autorização Braspag";
var form = ui.createForm({
    title : formTitle
});

var opportunityId   = context.request.parameters['opportunity'];
var contractId      = context.request.parameters['contract'];
var paymentway      = context.request.parameters['paymentway'];
var subsidiary      = context.request.parameters['subsidiary'];

if( (!invoiceId && !opportunityId && !contractId ) || !paymentway || !subsidiary ){
    form.addPageInitMessage({type: message.Type.ERROR, message: cts.ERROR.CARDJS_WITHOUT_MANDATORY_ENTITIES });
}else{
    //invoice field
    var invIdFld = form.addField(cts.CARD_FORM.FIELDS.INVOICE).updateDisplayType({
        displayType : ui.FieldDisplayType.HIDDEN
    });
    if( !!invoiceId ) invIdFld.defaultValue = invoiceId;
    //opportunity field
    var oppIdFld = form.addField(cts.CARD_FORM.FIELDS.OPPORTUNITY).updateDisplayType({
        displayType : ui.FieldDisplayType.HIDDEN
    });
    if( !!opportunityId  ) oppIdFld.defaultValue = opportunityId;
    //contract field
    var contractIdFld = form.addField(cts.CARD_FORM.FIELDS.CONTRACT).updateDisplayType({
        displayType : ui.FieldDisplayType.HIDDEN
    });
    if( !!contractId  ) contractIdFld.defaultValue = contractId;
    //customer field
    var paymentwayFld = form.addField(cts.CARD_FORM.FIELDS.PAYMENTWAY).updateDisplayType({
        displayType : ui.FieldDisplayType.HIDDEN
    });
    if( !!paymentway ) paymentwayFld.defaultValue = paymentway;
    var subsidiaryFld = form.addField(cts.CARD_FORM.FIELDS.SUBSIDIARY).updateDisplayType({
        displayType : ui.FieldDisplayType.HIDDEN
    });
    if( !!subsidiary) subsidiaryFld.defaultValue = subsidiary;
    /*
    *       CARD JS
    * */
    var cardJsField = form.addField(cts.CARD_FORM.FIELDS.CARDJS);
    var filePathRoot = runtime.accountId == 1883377? "SuiteScripts/" : "SuiteBundles/Bundle 286026/";
    var cardJsHtml = file.load({
        id: filePathRoot+'Braspag Integration/View/CardJs/acs_card-form.html'
    });
    var cardJsHtml =cardJsHtml.getContents();
    if( invoiceId > 0 ) cardJsHtml = cardJsHtml.replace('<button  id="read-btn-1">Enviar</button>', '<button  id="read-btn-1">Pagar</button>')
    cardJsField.defaultValue = cardJsHtml;
}
return form;
}
function handlePost(context){
// var paymentData = getBraspagPaymentData(  context.request.parameters['custpage_acs_braspag_invoice_ds'] )
//
// var apiResponse = braspag_api.newPayment(paymentData);
//
// return apiResponse;

var invoiceId       = context.request.parameters[ cts.CARD_FORM.FIELDS.INVOICE.id ];
var opportunityId   = context.request.parameters[ cts.CARD_FORM.FIELDS.OPPORTUNITY.id ];
var contractChangeId      = context.request.parameters[ cts.CARD_FORM.FIELDS.CONTRACT.id ];
var paymentWay   = context.request.parameters[ cts.CARD_FORM.FIELDS.PAYMENTWAY.id ];
var subsidiary   = context.request.parameters[ cts.CARD_FORM.FIELDS.SUBSIDIARY.id ];
var cardNumber = context.request.parameters['my-custom-form-field__card-number'].split(' ').join('');
var name = context.request.parameters['my-custom-form-field__card-name'];
var expirationYear = context.request.parameters['my-custom-form-field__card-expiry-year'];
var expirationMonth = context.request.parameters['my-custom-form-field__card-expiry-month'];
var securityCode = context.request.parameters['my-custom-form-field__card-cvc'];
var brand = context.request.parameters['my-custom-form-field__brand'];

log.audit( "cardNumber", cardNumber )
log.audit( "name", name )
log.audit( "expirationYear", expirationYear )
log.audit( "expirationMonth", expirationMonth )

log.audit( "securityCode", securityCode )
log.audit( "brand", brand )


var newPayment = "";
if( invoiceId > 0 ){

}else{
    if( opportunityId > 0 ){
            expirationMonth = expirationMonth.length == 1? "0"+expirationMonth : expirationMonth;
            var expirationDate =  expirationMonth+"/20"+expirationYear;
            var provider = msr.getProvider(subsidiary, paymentWay);
            log.debug("provider", provider)
             if(typeof provider === "object"){
                 var paymentBody = msr.getBraspagPaymentData({
                    operationType: cts.PAYMENT_CONDITION_MAP[paymentWay],
                    transactionId: "o"+opportunityId,
                    customer: name,
                    amount: "10",
                    cardNumber: cardNumber,
                    name: name,
                    expirationDate: expirationDate,
                    securityCode: securityCode,
                    brand: brand,
                    saveCard: true,
                    provider:provider,
                    capture:false,
                    withCardToken:false
                 });
                 log.debug("paymentBody",paymentBody)
                 var requestTime = new Date();
                 var newPayment = braspag_api.newPayment(JSON.stringify(paymentBody));
                 newPayment.responseTime = new Date();
                 newPayment.requestTime = requestTime;
                 newPayment.opportunity = opportunityId;
                 newPayment.subsidiary = subsidiary;
                 newPayment.operationType = cts.PAYMENT_CONDITION_MAP[paymentWay];
                 msr.processNewPayment(newPayment, null);
             }
             redirect.toRecord({
                type : "opportunity",
                id : opportunityId
             });
    }else{
        if( contractChangeId > 0 ){
            expirationMonth = expirationMonth.length == 1? "0"+expirationMonth : expirationMonth;
            var expirationDate =  expirationMonth+"/20"+expirationYear;
            var provider = msr.getProvider(subsidiary, paymentWay);
             if(typeof provider === "object"){
                 var paymentBody = msr.getBraspagPaymentData({
                    operationType: cts.PAYMENT_CONDITION_MAP[paymentWay],
                    transactionId: "c"+contractChangeId,
                    customer: name,
                    amount: "10",
                    cardNumber: cardNumber,
                    name: name,
                    expirationDate: expirationDate,
                    securityCode: securityCode,
                    brand: brand,
                    saveCard: true,
                    provider:provider,
                    capture:false,
                    withCardToken:false
                 });
                 var requestTime = new Date();
                 var newPayment = braspag_api.newPayment(JSON.stringify(paymentBody));
                 newPayment.responseTime = new Date();
                 newPayment.requestTime = requestTime;
                 newPayment.contractChange = contractChangeId;
                 newPayment.subsidiary = subsidiary;
                 newPayment.operationType = cts.PAYMENT_CONDITION_MAP[paymentWay];
                 msr.processNewPayment(newPayment, null);
             }
             redirect.toRecord({
                type : cts.CONTRACT_CHANGE.RECORDTYPE,
                id : contractChangeId
            });
        }
    }
}

return JSON.stringify(newPayment)
}
return {
handleGetForm:handleGetForm,
handlePost:handlePost
};
});
