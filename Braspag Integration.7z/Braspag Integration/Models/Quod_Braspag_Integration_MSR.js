/**
 * Quod_Braspag_Integration_MSR.js
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @author felipema90
 * @author erickmunekata
 */
/**
* @class Quod_Braspag_Integration_MSR
* @returns {Quod_Braspag_Integration_MSR} models
*/
define([
    'N/config',
    'N/runtime',
    'N/search',
    '../Api/ACS_Braspag_API',
    './ACS_Braspag_Integration_CTS',
    'N/url',
    'N/record',
    '../Utils/oauthSS2',
    '../Utils/quod_oauthSS2',
    'N/error',
    'N/https',
    'N/format'
],
    function (config, runtime, search, braspag_api, cts, urlModule, record, oauthjs, quod_oauth, errorModule, https, format) {
        /**
         * 
         * @param {Number} subsidiary 
         * @param {Number} paymentWay 
         * @description No momento só existe dois tipos para retornar.
         *              não me parece necessário fazer essa busca para todas as faturas.
         *              Uma busca que trate o resultado seja uma opção melhor
         * @example {
            "affiliationCode": "0d30d903-d484-4fce-936a-22a54eca9d62",
            "affiliationKey": "THVUMKQXWUMQBIJVEGPZHUKWQQZXJBVOHRJKKCSN",
            "name": "Cielo30",
            "password": "",
            "username": "",
            "terminalId": "",
            "softDescription": "QUOD",
            "paymentBankAccount": "2522"
            }
         */
        function getProvider(subsidiary, paymentWay) {
            var providerSearch = search.create({
                // ACS Configuração Adquirente Braspag [customrecord_acs_braspag_acquirer_setup]
                type: cts.PROVIDER_SETUP_MAP.RECORDTYPE,
                filters:
                    [
                        [cts.PROVIDER_SETUP_MAP.SUBSIDIARY, "anyof", subsidiary],
                        "AND",
                        [cts.PROVIDER_SETUP_MAP.PAYMENTWAY, "anyof", paymentWay]
                    ],
                columns:
                    [
                        { name: cts.PROVIDER_SETUP_MAP.SOFTDESCRIPTION },
                        { name: cts.PROVIDER_SETUP_MAP.PAYMENTBANKACCOUNT },
                        { name: cts.PROVIDER_SETUP.AFFILIATION_KEY, join: cts.PROVIDER_SETUP_MAP.PROVIDER },
                        { name: cts.PROVIDER_SETUP.AFFILIATION_CODE, join: cts.PROVIDER_SETUP_MAP.PROVIDER },
                        { name: "name", join: cts.PROVIDER_SETUP_MAP.PROVIDER },
                        { name: cts.PROVIDER_SETUP.PASSWORD, join: cts.PROVIDER_SETUP_MAP.PROVIDER },
                        { name: cts.PROVIDER_SETUP.TERMINAL_ID, join: cts.PROVIDER_SETUP_MAP.PROVIDER },
                        { name: cts.PROVIDER_SETUP.USERNAME, join: cts.PROVIDER_SETUP_MAP.PROVIDER }
                    ]
            }),
            providersResult = providerSearch.run().getRange({ start: 0, end: 1 });
            
            if (providersResult.length > 0) {
                return {
                    affiliationCode: providersResult[0].getValue({ name: cts.PROVIDER_SETUP.AFFILIATION_CODE, join: cts.PROVIDER_SETUP_MAP.PROVIDER }),
                    affiliationKey: providersResult[0].getValue({ name: cts.PROVIDER_SETUP.AFFILIATION_KEY, join: cts.PROVIDER_SETUP_MAP.PROVIDER }),
                    name: providersResult[0].getValue({ name: "name", join: cts.PROVIDER_SETUP_MAP.PROVIDER }),
                    password: providersResult[0].getValue({ name: cts.PROVIDER_SETUP.PASSWORD, join: cts.PROVIDER_SETUP_MAP.PROVIDER }),
                    username: providersResult[0].getValue({ name: cts.PROVIDER_SETUP.USERNAME, join: cts.PROVIDER_SETUP_MAP.PROVIDER }),
                    terminalId: providersResult[0].getValue({ name: cts.PROVIDER_SETUP.TERMINAL_ID, join: cts.PROVIDER_SETUP_MAP.PROVIDER }),
                    softDescription: providersResult[0].getValue({ name: cts.PROVIDER_SETUP_MAP.SOFTDESCRIPTION }),
                    paymentBankAccount: providersResult[0].getValue({ name: cts.PROVIDER_SETUP_MAP.PAYMENTBANKACCOUNT })
                };
            } else return null;
        }
        /**
         * 
         * @param {Object} params 
         * 
         */
        function getBraspagPaymentData(params) {
            log.debug("getBraspagPaymentData params", params)
            var sale = new braspag_api.SalesObject(params.operationType, params.withCardToken, params.operationInstallments);
            sale.MerchantOrderId = params.transactionId;
            sale.Customer.Name = params.customer;
            sale.Payment.Provider = params.provider.name;
            sale.Payment.Type = params.operationType;
            log.debug('C  MSR', params.amount)
            sale.Payment.Amount = params.amount.replace(/\./g, '');
            log.debug('D MSR')
            if (params.operationType === "CreditCard" || params.operationType === "DebitCard") {
                // CAMPOS EXCLUSIVOS DE MÉTODO COM CARTÃO
                sale.Payment.Currency = "BRL";
                sale.Payment.Country = "BRA";
                sale.Payment.Installments = params.operationInstallments || 1;
                sale.Payment.Interest = "ByMerchant";
                sale.Payment.Capture = params.capture;
                sale.Payment.SoftDescriptor = params.provider.softDescription;
                if (params.withCardToken) {
                    sale.Payment[params.operationType].CardToken = params.cardToken;
                    sale.Payment[params.operationType].Brand = params.cardBrand;
                } else {
                    sale.Payment[params.operationType].CardNumber = params.cardNumber;
                    sale.Payment[params.operationType].Holder = params.name;
                    sale.Payment[params.operationType].ExpirationDate = params.expirationDate;
                    sale.Payment[params.operationType].SecurityCode = params.securityCode;
                    sale.Payment[params.operationType].Brand = params.brand;
                    sale.Payment[params.operationType].SaveCard = params.saveCard;
                }
                sale.Payment.Credentials.code = params.provider.affiliationCode;
                sale.Payment.Credentials.key = params.provider.affiliationKey;
                sale.Payment.Credentials.password = params.provider.password;
                sale.Payment.Credentials.username = params.provider.username;
                sale.Payment.Credentials.signature = params.provider.terminalId;
            } else {
                // CAMPOS REFERENTES AO BOLETO
                sale.Customer.Identity = params.identity;
                sale.Customer.IdentityType = params.identityType;
                sale.Customer.Address.Street = params.address.street;
                sale.Customer.Address.Number = params.address.number;
                sale.Customer.Address.Complement = params.address.complement;
                sale.Customer.Address.ZipCode = params.address.zipcode;
                sale.Customer.Address.City = params.address.city;
                sale.Customer.Address.State = params.address.state;
                sale.Customer.Address.Country = "BRA";
                sale.Customer.Address.District = params.address.district;
                sale.Payment.ExpirationDate = params.duedate;
            }

            return sale;
        }
        function formatCapuredDate(cDt) {
            log.audit("formatCapuredDate", cDt)
            var date = cDt.split(" ")[0].split('-').reverse().join('/');
            log.audit("formatCapuredDate", date)
            var cDate = format.format({ value: format.parse({ value: date, type: format.Type.DATE }), type: format.Type.DATE });
            log.audit("cDate", cDate);
            return cDate;
        }
        /**
         * @see {https://braspag.github.io/Pagador-API-REST/#lista-de-providers}
         * @param {*} newPayment 
         * @param {*} provider 
         */
        function processNewPayment(newPayment, provider) {
            createBraspagIntegrationLog(newPayment);
            log.debug('dm_37 ****************** newPayment', newPayment)
            var responseBody = JSON.parse(newPayment.response.body);
            if ((newPayment.response.code == 200) || (newPayment.response.code == 201)) {
                if (!!responseBody.Payment) {
                    if (newPayment.invoice > 0 && responseBody.Payment.hasOwnProperty("Status")) {
                        if (responseBody.Payment.Status == 2) {
                            var paymentDate = formatCapuredDate(responseBody.Payment.CapturedDate);
                            payInvoice(newPayment, paymentDate, provider.paymentBankAccount);
                            updateInvoice(responseBody, newPayment);
                        } else {
                            updateInvoice(responseBody, newPayment);
                        }
                    }
                    if (newPayment.contractChange > 0 && responseBody.Payment.hasOwnProperty(newPayment.operationType)) {
                        updateContractChange(newPayment.contractChange, responseBody.Payment[newPayment.operationType]);
                        var requestTime = new Date();
                        var newPaymentVoid = braspag_api.voidPayment(responseBody.Payment.PaymentId)
                        newPaymentVoid.responseTime = new Date();
                        newPaymentVoid.requestTime = requestTime;
                        newPaymentVoid.contractChange = newPayment.contractChange;
                        createBraspagIntegrationLog(newPaymentVoid);
                    }
                    if (newPayment.opportunity > 0 && responseBody.Payment.hasOwnProperty(newPayment.operationType)) {
                        updateOpportunity(newPayment.opportunity, responseBody.Payment[newPayment.operationType]);
                        var requestTime = new Date();
                        var newPaymentVoid = braspag_api.voidPayment(responseBody.Payment.PaymentId)
                        newPaymentVoid.responseTime = new Date();
                        newPaymentVoid.requestTime = requestTime;
                        newPaymentVoid.opportunity = newPayment.opportunity;
                        createBraspagIntegrationLog(newPaymentVoid);
                    }
                }
            }
            // dm_37 Início
            if (newPayment.response.code >= 400) {
                updateInvoice(responseBody, newPayment);
            }
            // dm_37 Fim
        }
        function payInvoice(newPayment, paymentDate, paymentAccount) {
            log.debug("payInvoice before snp installment search", newPayment)
            var snpInstallment = searchSnpInstallment(newPayment.invoice, newPayment.paymentId, newPayment.legado); // dm_37
            log.debug("payInvoice snpInstallment", snpInstallment)
            if (typeof snpInstallment === "object") {
                log.debug("payInvoice snpInstallmentis object")
                var hash = guid();
                log.debug("payInvoice guid", hash)
                createPaymentSnp(snpInstallment, paymentDate, hash);
                log.debug("payInvoice", "before createPaymentDefault");
                var paymentId = createPaymentDefault(snpInstallment, paymentDate, paymentAccount);
                log.debug("payInvoice paymentId", paymentId);
                makePaymentSnp(hash, paymentId);
                log.debug("payInvoice makePaymentSnp", "done");
            } else {
                //TODO o que fazer se nao tiver parcela o2
            }
        }
        function createPaymentSnp(snpInstallment, paymentDate, hash) {
            log.audit("createPaymentSnp snpInstallment", snpInstallment)
            var requestOptions = getPaymentO2ResletHeaders();
            log.debug('requestOptions', requestOptions)
            var discharge = https.post({
                url: requestOptions.full_url,
                body: JSON.stringify({
                    functionName: 'pagarParcela',
                    objParam:
                    {
                        'parcelaId': snpInstallment.parentId,
                        'valorPagamento': (snpInstallment.amount).toString(),
                        'dataQuitacao': paymentDate,
                        'valorMulta': '0.00',
                        'valorJuros': '0.00',
                        'valorDesconto': '0.00',
                        'chaveTransacao': hash,
                        'valorAdiantamento': '0.00'
                    }
                }),
                headers: requestOptions.headers
            });
            log.audit('snp billing call result "pagarParcela"', discharge);
            if (discharge.code == 401) //Http code 401 Unauthorized
                throw errorModule.create(cts.ERROR.CNAB_PASSWORD);
            else if (discharge.code < 200 || discharge.code >= 300)
                throw errorModule.create(cts.ERROR.CNAB_ERROR);
        }
        function createPaymentDefault(installment, trandate, paymentAccount) {
            try {
                var payment = record.transform({
                    fromType: record.Type.INVOICE,
                    fromId: installment.invoice,
                    toType: record.Type.CUSTOMER_PAYMENT
                });
                if (!!paymentAccount) payment.setValue({ fieldId: "account", value: paymentAccount });
                payment.setValue({ fieldId: "trandate", value: format.parse({ value: trandate, type: format.Type.DATE }) });
                payment.setValue({ fieldId: "department", value: installment.department });
                payment.setValue({ fieldId: "class", value: installment.class });
                payment.setValue({ fieldId: "location", value: installment.location });
                payment.setValue({ fieldId: 'custbody_sit_chave_parcela', value: guid }); //(SNP)
                var y = payment.findSublistLineWithValue({ sublistId: "apply", fieldId: 'internalid', value: installment.invoice });
                if (y < 0) {
                    throw errorModule.create({
                        name: 'Sublist not found',
                        message: 'Unable to find a sublist with payment transaction of id: ' + installment.invoice,
                        notifyOff: false
                    });
                }
                payment.setSublistValue({ sublistId: "apply", fieldId: "apply", line: y, value: true });
                payment.setSublistValue({ sublistId: "apply", fieldId: "amount", line: y, value: installment.amount });
                var paymentId = payment.save();
                log.audit("Default Payment Created", paymentId);
                return paymentId;
            } catch (e) {
                log.error("createPaymentDefault", e);
                throw e;
            }
        }
        function makePaymentSnp(hash, paymentId) {
            var requestOptions = getPaymentO2ResletHeaders();
            try {
                var discharge = https.post({
                    url: requestOptions.full_url,
                    body: JSON.stringify({
                        functionName: 'efetivarPagamento',
                        objParam:
                        {
                            'chave': hash,
                            'transacaoPagamentoId': paymentId
                        }
                    }),
                    headers: requestOptions.headers
                });
                log.audit('snp billing call result "efetivarPagamento"', discharge);

                if (discharge.code == 401) //Http code 401 Unauthorized
                    throw errorModule.create(cts.ERROR.CNAB_PASSWORD);
                else if (discharge.code < 200 || discharge.code >= 300)
                    throw errorModule.create(cts.ERROR.CNAB_ERROR);
            } catch (e) {
                log.error("makePaymentSnp", e);
                throw e;
            }
        }
        function createBraspagIntegrationLog(data) {
            log.debug("createBraspagIntegrationLog data", data)
            var logRec = record.create({ type: cts.INTEGRATION_LOG.RECORDTYPE });
            logRec.setValue({ fieldId: cts.INTEGRATION_LOG.ENDPOINT, value: data.request.url });
            logRec.setValue({ fieldId: cts.INTEGRATION_LOG.REQUESTDT, value: data.requestTime });
            logRec.setValue({ fieldId: cts.INTEGRATION_LOG.RESPONSEDT, value: data.responseTime });
            logRec.setValue({ fieldId: cts.INTEGRATION_LOG.HEADERREQUEST, value: JSON.stringify(data.request.headers) });
            logRec.setValue({ fieldId: cts.INTEGRATION_LOG.HEADERRESPONSE, value: JSON.stringify(data.response.headers) });
            logRec.setValue({ fieldId: cts.INTEGRATION_LOG.BODYREQUEST, value: data.request.body });
            logRec.setValue({ fieldId: cts.INTEGRATION_LOG.BODYRESPONSE, value: data.response.body });
            logRec.setValue({ fieldId: cts.INTEGRATION_LOG.HTTPRESPONSECODE, value: data.response.code });

            if (data.opportunity > 0) logRec.setValue({ fieldId: cts.INTEGRATION_LOG.OPPORTUNITY, value: data.opportunity });
            if (data.invoice > 0) logRec.setValue({ fieldId: cts.INTEGRATION_LOG.INVOICE, value: data.invoice });
            if (data.installmentNumber) logRec.setValue({ fieldId: cts.INTEGRATION_LOG.INSTALLMENT, value: data.installmentNumber });
            if (data.installmentId) logRec.setValue({ fieldId: 'custrecord_quod_o2c_parcela_id', value: data.installmentId });
            if (data.contractChange > 0) logRec.setValue({ fieldId: cts.INTEGRATION_LOG.CONTRACT_CHANGE, value: data.contractChange });

            var logRecId = logRec.save();
            log.audit("Log created", logRecId);
        }

        function updateInvoice(responseBody, newPayment) {
            var invoiceid = newPayment.invoice
            var subsidiary = newPayment.subsidiary || 0
            var installmentId = newPayment.installmentId || 0
            log.debug("updateInvoice iniciado na fatura " + invoiceid, responseBody)
            log.debug("updateInstallment iniciado na parcela " + installmentId, responseBody)
            log.debug('dm_37 **************** updateInvoice - newPayment', newPayment)
            if (!responseBody || typeof responseBody !== 'object') {
                log.error("Não foram recebidos dados da resposta na fatura " + invoiceid);
                return;
            }

            var valuesInstall = {};
            var valuesInvoice = {};
            if (responseBody.length) {
                if (responseBody[0].hasOwnProperty("Code")) {
                    if (!newPayment.legado) {
                        log.debug('dm_37 ********* não legado 1')
                        valuesInstall[cts.SNP_INSTALLMENT_FIELDS.STATUSBRASPAG] =
                            responseBody[0].Code;
                        valuesInstall[cts.SNP_INSTALLMENT_FIELDS.STATUSBRASPAGDESC] =
                            responseBody[0].Message;
                    }
                    else {
                        log.debug('dm_37 ********* LEGADO 1')
                        valuesInvoice[cts.TRANSACTION_FIELDS.STATUSBRASPAG] =
                            responseBody[0].Code;
                        valuesInvoice[cts.TRANSACTION_FIELDS.STATUSBRASPAGDESC] =
                            responseBody[0].Message;
                    }
                }
            }
            if (responseBody.hasOwnProperty("Payment")) {
                if (responseBody.Payment.Type != "Boleto") valuesInvoice[cts.TRANSACTION_FIELDS.CARDTOKENUSED] = true;

                if (!newPayment.legado) {
                    log.debug('dm_37 ********* não legado 2')
                    if (responseBody.Payment.hasOwnProperty("Url")) valuesInstall[cts.SNP_INSTALLMENT_FIELDS.BOLETOPDF] = responseBody.Payment.Url;

                    valuesInstall[cts.SNP_INSTALLMENT_FIELDS.STATUSBRASPAG] = cts.BRASPAG_STATUS_MAP[responseBody.Payment.Status].name;
                    valuesInstall[cts.SNP_INSTALLMENT_FIELDS.STATUSBRASPAGDESC] = cts.BRASPAG_STATUS_MAP[responseBody.Payment.Status].description;
                    valuesInstall[cts.SNP_INSTALLMENT_FIELDS.PAYMENTIDBRASPAG] = responseBody.Payment.PaymentId;
                    valuesInvoice[cts.TRANSACTION_FIELDS.PROVIDERMESSAGE] = !!responseBody // custbody_acs_braspag_providermsg_ds
                        .Payment.ProviderReturnMessage
                        ? responseBody.Payment.ProviderReturnMessage
                        : "";

                    valuesInstall[cts.SNP_INSTALLMENT_FIELDS.REASONMESSAGE] =
                        cts.BRASPAG_REASON_MAP[responseBody.Payment.ReasonCode].message;
                    valuesInvoice[
                        cts.TRANSACTION_FIELDS.CODIGO_RETORNADO_PELO_MEIO_DE_PAGAMENTO // custbody_quod_cod_ret_meio_pag
                    ] = !!responseBody.Payment.ProviderReturnCode
                            ? responseBody.Payment.ProviderReturnCode
                            : "";

                    valuesInvoice[
                        cts.TRANSACTION_FIELDS.MENSAGEM_RETORNADA_PELO_MEIO_DE_PAGAMENTO // custbody_quod_msg_ret_meio_pag
                    ] = !!responseBody.Payment.ProviderReturnMessage
                            ? responseBody.Payment.ProviderReturnMessage
                            : "";
                    valuesInvoice[
                        cts.TRANSACTION_FIELDS.NSU  // custbody_quod_nsu
                    ] = !!responseBody.Payment.AuthorizationCode
                            ? responseBody.Payment.AuthorizationCode
                            : "";
                } else {
                    log.debug('dm_37 ********* LEGADO 2')
                    if (responseBody.Payment.hasOwnProperty("Url")) valuesInvoice[cts.TRANSACTION_FIELDS.BOLETOPDF] = responseBody.Payment.Url;

                    valuesInvoice[cts.TRANSACTION_FIELDS.STATUSBRASPAG] = cts.BRASPAG_STATUS_MAP[responseBody.Payment.Status].name;
                    valuesInvoice[cts.TRANSACTION_FIELDS.STATUSBRASPAGDESC] = cts.BRASPAG_STATUS_MAP[responseBody.Payment.Status].description;
                    valuesInvoice[cts.TRANSACTION_FIELDS.PAYMENTIDBRASPAG] = responseBody.Payment.PaymentId;
                    valuesInvoice[cts.TRANSACTION_FIELDS.PROVIDERMESSAGE] = !!responseBody
                        .Payment.ProviderReturnMessage
                        ? responseBody.Payment.ProviderReturnMessage
                        : "";

                    valuesInvoice[cts.TRANSACTION_FIELDS.REASONMESSAGE] =
                        cts.BRASPAG_REASON_MAP[responseBody.Payment.ReasonCode].message;
                    valuesInvoice[
                        cts.TRANSACTION_FIELDS.CODIGO_RETORNADO_PELO_MEIO_DE_PAGAMENTO
                    ] = !!responseBody.Payment.ProviderReturnCode
                            ? responseBody.Payment.ProviderReturnCode
                            : "";

                    valuesInvoice[
                        cts.TRANSACTION_FIELDS.MENSAGEM_RETORNADA_PELO_MEIO_DE_PAGAMENTO
                    ] = !!responseBody.Payment.ProviderReturnMessage
                            ? responseBody.Payment.ProviderReturnMessage
                            : "";
                    valuesInvoice[
                        cts.TRANSACTION_FIELDS.NSU
                    ] = !!responseBody.Payment.AuthorizationCode
                            ? responseBody.Payment.AuthorizationCode
                            : "";
                }

                if (subsidiary > 0) {
                    var lookup = search.lookupFields({
                        type: search.Type.SUBSIDIARY,
                        id: subsidiary,
                        columns: [
                            cts.SUBSIDIARY.DOCUMENT_MODEL,
                            cts.SUBSIDIARY.SEND_METHOD,
                        ],
                    });
                    valuesInvoice[cts.TRANSACTION_FIELDS.DOCUMENT_TEMPLATE] = lookup.custrecord_acs_eletronic_doc_model_ls[0].value;
                    valuesInvoice[cts.TRANSACTION_FIELDS.SEND_METHOD] = lookup.custrecord_acs_eletronic_send_method_ls[0].value;
                    valuesInvoice[cts.TRANSACTION_FIELDS.DOCUMENT_TYPE] = cts.TRANSACTION_FIELDS.NFSE;
                    valuesInvoice[cts.TRANSACTION_FIELDS.NFSE_STATUS] = cts.TRANSACTION_FIELDS.NFSE_STATUS_SENT;
                }
            }
            log.debug("Valores identificados na fatura " + invoiceid, valuesInvoice)
            log.debug("Valores identificados na parcela " + installmentId, valuesInstall)
            var updInvoiceId = record.submitFields({
                type: record.Type.INVOICE,
                id: invoiceid,
                values: valuesInvoice,
                options: {
                    enableSourcing: false,
                    ignoreMandatoryFields: true
                }
            });
            if (installmentId > 0)
                var updInstallmentId = record.submitFields({
                    type: 'customrecord_sit_parcela',
                    id: installmentId,
                    values: valuesInstall,
                    options: {
                        enableSourcing: false,
                        ignoreMandatoryFields: true
                    }
                });
            log.audit('updated invoice', updInvoiceId);
            log.audit('updated install', updInstallmentId);
            atualizarContrato(invoiceid)
        }

        function atualizarContrato(invoiceid) {
            try {
                var dadosFatura = getDadosFatura({
                    invoiceId: invoiceid
                });

                log.debug("dadosFatura", dadosFatura);
                var cValues = {};

                if (Boolean(dadosFatura.periodicidade)) {
                    var _dataCarenciaFaturamento = getCarenciaFaturamento(dadosFatura.periodicidade);
                    cValues['custrecord_quod_carencia_fat_datafim'] = _dataCarenciaFaturamento;
                    log.debug("Contrato " + dadosFatura.contratoId + " teve a data da fim da carência atualizada")
                }

                cValues['custrecord_quod_checklist_migracao_ok'] = true;

                record.submitFields({
                    type: 'customrecord_acs_quodcontract',
                    id: dadosFatura.contratoId,
                    values: cValues
                });

            } catch (error) {
                log.error("Contrato " + dadosFatura.contratoId + " gerou um erro ao tentar atualizar a data da fim da carência", error);
                throw error
            }
        }

        /**
         * 
         * @param {Object} opcoes
         * @param {String | Number} opcoes.invoiceId
         */
        function getDadosFatura(opcoes) {
            var _periodicidadeColumn = "custbody_acs_opportunity_paym_cond_ls.custrecord_quod_num_parcel_credit_card";
            var _contratoColumn = "custbody_acs_opportunity_contract_ls";
            var _fieldLookup = search.lookupFields({
                type: "invoice",
                id: opcoes.invoiceId,
                columns: [_periodicidadeColumn, _contratoColumn]
            });
            return {
                contratoId: _fieldLookup[_contratoColumn][0].value,
                periodicidade: _fieldLookup[_periodicidadeColumn]
            }
        }

        function getCarenciaFaturamento(periodicidade) {
            var _dataCarenciaFaturamento = new Date();
            var _prazoAdicional = 4;
            log.debug("_dataCarenciaFaturamento", _dataCarenciaFaturamento);
            for (var i = 0; i < periodicidade; i++) {
                _dataCarenciaFaturamento.setMonth(_dataCarenciaFaturamento.getMonth() + 1);
                log.debug("_dataCarenciaFaturamento após +1 mês", _dataCarenciaFaturamento);
            }

            _dataCarenciaFaturamento.setDate(_dataCarenciaFaturamento.getDate() - _prazoAdicional);
            log.debug("_dataCarenciaFaturamento após dias", _dataCarenciaFaturamento);
            return _dataCarenciaFaturamento
        }

        function updateContractChange(id, cardObj) {
            var values = {};
            values[cts.CONTRACT_CHANGE.CARD_TOKEN] = cardObj.CardToken;
            values[cts.CONTRACT_CHANGE.CARD_BRAND] = cardObj.Brand;
            var ccId = record.submitFields({
                type: cts.CONTRACT_CHANGE.RECORDTYPE,
                id: id,
                values: values,
                options: {
                    enableSourcing: true,
                    ignoreMandatoryFields: true
                }
            });
            log.audit('updated contract change', ccId);
        }
        function updateOpportunity(id, cardObj) {
            var values = {};
            values[cts.TRANSACTION_FIELDS.CARDTOKEN] = cardObj.CardToken;
            values[cts.TRANSACTION_FIELDS.CARDBRAND] = cardObj.Brand;
            var oppId = record.submitFields({
                type: "opportunity",
                id: id,
                values: values,
                options: {
                    enableSourcing: true,
                    ignoreMandatoryFields: true
                }
            });
            log.audit('updated opportunity', oppId);
        }
        function searchSnpInstallment(invoiceId, paymentId, legado) { // dm_37
            try {
                log.debug('searchSnpInstallment paymentId', paymentId)
                var columns = [];
                columns.push(search.createColumn({ name: cts.SNP_INSTALLMENT_FIELDS.AMOUNT }));
                columns.push(search.createColumn({ name: cts.SNP_INSTALLMENT_FIELDS.INVOICE }));
                var transCols = ["entity", "department", "class", "location"];
                transCols.map(function (c) {
                    columns.push(search.createColumn({ name: c, join: cts.SNP_INSTALLMENT_FIELDS.INVOICE }))
                });
                var filters = []
                filters.push(search.createFilter({ name: cts.SNP_INSTALLMENT_FIELDS.INVOICE, operator: search.Operator.ANYOF, values: invoiceId }))
                if (!legado)
                    filters.push(search.createFilter({ name: 'custrecord_o2c_braspag_paymentid', operator: search.Operator.IS, values: paymentId })) // dm_37
                var resultSet = search.create({
                    type: cts.SNP_INSTALLMENT_FIELDS.RECORDTYPE,
                    columns: columns,
                    filters: filters
                }).run().getRange({ start: 0, end: 1 });
                if (resultSet.length > 0) {
                    return {
                        parentId: resultSet[0].id,
                        amount: resultSet[0].getValue({ name: cts.SNP_INSTALLMENT_FIELDS.AMOUNT }),
                        invoice: resultSet[0].getValue({ name: cts.SNP_INSTALLMENT_FIELDS.INVOICE }),
                        entity: resultSet[0].getValue({ name: "entity", join: cts.SNP_INSTALLMENT_FIELDS.INVOICE }),
                        department: resultSet[0].getValue({ name: "department", join: cts.SNP_INSTALLMENT_FIELDS.INVOICE }),
                        class: resultSet[0].getValue({ name: "class", join: cts.SNP_INSTALLMENT_FIELDS.INVOICE }),
                        location: resultSet[0].getValue({ name: "location", join: cts.SNP_INSTALLMENT_FIELDS.INVOICE }),
                    };
                } else return null;
            } catch (e) {
                log.error('searchSnpInstallment', e);
            }
        }
        function getPaymentO2RestletURL() {
            try {
                url = urlModule.resolveScript(cts.SNP_PAYMENT_RESTLET_NEW);
            } catch (e) {
                url = urlModule.resolveScript(cts.SNP_PAYMENT_RESTLET_OLD);
            }
            return url;
        }
        var accountId, genPref, tokenId, tokenSecret, domain, url, full_url;
        function getPaymentO2ResletHeaders() {

            accountId = !!accountId ? accountId : runtime.accountId;
            genPref = !!genPref ? genPref : config.load({ type: config.Type.COMPANY_PREFERENCES });
            tokenId = !!tokenId ? tokenId : genPref.getValue({ fieldId: cts.GENERAL_PREFERENCES.CNAB_TOKEN });
            tokenSecret = !!tokenSecret ? tokenSecret : genPref.getValue({ fieldId: cts.GENERAL_PREFERENCES.CNAB_SECRET });
            domain = !!domain ? domain : 'https://' + accountId.toLowerCase().replace('_', '-') + '.restlets.api.netsuite.com';
            var oauth = quod_oauth.getKey(tokenId, tokenSecret, accountId);
            var authObj = new oauthjs.OAuth({
                realm: oauth.realm,
                consumer: {
                    key: oauth.consumer.public,
                    secret: oauth.consumer.secret
                },
                signature_method: 'HMAC-SHA256',
                hash_function: oauthjs.OAuth.hash_function_sha256
            });
            url = !!url ? url : getPaymentO2RestletURL();
            full_url = !!full_url ? full_url : domain + url;
            var headers = authObj.getHeaders({
                url: full_url,
                method: "POST",
                tokenKey: oauth.token.public,
                tokenSecret: oauth.token.secret
            });
            headers['User-Agent-x'] = 'SuiteScript-Call';
            headers['Content-Type'] = 'application/json';
            return {
                headers: headers,
                full_url: full_url,
            };
        }
        function guid() {
            function s4() {
                return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
            }
            return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
        }
        function getInvoiceInstallments(id) {
            try {
                var filters = [];
                filters.push(search.createFilter({ name: cts.INSTALLMENT.TRANSACTION, operator: search.Operator.ANYOF, values: id }));

                var columns = [];
                columns.push(search.createColumn({ name: cts.INSTALLMENT.STATUS }));

                var installmentSearch = search.create({ type: cts.INSTALLMENT.RECORDTYPE, filters: filters, columns: columns });
                var resultSet = installmentSearch.run().getRange({ start: 0, end: 50 });
                return resultSet;
            } catch (e) {
                log.error('getInvoiceNotOpenedInstallments', e);
                throw e;
            }
        }
        function updateInstallments(installments) {
            try {
                for (i in installments) {
                    var iValues = {};
                    iValues[cts.INSTALLMENT.STATUS] = cts.INSTALLMENT_STATUS.DONOTSEND;
                    record.submitFields({ type: cts.INSTALLMENT.RECORDTYPE, id: installments[i].id, values: iValues });
                }
            } catch (e) {
                log.error('updateInstallments', e);
                throw e;
            }
        }
        function checkOpenReopenInstallments(installments) {
            var haveOpenReopen = false;
            for (i in installments)
                if (installments[i].getValue(cts.INSTALLMENT.STATUS) == cts.INSTALLMENT_STATUS.OPEN ||
                    installments[i].getValue(cts.INSTALLMENT.STATUS) == cts.INSTALLMENT_STATUS.REOPENED)
                    haveOpenReopen = true;

            return haveOpenReopen;
        }
        function checkAndFormatAddress(parameters) {
            var street = removeAccents(parameters.street);
            var complement = removeAccents(parameters.complement);
            var district = removeAccents(parameters.district);

            var addressString = street + parameters.number + complement + district;
            var length = addressString.length;
            var formattedStreet;
            if (addressString.length > 60) {
                var cutLength = length - 60;
                var streetLength = street.length;
                formattedStreet = addressString.substring(0, streetLength - cutLength);
            }
            else
                formattedStreet = street;

            return {
                street: formattedStreet.toUpperCase(),
                number: parameters.number,
                complement: complement.toUpperCase(),
                district: district.toUpperCase()
            };
        }
        function checkAndFormatName(name) {
            var length = name.length;
            var formattedName;
            if (length > 60) {
                var cutLength = length - 60;
                formattedName = name.substring(0, length - cutLength);
            }
            else
                formattedName = name;

            return removeAccents(formattedName).toUpperCase();
        }
        function removeAccents(string) {
            var r = string;

            // Retira todos os acentos e caracteres especiais diferentes de hífen e apóstrofo
            r = r.toLowerCase()
            r = r.replace(new RegExp(/[àáâãäå]/g), "a");
            r = r.replace(new RegExp(/æ/g), "ae");
            r = r.replace(new RegExp(/ç/g), "c");
            r = r.replace(new RegExp(/[èéêë]/g), "e");
            r = r.replace(new RegExp(/[ìíîï]/g), "i");
            r = r.replace(new RegExp(/ñ/g), "n");
            r = r.replace(new RegExp(/[òóôõö]/g), "o");
            r = r.replace(new RegExp(/œ/g), "oe");
            r = r.replace(new RegExp(/[ùúûü]/g), "u");
            r = r.replace(new RegExp(/[ýÿ]/g), "y");
            r = r.replace(new RegExp(/&#{0,1}[a-z0-9]+;/ig), "");
            r = r.replace(new RegExp(/[&\/\\#,+()$~%._¨=§ªº°¬¢£³²¹!@'":*?{}]/g), '');


            // Retira os espaços antes e depois de hífens que tiver na string
            r = r.replace(/\s{1,}-\s{1,}/g, '-');
            r = r.replace(/\s{1,}-/g, '-');
            r = r.replace(/-\s{1,}/g, '-');

            // Retira os espaços antes e depois de apóstrofos que tiver na string
            r = r.replace(/\s{1,}’\s{1,}/g, "’");
            r = r.replace(/\s{1,}’/g, "’");
            r = r.replace(/’\s{1,}/g, "’");

            // Retira o excesso de espaço entre as palavras, deixando apenas um espaço
            r = r.replace(/\s{2,}/g, ' ');

            r = r.trim();

            return r;
        }
        return {
            getBraspagPaymentData: getBraspagPaymentData,
            getProvider: getProvider,
            processNewPayment: processNewPayment,
            getInvoiceInstallments: getInvoiceInstallments,
            updateInstallments: updateInstallments,
            checkOpenReopenInstallments: checkOpenReopenInstallments,
            checkAndFormatAddress: checkAndFormatAddress,
            checkAndFormatName: checkAndFormatName,
            removeAccents: removeAccents,
            createBraspagIntegrationLog: createBraspagIntegrationLog
        };
    }
);
