/**
 * ACS_Braspag_Integration_CTS.js
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

define ([],
/**
* @class ACS_Braspag_Integration_CTS
* @returns {ACS_Braspag_Integration_CTS} constants
*/
function ()
{
    return {
        ERROR : {
            CARDJS_WITHOUT_MANDATORY_ENTITIES : "Formulário não pode ser carregado porque referências obrigatórias não foram recebidas.",
            PROVIDER_NOT_FOUND                : "Não foi encontrado configuração de adquirente para a subsidiária e forma de pagamento da transação de id: ",
            CNAB_PASSWORD : {
                name: 'INVALID_PAYMENT_O2_RESTLET_CREDENTIALS',
                message: 'Incorrect Payment Oxygen Credentials, is Access Token enabled and set-up ?',
                notifyOff: true
            },
            CNAB_ERROR : {
                name: 'INVALID_PAYMENT_O2_RESTLET_AUTHENTICATION',
                message: 'Oxygen Installment Payment Restlet Authentication error.',
                notifyOff: true
            },
            TOKEN_NOT_CONFIGURED: 'Access Token para RESTlet de pagamento da Oxygen não está configurado, por favor, contate um administrador do sistema.',
            BRASPAG_BILLET_WRONG_ROLE : {
                name: 'NO_PERMISSION_BRASPAG_BILLET',
                message: "No permission to edit invoice's Braspag Billet field. Check if your role allows to change this field in your subsidiary."
            },
            INSTALLMENTS_WITH_STATUS_DIFFERENT_FROM_OPEN : {
                name: 'NO_PERMISSION_TO_EDIT_INVOICE',
                message: 'Cannot edit invoices with at least one installment with status different from Open if it is using CNAB Billet.'
            }
        },
        CARD_FORM : {
            FIELDS : {
                CARDJS      : { id:"custpage_acs_braspag_html_ds", type:"inlinehtml", label: "Card JS"},
                OPPORTUNITY : { id:"custpage_acs_braspag_opp_ds", type:"text", label: "Opp ID"},
                PAYMENTWAY    : { id:"custpage_acs_braspag_paymentway_ds",type:"text",  label: "PaymentWay ID"},
                INVOICE     : { id:"custpage_acs_braspag_invoice_ds", type:"text", label: "Invoice ID"},
                CONTRACT    : { id:"custpage_acs_braspag_contract_ds", type:"text", label: "Contract ID"},
                CARDTYPE    : { id:"custpage_acs_braspag_cardtype_ds", type:"text", label: "Card type"},
                SUBSIDIARY    : { id:"custpage_acs_braspag_subsidiary_ds", type:"text", label: "Card type"}
            }
        },
        GENERAL_PREFERENCES : {
             CNAB_TOKEN  :'custscript_acs_cnabtokenid_ds',
             CNAB_SECRET :'custscript_acs_cnabtokensecret_ds'
        },
        TRANSACTION_FIELDS  : {
            CONTRACT        :    'custbody_acs_opportunity_contract_ls',
            CARDTOKEN       :    "custbody_acs_braspag_cardtoken_ds",
            CARDTOKENUSED   :    "custbody_acs_braspag_cardtokenused_fl",
            STATUSBRASPAG   :    "custbody_acs_braspag_status_ds",
            STATUSBRASPAGDESC:   "custbody_acs_braspag_statusdesc_ds",
            PAYMENTIDBRASPAG:    "custbody_acs_braspag_paymentid_ds",
            PROVIDERMESSAGE :    "custbody_acs_braspag_providermsg_ds",
            REASONMESSAGE   :    "custbody_acs_braspag_paymentmsg_ds",
            CARDBRAND       :    "custbody_acs_braspag_cardbrand_ds",
            DOCUMENT_TEMPLATE  :'custbody_psg_ei_template',
            SEND_METHOD       : 'custbody_psg_ei_sending_method',
            NFSE_STATUS       : 'custbody_sit_transaction_t_status',
            NFSE_STATUS_SENT  : '1',
            DOCUMENT_TYPE     : 'custpage_o2s_transaction_l_tip_doc_fis',
            ACS_PAYMENT_METHOD: 'custbody_acs_opportunity_paym_cond_ls',
            NFSE              : '2',
            USEBRASPAGBILLET  : 'custbody_acs_braspagbillet_fl',
            BOLETOPDF         : 'custbody_acs_braspagbilleturl_lk',
            STATUS            : 'status',
            MENSAGEM_RETORNADA_PELO_MEIO_DE_PAGAMENTO : 'custbody_quod_msg_ret_meio_pag',
            CODIGO_RETORNADO_PELO_MEIO_DE_PAGAMENTO : 'custbody_quod_cod_ret_meio_pag',
            NSU : 'custbody_quod_nsu'
        },
        SUBSIDIARY :{
            RECORDTYPE     :'subsidiary',
            DOCUMENT_MODEL :'custrecord_acs_eletronic_doc_model_ls',
            SEND_METHOD    :'custrecord_acs_eletronic_send_method_ls',
            BRASPAG_BILLET_ROLE : 'custrecord_acs_rolebraspagbillet_ls'
        },
        SNP_INSTALLMENT_FIELDS : {
          RECORDTYPE: 'customrecord_sit_parcela',
          INVOICE   :'custrecord_sit_parcela_l_transacao',
          AMOUNT    :'custrecord_sit_parcela_n_valor',
          STATUSBRASPAG: 'custrecord_o2c_braspag_status',
          STATUSBRASPAGDESC: 'custrecord_o2c_braspag_statusdes',
          BOLETOPDF: 'custrecord_o2c_braspagbilleturl_lk',
          PAYMENTIDBRASPAG: 'custrecord_o2c_braspag_paymentid',
          REASONMESSAGE: 'custrecord_o2c_braspag_paymentmsg'
        },
        CARDJS_SUITELET_IDS : {
            scriptId: 'customscript_acs_bp_cardtokenization_st',
            deploymentId: 'customdeploy_acs_bp_cardtokenization_st',
            returnExternalUrl: false
        },
        SNP_PAYMENT_RESTLET_NEW : {
            scriptId: 'customscript_o2s_lib_parc_restlet',
            deploymentId: 'customdeploy_o2s_lib_parc_restlet',
            returnExternalUrl: false
        },
        SNP_PAYMENT_RESTLET_OLD : {
            scriptId: 'customscript_sit_lib_parc_restlet',
            deploymentId: 'customdeploy_sit_lib_parc_restlet',
            returnExternalUrl: false
        },
        BRASPAG_STATUS_MAP  : {
            "0": {name:"NotFinished",       description: "Falha ao processar o pagamento"},
            "1": {name:"Authorized",        description: "Meio de pagamento apto a ser capturado ou pago(Boleto)"},
            "2": {name:"PaymentConfirmed",  description: "Pagamento confirmado e finalizado"},
            "3": {name:"Denied", description:"Pagamento negado"},
            "10": {name:"Voided",            description: "Pagamento cancelado"},
            "11": {name:"Refunded",          description: "Pagamento Cancelado/Estornado"},
            "12": {name:"Pending",           description: "Esperando retorno da instituição financeira"},
            "13": {name:"Aborted",           description: "Pagamento cancelado por falha no processamento"},
            "20": {name:"Scheduled",         description: "Recorrência agendada"} //nao utilizado
        },
        BRASPAG_REASON_MAP  : {
             "0" : { message: "Successful"},
             "1" : { message: "AffiliationNotFound"},
             "2" : { message: "IssuficientFunds"},
             "3" : { message: "CouldNotGetCreditCard"},
             "4" : { message: "ConnectionWithAcquirerFailed"},
             "5" : { message: "InvalidTransactionType"},
             "6" : { message: "InvalidPaymentPlan"},
             "7" : { message: "Denied"},
             "8" : { message: "Scheduled"},
             "9" : { message: "Waiting"},
             "10": { message: "Authenticated"},
             "11": { message: "NotAuthenticated"},
             "12": { message: "ProblemsWithCreditCard"},
             "13": { message: "CardCanceled"},
             "14": { message: "BlockedCreditCard"},
             "15": { message: "CardExpired"},
             "16": { message: "AbortedByFraud"},
             "17": { message: "CouldNotAntifraud"},
             "18": { message: "TryAgain"},
             "19": { message: "InvalidAmount"},
             "20": { message: "ProblemsWithIssuer"},
             "21": { message: "InvalidCardNumber"},
             "22": { message: "TimeOut"},
             "23": { message: "CartaoProtegidoIsNotEnabled"},
             "24": { message: "PaymentMethodIsNotEnabled"},
             "98": { message: "InvalidRequest"},
             "99": { message: "InternalError"}
        },
        PAYMENT_CONDITION   : {
            RECORDTYPE       : 'customrecord_sit_cod_pagto',
            METHOD           : 'custrecord_o2s_cod_pagto_l_forma_pagto',
            CASH             : "1",
            CHECK            : "2",
            CREDIT_CARD      : "3",
            DEBIT_CARD       : "4",
            LOJA_CREDIT      : "5",
            ALIMENTACAO      : "6",
            REFEICAO         : "7",
            GIFT_CARD        : "8",
            COMBUSTIVEL      : "9",
            DUP_MERCANTIL    : "10",
            BANKING_BILLET   : "11",
            SEM_PAGAMENTO    : "12",
            OTHERS           : "13",
        },
        PAYMENT_CONDITION_MAP   : {
            "3": "CreditCard",
            "4": "DebitCard",
            "11":"Boleto"
        },
        CONTRACT_CHANGE  :{
            RECORDTYPE     : 'customrecord_acs_contract_change',
            TYPE           : 'custrecord_acs_contrchange_type_ls',
            PAYMENT_METHOD : 'custrecord_acs_contrchange_paymentmet_ls',
            CARD_TOKEN     : 'custrecord_acs_contrchange_cardtoken_ds',
            CARD_BRAND     : 'custrecord_acs_contrchange_cardbrand_ds',
            TYPE_RENEW     : '1',
            TYPE_READJUST  : '2',
            TYPE_TERM      : '3',
            TYPE_SUSP      : '4',
            TYPE_RETURN    : '5',
            TYPE_ITEM      : '6',
            TYPE_PAYMENTWAY: '7'
        },
        INTEGRATION_LOG     : {
            RECORDTYPE      :   "customrecord_acs_braspag_integration_log",
            ENDPOINT        :   "custrecord_acs_bil_endpoint_ds",
            REQUESTDT       :   "custrecord_acs_bil_request_dt",
            HEADERREQUEST   :   "custrecord_acs_bil_headerrequest_ds",
            BODYREQUEST     :   "custrecord_acs_bil_bodyrequest_ds",
            RESPONSEDT      :   "custrecord_acs_bil_response_dt",
            HTTPRESPONSECODE:   "custrecord_acs_bil_httpresponsecode_ds",
            HEADERRESPONSE  :   "custrecord_acs_bil_headerresponse_ds",
            BODYRESPONSE    :   "custrecord_acs_bil_bodyresponse_ds",
            OPPORTUNITY     :   "custrecord_acs_bil_opportunity_ls",
            INVOICE         :   "custrecord_acs_bil_invoice_ls",
            CONTRACT_CHANGE :   "custrecord_acs_bil_contractchange_ls",
            INSTALLMENT     :   "custrecord_quod_o2c_parcela_log"
        },
        PROVIDER_SETUP_MAP  : {
            RECORDTYPE          :   "customrecord_acs_braspag_acquirer_setup",
            PROVIDER            :   "custrecord_acs_bas_acquirer_ls",
            PAYMENTWAY          :   "custrecord_acs_bas_paymentway_ls",
            SUBSIDIARY          :   "custrecord_acs_bas_subsidiary_ls",
            SOFTDESCRIPTION     :   "custrecord_acs_bas_softdescription_ds",
            PAYMENTBANKACCOUNT  :   "custrecord_acs_bas_paymentbankaccount_ls"
        },
        PROVIDER_SETUP      : {
            AFFILIATION_CODE: "custrecord_acs_acq_affiliationcode_ds",
            AFFILIATION_KEY: "custrecord_acs_acq_affiliationkey_ds",
            USERNAME: "custrecord_acs_acq_username_ds",
            PASSWORD: "custrecord_acs_acq_password_ds",
            TERMINAL_ID: "custrecord_acs_acq_terminalid_ds"
        },
        INSTALLMENT         : {
            RECORDTYPE          : "customrecord_acs_installment",
            STATUS              : "custrecord_acs_cnabstatus_ls",
            TRANSACTION         : "custrecord_acs_transaction_ls"
        },
        INSTALLMENT_STATUS  : {
            OPEN                : 5,
            REOPENED            : 3,
            DONOTSEND           : 16
        },
        MAINTENANCE_BILLET_ST   : {
            FORM_TITLE: "Manutenção de Boletos",
            SUBMIT_BUTTON: {label: 'Pesquisar'},
            FORM_GROUP: {
                TRANSACTION: {id : 'transactiongroup', label : 'Transação'},
                DATE: {id: 'dategroup', label: 'Data'},
                CONTRACT: {id: 'contractgroup', label: 'Contrato'}
            },
            CLIENT_PATH: '../Controllers/ACS_Braspag_MaintenanceBillet_CL.js',
            FORM_BUTTONS:{
                CLEARFILTERS: { id: 'custpage_clearfilters_btn', label: 'Nova Busca', functionName: 'clearFilters' },
                SELECTALL: {id: 'custpage_addall_btn', label: 'Selecionar Tudo', functionName: 'selectAllLines'},
                UNSELECTALL: {id: 'custpage_unselectall_btn', label: 'Desmarcar Tudo', functionName: 'unselectAllLines'},
                CHANGEBILLET: {id: 'custpage_change_btn', label: 'Mudar para boleto Braspag', functionName: 'changeBillet'},
                SENDBILLET: {id: 'custpage_send_btn', label: 'Enviar boleto(s) Braspag', functionName: 'sendBillet'}
            },
            FORM_FIELDS: {
                TRANSACTION:                {id: 'custpage_acs_braspagtran_ls', type: 'text', source: 'invoice', label: 'Transação', container: 'transactiongroup'},
                ENTITY:                     {id: 'custpage_acs_braspagentity_ms', type: 'select', source: 'customer', label: 'Clientes', container: 'transactiongroup'},
                CNPJ:                       {id: 'custpage_acs_braspagcnpj_ds', type: 'text', label: 'CNPJ do Cliente', container: 'transactiongroup'},
                DATE_CREATE_INI:            {id: 'custpage_acs_braspagtrandateini_dt', type: 'date', label: 'Data da Transação Início', container: 'dategroup'},
                DATE_CREATE_END:            {id: 'custpage_acs_braspagtrandateend_dt', type: 'date', label: 'Data da Transação Fim', container: 'dategroup'},
                INSTALLMENT_DUEDATE_INI:    {id: 'custpage_acs_braspaginstduedateini_dt', type: 'date', label: 'Data de Vencimento Parcela Início', container: 'dategroup'},
                INSTALLMENT_DUEDATE_END:    {id: 'custpage_acs_braspaginstduedateend_dt', type: 'date', label: 'Data de Vencimento Parcela Fim', container: 'dategroup'},
                PAYMENT_CONDITION:          {id: 'custpage_acs_braspagpaycond_ls', type: 'select', source: 'customrecord_sit_cod_pagto', label: 'Condição de Pagamento', container: 'dategroup'},
                CONTRACT:                   {id: 'custpage_acs_braspagcontract_ls', type: 'select', source: 'customrecord_acs_quodcontract', label: 'Contrato', container: 'contractgroup'},
                BILLING_CYCLE:              {id: 'custpage_acs_braspagbillcycle_ls', type: 'multiselect', source: 'customrecord_acs_invoice_cycle', label: 'Ciclo de Faturamento', container: 'contractgroup'}
            },
            MAP_FILTER_FIELDS: {
                'custpage_acs_braspagtran_ls':              { id:'tranid', operator: 'anyof' },
                'custpage_acs_braspagentity_ms':            { id: 'entity', operator: 'anyof' },
                'custpage_acs_braspagcnpj_ds':              { id: 'custentity_psg_br_cnpj', join: 'customermain', operator: 'is' },
                'custpage_acs_braspagtrandateini_dt':       { id: 'trandate', operator: 'onorafter' },
                'custpage_acs_braspagtrandateend_dt':       { id: 'trandate', operator: 'onorbefore' },
                'custpage_acs_braspaginstduedateini_dt':    { id: 'custrecord_acs_duedateinstallment_dt', join: 'custrecord_acs_transaction_ls', operator: 'onorafter' }, // ceva
                'custpage_acs_braspaginstduedateend_dt':    { id: 'custrecord_acs_duedateinstallment_dt', join: 'custrecord_acs_transaction_ls', operator: 'onorbefore' }, //ceva
                'custpage_acs_braspagpaycond_ls':           { id: 'custbody_acs_opportunity_paym_cond_ls', operator: 'anyof' },
                'custpage_acs_braspagcontract_ls':          { id: 'custbody_acs_opportunity_contract_ls', operator: 'anyof' },
                'custpage_acs_braspagbillcycle_ls':         { id: 'custbody_acs_opportunity_cycle_ls', operator: 'anyof' }
            },
            MAP_FILTER_FIELDS_INST: {
                'custpage_acs_braspagtran_ls':              { id: 'tranid', join: 'custrecord_sit_parcela_l_transacao', operator: 'anyof' },
                'custpage_acs_braspagentity_ms':            { id: 'entity', join: 'custrecord_sit_parcela_l_transacao', operator: 'anyof' },
                'custpage_acs_braspagcnpj_ds':              { id: 'custentity_psg_br_cnpj', join: 'custrecord_sit_parcela_l_cliente', operator: 'is' },
                'custpage_acs_braspagtrandateini_dt':       { id: 'trandate', join: 'custrecord_sit_parcela_l_transacao', operator: 'onorafter' },
                'custpage_acs_braspagtrandateend_dt':       { id: 'trandate', join: 'custrecord_sit_parcela_l_transacao', operator: 'onorbefore' },
                'custpage_acs_braspaginstduedateini_dt':    { id: 'custrecord_sit_parcela_d_dt_vencimen', operator: 'onorafter' }, // ceva
                'custpage_acs_braspaginstduedateend_dt':    { id: 'custrecord_sit_parcela_d_dt_vencimen', operator: 'onorbefore' }, //ceva
                'custpage_acs_braspagpaycond_ls':           { id: 'custbody_acs_opportunity_paym_cond_ls', join: 'custrecord_sit_parcela_l_transacao', operator: 'anyof' },
                'custpage_acs_braspagcontract_ls':          { id: 'custbody_acs_opportunity_contract_ls', join: 'custrecord_sit_parcela_l_transacao', operator: 'anyof' },
                'custpage_acs_braspagbillcycle_ls':         { id: 'custbody_acs_opportunity_cycle_ls', join: 'custrecord_sit_parcela_l_transacao', operator: 'anyof' }
            },
            INVOICE_FILTERS: {
                NOT_BRASPAG_BILLET:     {name: 'custbody_acs_braspagbillet_fl', operator: 'is', values: false},
                INVOICE_STATUS:         {name: 'status', operator: 'anyof', values: ['CustInvc:A']},
                INSTALLMENT_STATUS:     {name: 'custrecord_acs_cnabstatus_ls', join: 'custrecord_acs_transaction_ls', operator: 'anyof', values:[5, 3]},
                MAINLINE:               {name: 'mainline', operator: 'is', values: true},
                PAYMENT_CONDITION:      {name: 'custrecord_o2s_cod_pagto_l_forma_pagto', join: 'custbody_acs_opportunity_paym_cond_ls', operator: 'anyof', values: 11}
            },
            INVOICE_RECORD: {
                ID:                         {name: 'internal'},
                RECORD_TYPE:                {name: 'invoice'}
            },
            INVOICE_COLUMNS: {
                ID:                         {name: 'internalid'},
                TRANID:                     {name: 'tranid'},
                ENTITY:                     {name: 'entity'},
                TRANDATE:                   {name: 'trandate'},
                AMOUNT:                     {name: 'amount'},
                CNPJ:                       {name: 'custentity_psg_br_cnpj', join: 'customermain'},
                OPPORTUNITY:                {name: 'custrecord_acs_quodcontr_opp_ls', join: 'custbody_acs_opportunity_contract_ls'},
                CONTRACT:                   {name: 'custbody_acs_opportunity_contract_ls'},
                NFSE:                       {name: 'custbody_o2s_transac_t_nr_nfse'},
                // NFE:                        {name: 'custbody_sit_transaction_t_nr_nfe'},
                RPS:                        {name: 'custbody_sit_transaction_t_nr_rps'},
                DUEDATE_INSTALLMENT:        {name: 'custrecord_acs_duedateinstallment_dt', join: 'custrecord_acs_transaction_ls'},
                // STATUS_NFSE:                {name: 'custbody_o2s_transaction_t_status_ret'},
                STATUS_NFSE:                {name: 'custbody_sit_transaction_t_status'},
                BILLING_CYCLE:              {name: 'custbody_acs_opportunity_cycle_ls'},
                PAYMENT_CONDITION:          {name: 'custbody_acs_opportunity_paym_cond_ls'}
            },
            INVOICE_SUBLIST: {
                METADATA: {id : 'custpage_braspagsub', type : 'list', label : 'Converter Boleto CNAB para Braspag'},
                FIELDS: {
                    braspagbillet:          {id: 'custpage_sub_braspagbill', type: 'checkbox', label: 'Selecionar'},
                    id:                     {id: 'custpage_sub_id', type: 'text', label: 'ID'},
                    transaction:            {id: 'custpage_sub_tranid', type: 'integer', label: 'Transação'},
                    transactionlink:        {id: 'custpage_sub_link', type: 'url', label: 'Visualizar'},
                    entity:                 {id: 'custpage_sub_entity', type: 'text', label: 'Cliente'},
                    trandate:               {id: 'custpage_sub_trandate', type: 'date', label: 'Data da transação'},
                    amount:                 {id: 'custpage_sub_amount', type: 'currency', label: 'Valor'},
                    cnpj:                   {id: 'custpage_sub_cnpj', type: 'text', label: 'CNPJ'},
                    opportunity:            {id: 'custpage_sub_opp', type: 'text', label: 'Oportunidade'},
                    contract:               {id: 'custpage_sub_contract', type: 'text', label: 'Contrato'},
                    nfse:                   {id: 'custpage_sub_nfse', type: 'text', label: 'NFSE'},
                    // nfe:                    {id: 'custpage_sub_nfe', type: 'text', label: 'NFE'},
                    rps:                    {id: 'custpage_sub_rps', type: 'integer', label: 'RPS'},
                    installmentduedate:     {id: 'custpage_sub_instduedate', type: 'date', label: 'Data de Vencimento da Parcela'},
                    statusnfe:              {id: 'custpage_sub_nfestatus', type: 'text', label: 'Status da NFSE'},
                    billingcycle:           {id: 'custpage_sub_billcycle', type: 'text', label: 'Ciclo de Faturamento'},
                    paymentcondition:       {id: 'custpage_sub_paycondition', type: 'text', label: 'Condição de Pagamento'},
                    // status:                 {id: 'custpage_sub_statusline', type: 'text', label: 'Status de Atualização'}
                },
                SETUP_DISPLAY:{
                    id: {
                        display:{ displayType: 'hidden' }
                    }
                },
                DOM: {
                    STATUS: { id: '#custpage_braspagsubrow' },
                    UPDATE_FLAG: { id: '#custpage_sub_braspagbill' }
                },
            },
            INSTALLMENT_FILTERS: {
                BRASPAG_BILLET:         {name: 'custbody_acs_braspagbillet_fl', join: 'custrecord_sit_parcela_l_transacao', operator: 'is', values: true},
                INVOICE_STATUS:         {name: 'status', join: 'custrecord_sit_parcela_l_transacao', operator: 'anyof', values: ['CustInvc:A']},
                INVOICE_TYPE:           {name: 'type', join: 'custrecord_sit_parcela_l_transacao', operator: 'anyof', values: 'CustInvc'},
                INSTALLMENT_STATUS:     {name: 'custrecord_sit_parcela_i_status', operator: 'notequalto', values: '3'},
                MAINLINE:               {name: 'mainline', join: 'custrecord_sit_parcela_l_transacao', operator: 'is', values: true},
                PAYMENT_CONDITION:      {name: 'custrecord_o2s_parcela_l_forma_pagamento', operator: 'anyof', values: '11'},
            },
            INSTALLMENT_COLUMNS: {
                ID:                         {name: 'internalid'},
                TRANID:                     {name: 'tranid', join: 'custrecord_sit_parcela_l_transacao'},
                TRANLINKID:                 {name: 'internalid', join: 'custrecord_sit_parcela_l_transacao'},
                INSTALLMENT:                {name: 'custrecord_sit_parcela_i_numero'},
                ENTITY:                     {name: 'custrecord_sit_parcela_l_cliente'},
                TRANDATE:                   {name: 'trandate', join: 'custrecord_sit_parcela_l_transacao'},
                AMOUNT:                     {name: 'custrecord_sit_parcela_n_valor'},
                PAID_AMOUNT:                {name: 'custrecord_sit_parcela_n_vl_pago'},
                CONTRACT:                   {name: 'custbody_acs_opportunity_contract_ls', join: 'custrecord_sit_parcela_l_transacao'},
                DUEDATE_INSTALLMENT:        {name: 'custrecord_sit_parcela_d_dt_vencimen'},
                STATUS_INSTALLMENT:         {name: 'custrecord_sit_parcela_i_status'},
                BRASPAG_LINK:               {name: 'custrecord_o2c_braspagbilleturl_lk'}, 
                BRASPAG_ID:                 {name: 'custrecord_o2c_braspag_paymentid'},
                BRASPAG_STATUS:             {name: 'custrecord_o2c_braspag_status'},
                BRASPAG_DESCRIPTION:        {name: 'custrecord_o2c_braspag_statusdes'},
                BRASPAG_MESSAGE:            {name: 'custrecord_o2c_braspag_paymentmsg'},
            },
            INSTALLMENT_SUBLIST: {
                METADATA: {id : 'custpage_brpinstallsub', type : 'list', label : 'Transmitir Boletos Braspag'},
                FIELDS: {
                    selecao:                {id: 'custpage_subi_select', type: 'checkbox', label: 'Selecionar'},
                    id:                     {id: 'custpage_subi_id', type: 'text', label: 'ID'},
                    transaction:            {id: 'custpage_subi_tranid', type: 'integer', label: 'Transação'},
                    transactionlink:        {id: 'custpage_subi_link', type: 'url', label: 'Visualizar'},
                    installment:            {id: 'custpage_subi_install', type: 'integer', label: 'Parcela'},
                    entity:                 {id: 'custpage_subi_entity', type: 'text', label: 'Cliente'},
                    trandate:               {id: 'custpage_subi_trandate', type: 'date', label: 'Data da transação'},
                    installmentAmount:      {id: 'custpage_subi_amount', type: 'currency', label: 'Valor da Parcela'},
                    installmentAmountPaid:  {id: 'custpage_subi_amountpaid', type: 'currency', label: 'Valor Pago da Parcela'},
                    contract:               {id: 'custpage_subi_contract', type: 'text', label: 'Contrato'},
                    installmentduedate:     {id: 'custpage_subi_instduedate', type: 'date', label: 'Data de Vencimento da Parcela'},
                    installmentstatus:      {id: 'custpage_subi_inststatus', type: 'text', label: 'Status da Parcela'},
                    braspaglink:            {id: 'custpage_subi_linkbo', type: 'text', label: 'Link Boleto Braspag Parcela'},
                    braspagid:              {id: 'custpage_subi_idpag', type: 'text', label: 'Id Pagamento Braspag Parcela'},
                    braspagstatus:          {id: 'custpage_subi_statusbras', type: 'text', label: 'Status Braspag Parcela'},
                    braspagdescription:     {id: 'custpage_subi_descstatus', type: 'text', label: 'Descrição Status Braspag'},
                    braspagmessage:         {id: 'custpage_subi_mensagbras', type: 'text', label: 'Mensagem Braspag'}
                },
                SETUP_DISPLAY:{
                    id: {
                        display:{ displayType: 'hidden' }
                    }
                },
                DOM: {
                    STATUS: { id: '#custpage_brpinstallsubrow' },
                    UPDATE_FLAG: { id: '#custpage_subi_select' },
                },
            },
            CONFIRM_SUBMIT: {
                title: 'Confirmar atualização para Boleto Braspag',
                message: 'Confirma que deseja mudar o tipo de boleto para Boleto Braspag nesta fatura?'
            },
            
            CONFIRM_SUBMIT_ALL_INVOICES: {
                title: 'Confirmar atualização de faturas para Boleto Braspag'
            },
            CONFIRM_SUBMIT_ALL_INSTALLMENTS: {
                title: 'Confirmar envio de todos os Boletos Braspag'
            },
            ALERT_NO_INVOICES_TO_UPDATE: {
                title: 'Não há faturas para atualizar',
                message: 'Atualmente não existem faturas para serem atualizadas para Boleto Braspag'
            },
            ALERT_NO_INSTALLMENTS_TO_SEND: {
                title: 'Não há parcelas para enviar',
                message: 'Atualmente não existem parcelas para serem enviadas'
            },
            CLIENT_MESSAGES: {
                UPDATE_INVOICES: ' faturas para que usem boleto Braspag?',
                UPDATE_INSTALLMENT: ' parcelas para serem enviadas?',
                UPDATE_SINGLE_INVOICE: ' fatura para que use boleto Braspag?',
                UPDATE_SINGLE_INSTALLMENT: ' parcela para ser enviada?',
                UPDATE_INVOICES_CONFIRM: 'Deseja confirmar a atualização de ',
                UPDATE_INSTALLMENT_CONFIRM: 'Deseja confirmar ',
                INVOICE_PROCESSING: 'Atualizando...',
                INVOICE_CANCELLED: 'Cancelado',
                INVOICE_UPDATED: ['Fatura ID ', ' Atualizada']
            },
            VOID: ""
        }
    };
});
