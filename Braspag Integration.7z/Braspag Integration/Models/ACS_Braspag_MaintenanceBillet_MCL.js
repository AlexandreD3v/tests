/**
 * @NApiVersion 2.x
 * @NModuleScope
 * @author: Erick Munekata
 * Date: 29/11/2019
 * Version: 1.0
 */
define(['N/record', 'N/currentRecord', 'N/ui/dialog', './ACS_Braspag_Integration_CTS'],
    function (record, currentRecord, dialog, cts) {
        var invId, clcontext;

        function updateInvoice(id, context, btnClick) {
            clcontext = context;
            invId = id;
            if (!btnClick)
                dialog.confirm(cts.MAINTENANCE_BILLET_ST.CONFIRM_SUBMIT)
                    .then(submitUpdate)
                    .catch(function (e) {
                        // failedStatus(e, invId, clcontext.line); 
                        log.error("Falha na alteração.", e);
                    });
            else submitUpdate(true);
        }

        function submitUpdate(result) {
            var line = clcontext.line;
            if (result === true) {
                var iValues = {};
                iValues[cts.TRANSACTION_FIELDS.USEBRASPAGBILLET] = true;
                iValues['custbody_acs_quod_bankbillet_ls'] = '';

                // printUpdateMessage(line, cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.INVOICE_PROCESSING, null);
                record.submitFields.promise({ type: record.Type.INVOICE, id: invId, values: iValues })
                // .then( function(recordId){ successStatus(recordId, line); }, function(e){ failedStatus(e, invId, line) } );
            }
            // else{
            //     printUpdateMessage(line, cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.INVOICE_CANCELLED);
            //     var ct = currentRecord.get();
            //     ct.setCurrentSublistValue({sublistId: clcontext.sublistId, fieldId: clcontext.fieldId, value: false});
            // }
        }

        // function successStatus(recordId, line){
        //     printUpdateMessage(line, getUpdatedMessage(recordId));
        //     disableUpdateCheckbox(++line);
        // }

        // function failedStatus(e, recordId, line) {
        //     printUpdateMessage(line, e.message);
        // }

        // function printUpdateMessage(line, message) {
        //     document.querySelector(cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.DOM.STATUS.id + line)
        //         .childNodes[16]
        //         .innerHTML = message;
        // }

        // function getUpdatedMessage(id){
        //     return cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.INVOICE_UPDATED[0] + id + cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.INVOICE_UPDATED[1];
        // }

        // function disableUpdateCheckbox(line){
        //     document.querySelector(cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.DOM.UPDATE_FLAG.id + line).disabled = true;
        // }

        function atualizarLinhas(parcelas, currentct) {
            var ct = currentct.get()

            search.create({
                type: 'customrecord_sit_parcela',
                filters: [
                    ['internalid', 'anyof', parcelas],
                ],
                columns: [
                    'internalid',
                    'custrecord_o2c_braspagbilleturl_lk',
                    'custrecord_o2c_braspag_paymentid',
                    'custrecord_o2c_braspag_status',
                    'custrecord_o2c_braspag_statusdes',
                    'custrecord_o2c_braspag_paymentmsg',
                ]
            }).run().each(function (result) {
                var line = ct.findSublistLineWithValue({
                    sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id,
                    fieldId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS.id.id,
                    value: result.getValue({ name: 'internalid' })
                })

                document.querySelector(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.DOM.UPDATE_FLAG.id + line).disabled = true;

                document.querySelector(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.DOM.STATUS.id + line)
                    .childNodes[10]
                    .innerHTML = result.getValue({ name: 'custrecord_o2c_braspagbilleturl_lk' });

                document.querySelector(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.DOM.STATUS.id + line)
                    .childNodes[11]
                    .innerHTML = result.getValue({ name: 'custrecord_o2c_braspag_paymentid' });

                document.querySelector(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.DOM.STATUS.id + line)
                    .childNodes[12]
                    .innerHTML = result.getValue({ name: 'custrecord_o2c_braspag_status' });

                document.querySelector(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.DOM.STATUS.id + line)
                    .childNodes[13]
                    .innerHTML = result.getValue({ name: 'custrecord_o2c_braspag_statusdes' });

                document.querySelector(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.DOM.STATUS.id + line)
                    .childNodes[14]
                    .innerHTML = result.getValue({ name: 'custrecord_o2c_braspag_paymentmsg' });

                return true
            })
        }

        return {
            updateInvoice: updateInvoice,
            atualizarLinhas: atualizarLinhas
        };
    });