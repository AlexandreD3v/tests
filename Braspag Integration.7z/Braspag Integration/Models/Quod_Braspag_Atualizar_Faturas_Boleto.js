/**
 * @NApiVersion 2.x
 * @NModuleScope SameAccount
 * @author: Danilo Nascimento
 * @since: 14/09/2020
 * @version: 1.0
 */

define([
  "../Api/ACS_Braspag_API",
  "../Models/Quod_Braspag_Integration_MSR",
  "N/record"
], function (ACS_Braspag_API, msr, record) {
  /**
   *
   * @param {Object} invoice - Objeto Invoice criado a partir de uma busca salva
   * @param {String | Number} invoice.id - ID da Invoice
   * @param {String | Number} invoice.paymentId - ID do Payment gerado pela BrasPag
   * @param {String | Number} invoice.subsidiary - Subsidiária da Fatura
   * @param {String | Number} invoice.formaDePagamento - Forma de pagamento da fatura
   */
  function Quod_Braspag_Atualizar_Faturas_Boleto(invoice) {
    this.invoiceId = invoice.id;
    this.paymentId = invoice.paymentId;
    this.paymenStatus = invoice.paymenStatus;
    this.subsidiary = invoice.subsidiary;
    this.formaDePagamento = invoice.formaDePagamento;
    this.brasPagStatusComplete = 2;
    this.brasPagStatusOKResponses = [200,201]
    this.legado = invoice.legado // dm_37
  }

  Quod_Braspag_Atualizar_Faturas_Boleto.prototype.getBraspagPaymentStatus = function () {
    this.responseBraspag = ACS_Braspag_API.getPayment(this.paymentId);
    this.responseBraspag.invoice = this.invoiceId;
    log.debug("this.responseBraspag", this.responseBraspag)
    msr.createBraspagIntegrationLog( this.responseBraspag );
    //if( this.brasPagStatusOKResponses.indexOf(this.responseBraspag.response.code) == -1 ) return;
    this.body = JSON.parse( this.responseBraspag.response.body );
    if(this.body.Payment) {
        this.paymenStatus = this.body.Payment.Status
        this.responseBraspag.invoice = this.invoiceId;
        this.responseBraspag.paymentId = this.paymentId; // dm_37
        this.responseBraspag.legado = this.legado; // dm_37
    }
  };

  Quod_Braspag_Atualizar_Faturas_Boleto.prototype.createPaymentToInvoice = function () {
    // if(this.paymenStatus != this.brasPagStatusComplete) return;
    var provider = msr.getProvider(
      this.subsidiary,
      this.formaDePagamento
    );
    msr.processNewPayment(this.responseBraspag, provider);
  };

  /**
   * @todo Confirmar se há necessidade de zerar valores
   */
  Quod_Braspag_Atualizar_Faturas_Boleto.prototype.clearErrorsFields = function() {
    var _self = this;
    var values = {

    }
    record.submitFields({
        type: record.Type.INVOICE,
        id: _self.invoiceId,
        values: values,
        options: {
            enableSourcing: false,
            ignoreMandatoryFields : true
        }
    })
  }

  return Quod_Braspag_Atualizar_Faturas_Boleto;
});
