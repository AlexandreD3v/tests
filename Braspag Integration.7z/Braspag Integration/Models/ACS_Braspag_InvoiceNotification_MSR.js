/**
 * @NApiVersion 2.x
 * @NModuleScope
 * @author: Erick Munekata
 * Date: 12/12/2019
 * Version: 1.0
 */
define(['../Api/ACS_Braspag_API', '../Api/ACS_Braspag_CTS', 'N/search', 'N/url', 'N/https', 'N/record', './ACS_Braspag_Integration_CTS', 'N/runtime', 'N/config',
	'../Utils/Cnab_Utils',
	'../Utils/cryptojsSS2',
	'../Utils/oauthSS2',
	'../Utils/cnab_oauthSS2'],
    function (api, cts, search, urlModule, https, record, custom_cts, runtime, config, Cnab_Utils, CryptoJS, oauthjs, cnab_oauth) {
        function processNotification(body){
            try {
                body = (typeof body == 'string') ? JSON.parse(body) : body;
                var response = body.ChangeType === cts.CHANGE_TYPE.CHANGE_PAYMENT_STATUS.code ? api.getPayment(body.PaymentId).response : null;
                var responseBody = (typeof response.body == 'string') ? JSON.parse(response.body) : response.body;
                var transactionRecord;
                var createdPaymentId;
                var updatedTransactionId;
                transactionRecord = getTransactionByPaymentId(body.PaymentId);
                if (!!transactionRecord && !!transactionRecord.id) {
                    if (responseBody) {
                        // if (responseBody.Payment.Status == cts.TRANSACTION_STATUS.PAYMNENTCONFIRMED.code) {
                            createdPaymentId = transformIntoPayment(transactionRecord, responseBody);
                            if (!!createdPaymentId && createdPaymentId > 0) log.debug('SUCCESS', 'Payment Created with ID ' + createdPaymentId);
                        // } else {
                        //     if (!!responseBody.Payment.Status) {
                        //         updatedTransactionId = updateTransactionWithStatus(responseBody, transactionRecord);
                        //         if (!!updatedTransactionId && updatedTransactionId > 0) log.debug('SUCCESS', 'Transaction Updated with ID ' + updatedTransactionId);
                        //     }
                        // }
                    }
                }
            } catch (e) {
                log.error('ERROR on processNotification', JSON.stringify(e));
                throw e;
            }
        }
        function getTransactionByPaymentId(payId){
            var returnRecord;
            try {
                var filters = [
                    search.createFilter({
                        name: custom_cts.TRANSACTION_FIELDS.PAYMENTIDBRASPAG,
                        operator: search.Operator.IS,
                        values: payId
                    })
                ];
                var searchForTransaction = search.create({
                    type:'invoice',
                    filters:filters,
                    columns:['internalid']
                });
                var searchResults = searchForTransaction.run().getRange({start:0,end:1});
                if (!!searchResults ) {
                    if (searchResults.length > 0) {
                        var resultFound = searchResults[0];
                        returnRecord = record.load({type:'invoice',id:resultFound.id});
                    } else
                        throw "ERROR on Search for Transaction, Payment ID "+payId+" not found.";
                } else
                    throw "ERROR on Search for Transaction, Payment ID "+payId+" not found.";
            } catch (e) {
                log.error('ERROR on getTransactionByPaymentId', JSON.stringify(e));
                throw e;
            }
            return returnRecord;
        }
        function transformIntoPayment(transactionRecord, responseBody){
            var paymentRecordId = -1;
            var statusFound = {};
            try {
                for (var z in cts.TRANSACTION_STATUS) {
                    if (cts.TRANSACTION_STATUS[z].code == responseBody.Payment.Status )
                        statusFound = cts.TRANSACTION_STATUS[z];
                }
                if (!!transactionRecord) {
                    var locInstallObj 	 = getLocalizationInstallment(transactionRecord);
                    // PAGAR PARCELA O2s
                 	  var accountId 	= runtime.accountId;
                 	  var genPref 	     = config.load({ type: config.Type.COMPANY_PREFERENCES });
                 	  var tokenId 		= genPref.getValue({ fieldId: "custscript_acs_cnabtokenid_ds" });
                 	  var tokenSecret 	= genPref.getValue({ fieldId: "custscript_acs_cnabtokensecret_ds" });
                 	  // var domain 		= urlModule.resolveDomain({ hostType: urlModule.HostType.RESTLET });
                 	  var domain 		= 'https://'+accountId.toLowerCase().replace('_','-')+'.restlets.api.netsuite.com';
                 	  var oauth;
                 	  //ESTOU CHECANDO PARA VER SE O ARQUIVO COM A CHAVE CNAB EXISTE
                 	  if (typeof cnab_oauth.getKey == 'function') {
                 		  oauth = new cnab_oauth.getKey(tokenId, tokenSecret, accountId);
                 	  } else {
                 		  throw "Access Token CNAB não configurado, por favor, contate um administrador do sistema.";
                 	  }
                 	  var authObj = new oauthjs.OAuth({
                 		  realm: oauth.realm,
                 		  consumer: {
                 			  key: oauth.consumer.public,
                 			  secret: oauth.consumer.secret
                 		  },
                 		  signature_method: 'HMAC-SHA256',
                 		  hash_function: oauthjs.OAuth.hash_function_sha256
                 	  });
                 	  var url;
                 	  try {
                 		 url = urlModule.resolveScript({
                 			scriptId: 'customscript_o2s_lib_parc_restlet',
                 			deploymentId: 'customdeploy_o2s_lib_parc_restlet',
                 			returnExternalUrl: false
                 		 });
                 	  } catch (e) {
                 		 url = urlModule.resolveScript({
                 			scriptId: 'customscript_sit_lib_parc_restlet',
                 			deploymentId: 'customdeploy_sit_lib_parc_restlet',
                 			returnExternalUrl: false
                 		 });
                 	  }
                 	  var full_url = domain + url;
                 	  var method = "POST";
                 	  var guid = Cnab_Utils.guid();
                 	  var headers = authObj.getHeaders({
                 			 url: full_url,
                 			 method: method,
                 			 tokenKey: oauth.token.public,
                 			 tokenSecret: oauth.token.secret
                 		});
                 	  headers['User-Agent-x'] = 'SuiteScript-Call';
                 	  headers['Content-Type'] = 'application/json';
                 	  // Create parcela quitacao (SNP)
                 	  var obj = {};
                 	  obj.functionName = 'pagarParcela';
                    log.debug('locInstallObj.amount', locInstallObj.amount);
                    log.debug('locInstallObj.amount', (locInstallObj.amount).toString());
                    log.debug('locInstallObj.amount',  ((locInstallObj.amount).toString()).replace('.', ','));
                 	  obj.objParam = {
                 		 'parcelaId': locInstallObj.id,
                 		 'valorPagamento': (locInstallObj.amount).toString(),
                 		 'dataQuitacao': (locInstallObj.paydate).toString(),
                 		 'valorMulta':'0.00',
                 		 'valorJuros': '0.00',
                 		 'valorDesconto':'0.00',
                 		 'chaveTransacao': guid,
                 		 'valorAdiantamento': '0.00'
                 	  };
                 	  obj = JSON.stringify(obj);
                 	  var discharge = https.post({
                 		 url: full_url,
                 		 body: obj,
                 		 headers: headers
                 	  });
                 	  log.debug({title:'discharge',details:JSON.stringify(discharge)});
                 	  if (discharge.code == 401) { //Http code 401 Unauthorized
                 		 throw errorModule.create({
                 			name: 'CNAB password',
                 			message: 'Incorrect CNAB Credentials, is Access Token enabled and set-up ?',
                 			notifyOff: true
                 		 });
                 	  } else if (discharge.code < 200 || discharge.code >= 300) {
                 			  throw errorModule.create({
                 				  name: 'CNAB ERROR',
                 				  message: 'CNAB Installment Authentication ERROR.',
                 				  notifyOff: true
                 			  });
                 	  }
                 	  log.debug('snp payment call result "pagarParcela"', discharge);
                    // PAGAR PARCELA O2s
                    paymentRecord = record.transform({
                        fromType:'invoice',
                        fromId: transactionRecord.id,
                        toType: 'customerpayment'
                    });
                    var y = paymentRecord.findSublistLineWithValue({
                        sublistId: 'apply',
                        fieldId: 'internalid',
                        value: transactionRecord.id
                    });
                    if (y > 0) {
                        paymentRecord.setSublistValue({sublistId: "apply", fieldId: "apply", line: y, value: true});
                        paymentRecordId = paymentRecord.save();
                        // QUITAR PARCELA O2s
                	 		  log.debug('Payment ID: ', paymentRecordId);
                	 		  obj = {};
                	 		  obj.functionName = 'efetivarPagamento';
                	 		  obj.objParam = {
                	 			  'chave': guid,
                	 			  'transacaoPagamentoId': paymentRecordId
                	 		  };
                	 		  // log.debug('chamando snp "efetivarPagamento" informando', obj);
                	 		  headers = authObj.getHeaders({
                	 				 url: full_url,
                	 				 method: method,
                	 				 tokenKey: oauth.token.public,
                	 				 tokenSecret: oauth.token.secret
                	 			});
                	 		  headers['User-Agent-x'] = 'SuiteScript-Call';
                	 		  headers['Content-Type'] = 'application/json';
                	 		  obj = JSON.stringify(obj);
                	 		  discharge = https.post({
                	 			 url: full_url,
                	 			 body: obj,
                	 			 headers: headers
                	 		  });
                	 		  if (discharge.code == 401) { //Http code 401 Unauthorized
                	 			 throw errorModule.create({
                	 				name: 'CNAB password',
                	 				message: 'Incorrect CNAB Credentials, is Access Token enabled and set-up ?',
                	 				notifyOff: true
                	 			 });
                	 		  } else if (discharge.code < 200 || discharge.code >= 300) {
                	 				  throw errorModule.create({
                	 					  name: 'CNAB ERROR',
                	 					  message: 'CNAB Installment Authentication ERROR.',
                	 					  notifyOff: true
                	 				  });
                	 		  }
                	 		  log.debug('snp payment call result "efetivarPagamento"', discharge);
                        // QUITAR PARCELA O2s
                        if (!!paymentRecordId && paymentRecordId > 0) {
                            transactionRecord = record.load({type:'invoice', id:transactionRecord.id});
                            if (!!transactionRecord && !!statusFound) {
                                transactionRecord.setValue({fieldId:custom_cts.TRANSACTION_FIELDS.STATUSBRASPAGDESC,    value:statusFound.description});
                                transactionRecord.setValue({fieldId:custom_cts.TRANSACTION_FIELDS.STATUSBRASPAG,        value:statusFound.name});
                                updatedTransactionId = transactionRecord.save();
                            }
                        }
                    } else throw "Transaction with ID" + transactionRecord.id + " not available for payment.";
                }
            } catch (e) {
                log.error('ERROR on transformIntoPayment', JSON.stringify(e));
                throw e;
            }
            return paymentRecordId;
        }
        function getLocalizationInstallment(transactionRecord){
            try {
              var locinstall = {};
              var filters = [
                      search.createFilter({
                          name: 'custrecord_sit_parcela_l_transacao',
                          operator: search.Operator.IS,
                          values: transactionRecord.id
                      })
              ];
              var columns = [
                      search.createColumn({
                          name: 'custrecord_sit_parcela_n_valor'
                      }),
                      search.createColumn({
                          name: 'custrecord_sit_parcela_d_dt_vencimen'
                      })
              ];
              var searchForLocInstallment = search.create({
                  type:'customrecord_sit_parcela',
                  filters:filters,
                  columns:columns
              });
              var searchResults = searchForLocInstallment.run().getRange({start:0,end:1});
              if (!!searchResults ) {
                  if (searchResults.length > 0) {
                      var resultFound = searchResults[0];
                      locinstall.id = resultFound.id;
                      locinstall.amount = resultFound.getValue(searchResults[0].columns[0]);
                      locinstall.paydate = resultFound.getValue(searchResults[0].columns[1]);
                  } else
                      throw "ERROR on Search for Localization Installment for Transaction ID "+transactionRecord.id+" not found.";
              } else
                  throw "ERROR on Search for Localization Installment for Transaction ID "+transactionRecord.id+" not found.";

              return locinstall;
            } catch (e) {
                log.error('ERROR on getLocalizationInstallment', JSON.stringify(e));
                throw e;
            }
        }
        function updateTransactionWithStatus(response, transactionRecord){
            var updatedTransactionId = -1;
            var statusFound = {};
            try {
                for (var z in cts.TRANSACTION_STATUS) {
                    if (cts.TRANSACTION_STATUS[z].code == response.Payment.Status )
                        statusFound = cts.TRANSACTION_STATUS[z];
                }
                if (!!transactionRecord && !!statusFound) {
                    transactionRecord.setValue({fieldId:custom_cts.TRANSACTION_FIELDS.STATUSBRASPAGDESC,    value:statusFound.description});
                    transactionRecord.setValue({fieldId:custom_cts.TRANSACTION_FIELDS.STATUSBRASPAG,        value:statusFound.name});
                    updatedTransactionId = transactionRecord.save();
                } else  throw "ERROR finding BRASpag Status in CTS, or Transaction not loaded.";
            } catch (e) {
                log.error('ERROR on updateTransactionWithStatus', JSON.stringify(e));
                throw e;
            }
            return updatedTransactionId;
        }
        return {
            processNotification: processNotification
        };
    });
