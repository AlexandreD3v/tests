/**
 * @NApiVersion 2.x
 * @NModuleScope
 * @author: Erick Munekata
 * Date: 27/11/2019
 * Version: 1.0
 */
/**
 * @class ACS_Braspag_MaintenanceBillet_MSR
 * @returns {ACS_Braspag_MaintenanceBillet_MSR} models
 */
define(['N/ui/serverWidget', 'N/search', './ACS_Braspag_Integration_CTS', 'N/url'],
    function (ui, search, cts, url) {

        function handleGetForm(context) {
            return generateGETForm();
        }

        function handlePost(context) {

            var requestParameters = context.request.parameters;
            var parameters = {};

            // delete requestParameters.custpage_acs_searchinvoice
            // delete requestParameters.custpage_acs_searchinstall

            // PEGA DO REQUEST OS VALORES DE PARAMETROS ENVIADOS
            for (field in cts.MAINTENANCE_BILLET_ST.FORM_FIELDS) {
                if (!!requestParameters[cts.MAINTENANCE_BILLET_ST.FORM_FIELDS[field].id])
                    parameters[cts.MAINTENANCE_BILLET_ST.FORM_FIELDS[field].id] = requestParameters[cts.MAINTENANCE_BILLET_ST.FORM_FIELDS[field].id];
            }

            // if(context.request.parameters.custpage_acs_searchinvoice == 'T')
            var invoices = getInvoices(parameters);

            // if(context.request.parameters.custpage_acs_searchinstall == 'T')
            var installments = getInstallments(parameters);

            return generatePOSTForm(invoices, installments);
        }

        function generateGETForm() {
            try {
                var form = ui.createForm({
                    title: cts.MAINTENANCE_BILLET_ST.FORM_TITLE
                });
                
                for (group in cts.MAINTENANCE_BILLET_ST.FORM_GROUP) form.addFieldGroup(cts.MAINTENANCE_BILLET_ST.FORM_GROUP[group]);

                for (field in cts.MAINTENANCE_BILLET_ST.FORM_FIELDS) form.addField(cts.MAINTENANCE_BILLET_ST.FORM_FIELDS[field]);

                form.addSubmitButton(cts.MAINTENANCE_BILLET_ST.SUBMIT_BUTTON);
                return form;
            } catch (e) {
                log.error('generateGETForm', e);
                throw e;
            }
        }

        function generatePOSTForm(invoices, installments) {
            try {

                var form = ui.createForm({
                    title: cts.MAINTENANCE_BILLET_ST.FORM_TITLE
                });
                form.clientScriptModulePath = cts.MAINTENANCE_BILLET_ST.CLIENT_PATH;
                form.addButton(cts.MAINTENANCE_BILLET_ST.FORM_BUTTONS.CLEARFILTERS); // dm_37
                form.addButton(cts.MAINTENANCE_BILLET_ST.FORM_BUTTONS.SELECTALL);
                form.addButton(cts.MAINTENANCE_BILLET_ST.FORM_BUTTONS.UNSELECTALL); // dm_37
                form.addButton(cts.MAINTENANCE_BILLET_ST.FORM_BUTTONS.CHANGEBILLET);
                form.addButton(cts.MAINTENANCE_BILLET_ST.FORM_BUTTONS.SENDBILLET);

                if (installments) {
                    // ADICIONA OS CAMPOS DA SUBLISTA E JÁ APLICA SETUP DE DISPLAY TYPE EM CAMPOS PRE CONFIGURADOS NO CTS
                    var sublistinstall = form.addSublist(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA);
                    for (f in cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS) {
                        var fieldinstall = sublistinstall.addField(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS[f]);
                        if (cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.SETUP_DISPLAY.hasOwnProperty(f))
                            for (s in cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.SETUP_DISPLAY[f])
                                fieldinstall.updateDisplayType(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.SETUP_DISPLAY[f][s]);
                        if (f === 'transactionlink') {
                            fieldinstall.linkText = "Visualizar"
                        }
                    }
                    var line = 0;
                    var valueinstall = 0
                    var countinstall = 0
                    //USA O OBJETO DE RESULTADO DE BUSCA DE INSTALLMENTS PARA MAPEAR OS VALORES INSERIDOS NA SUBLISTA DE INSTALLMENTS
                    for (i in installments) {
                        for (r in cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS) {
                            if (r === 'transactionlink') {
                                var recordURL = url.resolveRecord({
                                    recordType: "invoice",
                                    recordId: installments[i]['transactionid'],
                                    isEditMode: false
                                })
                                sublistinstall.setSublistValue({ id: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS[r].id, line: line, value: recordURL })
                            } else {
                                !!installments[i][r]
                                    ? sublistinstall.setSublistValue({ id: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS[r].id, line: line, value: installments[i][r] })
                                    : cts.MAINTENANCE_BILLET_ST.VOID;
                            }
                        }
                        ++line;
                        ++countinstall
                        valueinstall += parseFloat(installments[i].installmentAmount)
                    }
                }

                if (invoices) {
                    // ADICIONA OS CAMPOS DA SUBLISTA E JÁ APLICA SETUP DE DISPLAY TYPE EM CAMPOS PRE CONFIGURADOS NO CTS

                    var sublist = form.addSublist(cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA);
                    for (f in cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS) {
                        var field = sublist.addField(cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS[f]);
                        if (cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.SETUP_DISPLAY.hasOwnProperty(f))
                            for (s in cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.SETUP_DISPLAY[f])
                                field.updateDisplayType(cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.SETUP_DISPLAY[f][s]);
                        if (f === 'transactionlink') {
                            field.linkText = "Visualizar"
                        }
                    }
                    var line = 0;
                    var valueinv = 0
                    var countinv = 0
                    //USA O OBJETO DE RESULTADO DE BUSCA DE INVOICES PARA MAPEAR OS VALORES INSERIDOS NA SUBLISTA DE INVOICES
                    for (i in invoices) {
                        for (r in cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS) {
                            if (r === 'transactionlink') {
                                var recordURL = url.resolveRecord({
                                    recordType: "invoice",
                                    recordId: invoices[i]['id'],
                                    isEditMode: false
                                })
                                sublist.setSublistValue({ id: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS[r].id, line: line, value: recordURL })
                            } else {
                                !!invoices[i][r]
                                    ? sublist.setSublistValue({ id: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS[r].id, line: line, value: invoices[i][r] })
                                    : cts.MAINTENANCE_BILLET_ST.VOID;
                            }
                        }
                        ++line;
                        ++countinv
                        valueinv += parseFloat(invoices[i].amount)
                    }
                }

                const countinvField = form.addField({
                    id: 'custpage_countinv',
                    label: 'Qtd de Faturas CNAB',
                    type: 'integer',
                })
                countinvField.updateDisplayType({ displayType: 'disabled' })
                countinvField.defaultValue = countinv

                const valueinvField = form.addField({
                    id: 'custpage_valueinv',
                    label: 'Valor em Faturas CNAB',
                    type: 'currency',
                })
                valueinvField.updateDisplayType({ displayType: 'disabled' })
                valueinvField.defaultValue = valueinv.toFixed(2)

                const countinstallField = form.addField({
                    id: 'custpage_countinstall',
                    label: 'Qtd de Parcelas',
                    type: 'integer',
                })
                countinstallField.updateDisplayType({ displayType: 'disabled' })
                countinstallField.defaultValue = countinstall

                const valueinstallField = form.addField({
                    id: 'custpage_valueinstall',
                    label: 'Valor em Parcelas',
                    type: 'currency',
                })
                valueinstallField.updateDisplayType({ displayType: 'disabled' })
                valueinstallField.defaultValue = valueinstall.toFixed(2)


                const urlrestid = url.resolveScript({
                    scriptId: 'customscript_quod_callmapreduce_rl',
                    deploymentId: 'customdeploy_quod_callmapred',
                    returnExternalUrl: false
                })

                const urlRest = form.addField({
                    id: 'custpage_urlrest',
                    label: 'URL Rest',
                    type: 'text',
                })
                urlRest.updateDisplayType({ displayType: 'hidden' })
                urlRest.defaultValue = urlrestid

                return form;
            } catch (e) {
                log.error('generatePOSTForm', e);
                throw e;
            }
        }

        function getInvoices(parameters) {
            try {
                var filters = [];
                filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INVOICE_FILTERS.NOT_BRASPAG_BILLET));
                filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INVOICE_FILTERS.INVOICE_STATUS));
                filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INVOICE_FILTERS.INSTALLMENT_STATUS));
                filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INVOICE_FILTERS.MAINLINE));
                if (Object.keys(parameters).length > 0) {

                    for (p in parameters) {
                        log.debug('invoice - parameters field', cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS[p])
                        log.debug('parameters[p]', parameters[p])
                        if (cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS[p])
                            if (cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS[p].hasOwnProperty('join'))
                                filters.push(search.createFilter({
                                    name: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS[p].id,
                                    join: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS[p].join,
                                    operator: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS[p].operator,
                                    values: parameters[p]
                                }));
                            else
                                filters.push(search.createFilter({
                                    name: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS[p].id,
                                    operator: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS[p].operator,
                                    values: parameters[p]
                                }));
                    }
                }

                var columns = [];
                for (c in cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS) {
                    if (cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS[c].hasOwnProperty('join'))
                        columns.push(search.createColumn({
                            name: cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS[c].name,
                            join: cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS[c].join
                        }));
                    else
                        columns.push(search.createColumn({
                            name: cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS[c].name
                        }));
                }
                var invoiceSearch = search.create({ type: search.Type.INVOICE, filters: filters, columns: columns });
                var results = invoiceSearch.run().getRange({ start: 0, end: 1000 });
                var invoices = {};
                for (r in results) {
                    if (!invoices[results[r].id]) {
                        invoices[results[r].id] = {};
                        invoices[results[r].id].id = results[r].id;
                        invoices[results[r].id].transaction = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.TRANID);
                        invoices[results[r].id].entity = results[r].getText(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.ENTITY);
                        invoices[results[r].id].trandate = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.TRANDATE);
                        invoices[results[r].id].amount = Number(results[r].getValue(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.AMOUNT)).toFixed(2);
                        invoices[results[r].id].cnpj = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.CNPJ);
                        invoices[results[r].id].opportunity = results[r].getText({
                            name: cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.OPPORTUNITY.name,
                            join: cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.OPPORTUNITY.join
                        }).trim();
                        invoices[results[r].id].contract = results[r].getText(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.CONTRACT);
                        invoices[results[r].id].nfse = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.NFSE);
                        // invoices[results[r].id].nfe = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.NFE);
                        invoices[results[r].id].rps = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.RPS);
                        invoices[results[r].id].installmentduedate = results[r].getValue({
                            name: cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.DUEDATE_INSTALLMENT.name,
                            join: cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.DUEDATE_INSTALLMENT.join
                        });
                        invoices[results[r].id].statusnfe = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.STATUS_NFSE);
                        invoices[results[r].id].billingcycle = results[r].getText(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.BILLING_CYCLE);
                        invoices[results[r].id].paymentcondition = results[r].getText(cts.MAINTENANCE_BILLET_ST.INVOICE_COLUMNS.PAYMENT_CONDITION);
                    }
                }

                return invoices;
            } catch (e) {
                log.error('getInvoices', e);
                throw e;
            }
        }

        function getInstallments(parameters) {
            try {
                var filters = [];
                filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_FILTERS.BRASPAG_BILLET));
                // filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_FILTERS.INVOICE_STATUS));
                filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_FILTERS.INVOICE_TYPE));
                filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_FILTERS.INSTALLMENT_STATUS));
                filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_FILTERS.MAINLINE));
                filters.push(search.createFilter(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_FILTERS.PAYMENT_CONDITION));
                if (Object.keys(parameters).length > 0) {
                    for (p in parameters) {
                        log.debug('parcela - parameters field', cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS_INST[p])
                        log.debug('parameters[p]', parameters[p])
                        if (cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS_INST[p])
                            if (cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS_INST[p].hasOwnProperty('join'))
                                filters.push(search.createFilter({
                                    name: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS_INST[p].id,
                                    join: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS_INST[p].join, // ceva
                                    operator: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS_INST[p].operator,
                                    values: parameters[p]
                                }));
                            else
                                filters.push(search.createFilter({
                                    name: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS_INST[p].id,
                                    operator: cts.MAINTENANCE_BILLET_ST.MAP_FILTER_FIELDS_INST[p].operator,
                                    values: parameters[p]
                                }));
                    }
                }
                // Filtrar vencimentos futuros
                filters.push(search.createFilter({
                    name: 'custrecord_sit_parcela_d_dt_vencimen',
                    operator: 'after',
                    values: 'today'
                }));

                var columns = [];
                for (c in cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS) {
                    if (cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS[c].hasOwnProperty('join'))
                        columns.push(search.createColumn({
                            name: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS[c].name,
                            join: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS[c].join
                        }));
                    else
                        columns.push(search.createColumn({
                            name: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS[c].name
                        }));
                }

                var installSearch = search.create({ type: 'customrecord_sit_parcela', filters: filters, columns: columns });
                var results = installSearch.run().getRange({ start: 0, end: 1000 });
                var installments = {};
                for (r in results) {
                    if (!installments[results[r].id]) {
                        installments[results[r].id] = {};
                        installments[results[r].id].id = results[r].id;
                        installments[results[r].id].transaction = results[r].getValue({
                            name: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.TRANID.name,
                            join: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.TRANID.join,
                        });
                        installments[results[r].id].transactionid = results[r].getValue({
                            name: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.TRANLINKID.name,
                            join: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.TRANLINKID.join,
                        });
                        installments[results[r].id].installment = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.INSTALLMENT);
                        installments[results[r].id].entity = results[r].getText(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.ENTITY);
                        installments[results[r].id].trandate = results[r].getValue({
                            name: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.TRANDATE.name,
                            join: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.TRANDATE.join
                        });
                        installments[results[r].id].installmentAmount = Number(results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.AMOUNT)).toFixed(2);
                        installments[results[r].id].installmentAmountPaid = Number(results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.PAID_AMOUNT)).toFixed(2);
                        installments[results[r].id].contract = results[r].getText({
                            name: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.CONTRACT.name,
                            join: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.CONTRACT.join
                        });
                        installments[results[r].id].installmentduedate = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.DUEDATE_INSTALLMENT);
                        installments[results[r].id].installmentstatus = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.STATUS_INSTALLMENT);
                        installments[results[r].id].braspaglink = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.BRASPAG_LINK);
                        installments[results[r].id].braspagid = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.BRASPAG_ID);
                        installments[results[r].id].braspagstatus = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.BRASPAG_STATUS);
                        installments[results[r].id].braspagdescription = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.BRASPAG_DESCRIPTION);
                        installments[results[r].id].braspagmessage = results[r].getValue(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_COLUMNS.BRASPAG_MESSAGE);
                    }
                }

                return installments;
            } catch (e) {
                log.error('getInstallments', e);
                throw e;
            }
        }

        return {
            handleGetForm: handleGetForm,
            handlePost: handlePost
        };
    });