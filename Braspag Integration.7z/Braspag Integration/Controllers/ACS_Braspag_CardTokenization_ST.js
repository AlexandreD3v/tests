/**
* @NApiVersion 2.x
* @NScriptType Suitelet
*/

define(['../Models/ACS_Braspag_CardTokenization_MSR'],
    function (msr) {
        function onRequest(context) {
            if (context.request.method === "GET") {
                context.response.writePage(msr.handleGetForm(context));
            }
            else {
                context.response.write(msr.handlePost(context));
            }
        }
        return {
            onRequest: onRequest
        };
});