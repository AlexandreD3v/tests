/**
 * ACS_Braspag_BilletSender_MR.js
 *@NApiVersion 2.0
 *@NScriptType MapReduceScript
 *@author erickmunekata
 */

define(['N/search', 'N/runtime', '../Models/Quod_Braspag_Integration_MSR', // SSN_1241
"../Models/ACS_Braspag_Integration_CTS", '../Api/ACS_Braspag_API' ],

    function (search, runtime, msr, cts, braspag_api) {

        function getInputData() {

            try{
                // pegar as parcelas do parametro
                var currentScript = runtime.getCurrentScript()
                var installments = currentScript.getParameter({ name: 'custscript_o2c_braspag_installs' }).split(',')
                log.debug('valor', installments)

                return search.create({
                    type: 'customrecord_sit_parcela',
                    filters: [
                        ['internalid', 'anyof', installments],
                    ],
                    columns: [
                        'custrecord_sit_parcela_l_cliente',
                        'custrecord_sit_parcela_n_valor',
                        'custrecord_o2s_parcela_l_forma_pagamento',
                        'custrecord_sit_parcela_n_vl_pago',
                        'custrecord_sit_parcela_l_subsidiaria',
                        search.createColumn({ name: 'custentity_psg_br_cpf', join: 'CUSTRECORD_SIT_PARCELA_L_CLIENTE' }),
                        search.createColumn({ name: 'custentity_psg_br_cnpj', join: 'CUSTRECORD_SIT_PARCELA_L_CLIENTE' }),
                        'custrecord_sit_parcela_l_transacao',
                        'custrecord_sit_parcela_d_dt_vencimen',
                        search.createColumn({ name: 'custrecord_acs_duedateinstallment_dt', join: 'CUSTRECORD_ACS_PARENT_LS' }),
                        'custrecord_sit_parcela_i_numero'
                    ]
                });
            }catch(e){
                log.error('getInputData', e);
            }
        }

        function map(context) {
            

            log.debug("update", "init... ");
            try{
                log.debug("update mapcontextresult", context.value);
                var data = JSON.parse(context.value);
                
                var provider = msr.getProvider(data.values.custrecord_sit_parcela_l_subsidiaria.value, data.values.custrecord_o2s_parcela_l_forma_pagamento.value);
                
                if(typeof provider === "object"){
                    var info = {}
                    search.create({
                        type: 'invoice',
                        filters: [
                            ['type', 'anyof', 'CustInvc'],
                            'AND',
                            ['internalid', 'anyof', data.values.custrecord_sit_parcela_l_transacao.value],
                            'AND',
                            ['mainline', 'is', 'T'],
                        ],
                        columns: [
                            search.createColumn({ name: 'custrecord_sit_address_l_tp_logr', join: 'billingAddress' }),
                            search.createColumn({ name: 'address1', join: 'billingAddress' }),
                            search.createColumn({ name: 'custrecord_sit_address_i_numero', join: 'billingAddress' }),
                            search.createColumn({ name: 'zip', join: 'billingAddress' }),
                            search.createColumn({ name: 'custrecord_o2g_address_l_mun', join: 'billingAddress' }),
                            search.createColumn({ name: 'custrecord_sit_address_complemento', join: 'billingAddress' }),
                            search.createColumn({ name: 'custrecord_sit_address_t_bairro', join: 'billingAddress' }),
                            search.createColumn({ name: 'custrecord_acs_quodcontr_billing_type_ls', join: 'CUSTBODY_ACS_OPPORTUNITY_CONTRACT_LS' }),
                        ],
                    }).run().each(function (result) {
                        info.logradouro = result.getText({name: 'custrecord_sit_address_l_tp_logr', join: 'billingAddress'}) 
                        info.address1 = result.getValue({name: 'address1', join: 'billingAddress'}) 
                        info.numero = result.getValue({name: 'custrecord_sit_address_i_numero', join: 'billingAddress'}) 
                        info.zip = result.getValue({name: 'zip', join: 'billingAddress'}) 
                        info.municipio = result.getText({name: 'custrecord_o2g_address_l_mun', join: 'billingAddress'}) 
                        info.complemento = result.getValue({name: 'custrecord_sit_address_complemento', join: 'billingAddress'}) 
                        info.bairro = result.getValue({name: 'custrecord_sit_address_t_bairro', join: 'billingAddress'}) 
                        info.billingType = result.getValue({name: 'custrecord_acs_quodcontr_billing_type_ls', join: 'CUSTBODY_ACS_OPPORTUNITY_CONTRACT_LS'}) 
                        return false;
                      });

                
                    var districtArray = info.municipio.split('-');
                    var city = districtArray[0].trim();
                    var state = districtArray[1].trim();
                //     log.debug('data', data)
                //     log.debug('data.values', data.values)
                //     log.debug('data.values', data.values.amount)
                //     log.debug('data.values.custrecord_sit_parcela_n_valor',  data.values["custrecord_sit_parcela_n_valor.CUSTRECORD_SIT_PARCELA_L_TRANSACAO"])
                    var duedate = data.values.custrecord_sit_parcela_d_dt_vencimen ? data.values.custrecord_sit_parcela_d_dt_vencimen.split('/').reverse().join('-') : 
                    data.values["custrecord_acs_duedateinstallment_dt.CUSTRECORD_ACS_PARENT_LS"].split('/').reverse().join('-');
                //      log.debug('duedate', duedate)
                    var formattedAddress = msr.checkAndFormatAddress({
                        street: info.logradouro ? info.logradouro + ' ' + info.address1.trim() : info.address1.trim(),
                        number: info.numero,
                        complement: info.complemento,
                        district: info.bairro
                    });
                //     log.debug('formattedAddress', formattedAddress)

                    var paidAmount = Number(data.values.custrecord_sit_parcela_n_vl_pago)
                    var amount = Number(data.values.custrecord_sit_parcela_n_valor)
                    if (data.values.custrecord_sit_parcela_n_vl_pago === ".00") {
                        amount = Number(data.values.custrecord_sit_parcela_n_valor)
                    } else {
                        amount = amount - paidAmount
                    }
                    var billetBody = msr.getBraspagPaymentData({
                        transactionId: data.id,
                        customer: msr.checkAndFormatName(data.values.custrecord_sit_parcela_l_cliente.text),
                        identity: !!data.values['custentity_psg_br_cpf.CUSTRECORD_SIT_PARCELA_L_CLIENTE'] ?
                            data.values['custentity_psg_br_cpf.CUSTRECORD_SIT_PARCELA_L_CLIENTE'].replace(/[/.-]/g,"") : 
                            data.values['custentity_psg_br_cnpj.CUSTRECORD_SIT_PARCELA_L_CLIENTE'].replace(/[/.-]/g,""),
                        identityType: !!data.values['custentity_psg_br_cpf.CUSTRECORD_SIT_PARCELA_L_CLIENTE'] ? "CPF" : "CNPJ",
                        duedate: duedate,
                        amount: amount.toFixed(2).toString(),  // dm_37
                        operationType: cts.PAYMENT_CONDITION_MAP[ data.values.custrecord_o2s_parcela_l_forma_pagamento.value],
                        provider:provider,
                        address: {
                            street: formattedAddress.street,
                            number: formattedAddress.number,
                            complement: formattedAddress.complement.replace(/[/.;-]/g,""),
                            zipcode: info.zip,
                            city: msr.removeAccents(city).toUpperCase(),
                            state: state,
                            district: formattedAddress.district
                        }
                        
                    });
                //     log.debug('B')
                    var requestTime = new Date();
                //     log.debug('billetBody', billetBody)
                log.debug('data', data)
                    var newPayment = braspag_api.newPayment(JSON.stringify(billetBody));
                    newPayment.responseTime = new Date();
                    newPayment.requestTime = requestTime;
                    newPayment.installmentNumber = data.values.custrecord_sit_parcela_i_numero;
                    newPayment.installmentId = data.id;
                    newPayment.invoice = data.values.custrecord_sit_parcela_l_transacao.value;
                    newPayment.subsidiary = data.values.subsidiary;
                    msr.processNewPayment(newPayment, provider);
                }else{
                    throw cts.ERROR.PROVIDER_NOT_FOUND + data.id;
                }
            }catch(e){
                log.error('map error', e);
                throw e;
            }
        }

        function summarize(summary) {

        }


        return {
            getInputData: getInputData,
            map: map,
            summarize: summarize
        };

    });
