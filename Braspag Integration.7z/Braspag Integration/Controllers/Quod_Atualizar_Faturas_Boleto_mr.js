/**
 * @NApiVersion 2.x
 * @NModuleScope SameAccount
 * @author: Danilo Nascimento
 * @since: 14/09/2020
 * @version: 1.0
 * @NScriptType MapReduceScript
 */
define(['N/search', 'N/record', '../Models/Quod_Braspag_Atualizar_Faturas_Boleto'], function (search, record, Quod_Braspag_Atualizar_Faturas_Boleto) {

    function getInputData() {
        try {
            //return search.load({id:"customsearch_acs_braspagintebilletpaym_2"})
            // return search.load({id:"customsearch_acs_braspagintebilletpaymen"})
            return search.load({ id: "customsearch_quod_braspagpayment" }) // dm_37
        } catch (e) {
            log.error('Erro ao tentar buscar faturas de boleto Braspag', e);
        }
    }

    function map(context) {
        var data = JSON.parse(context.value);
        log.debug('data', data)
        var values = data.values;
        var invoice = {
            id: data.id,
            paymentId:
                values['custrecord_o2c_braspag_paymentid.CUSTRECORD_SIT_PARCELA_L_TRANSACAO'] ||
                values['custbody_acs_braspag_paymentid_ds'], 
            subsidiary: values['subsidiary'].value,
            formaDePagamento: values['custrecord_o2s_cod_pagto_l_forma_pagto.CUSTBODY_ACS_OPPORTUNITY_PAYM_COND_LS'].value,
            legado: values['custbody_acs_braspag_paymentid_ds'] ? true : false  // dm_37
        }
        log.debug('ssn_1241 ************************** invoice', invoice)
        try {
            var atualiza_fatura = new Quod_Braspag_Atualizar_Faturas_Boleto(invoice)
            log.debug('ssn_1241 ************************** atualiza_fatura 1', atualiza_fatura)
            atualiza_fatura.getBraspagPaymentStatus()
            log.debug('ssn_1241 ************************** atualiza_fatura 2', atualiza_fatura)
            atualiza_fatura.createPaymentToInvoice()
            log.debug('ssn_1241 ************************** atualiza_fatura 3', atualiza_fatura)
            atualizarContrato(invoice.id);
        } catch (error) {
            log.error("Erro ao iniciar Quod_Braspag_Atualizar_Faturas_Boleto na fatura " + invoice.id, error)
            throw error
        }
    }

    function atualizarContrato(invoiceid) {
        try {
            var dadosFatura = getDadosFatura({
                invoiceId: invoiceid
            });
            var itemFatura = getItemFaturaPme({
                faturaId: invoiceid
            });
            var cValues = {};
            if (!!dadosFatura.periodicidade || !!itemFatura.periodicidade) {
                var _dataCarenciaFaturamento = getCarenciaFaturamento(dadosFatura.periodicidade || itemFatura.periodicidade);
                cValues['custrecord_quod_carencia_fat_datafim'] = _dataCarenciaFaturamento;
            }

            cValues['custrecord_quod_checklist_migracao_ok'] = true;
            record.submitFields({
                type: 'customrecord_acs_quodcontract',
                id: dadosFatura.contratoId,
                values: cValues
            });
            log.debug("Contrato " + dadosFatura.contratoId + " teve a data da fim da carência")
        } catch (error) {
            var mensagemErro = "Contrato " + dadosFatura.contratoId + " gerou um erro ao tentar atualizar a data da fim da carência";
            log.error(mensagemErro, error)
            throw new Error(mensagemErro);
        }
    }

    /**
     * 
     * @param {Object} opcoes
     * @param {String | Number} opcoes.invoiceId
     */
    function getDadosFatura(opcoes) {
        var _periodicidadeColumn = "custbody_acs_opportunity_paym_cond_ls.custrecord_quod_num_parcel_credit_card";
        var _contratoColumn = "custbody_acs_opportunity_contract_ls";
        var _fieldLookup = search.lookupFields({
            type: "invoice",
            id: opcoes.invoiceId,
            columns: [_periodicidadeColumn, _contratoColumn]
        });
        return {
            contratoId: _fieldLookup[_contratoColumn][0].value,
            periodicidade: _fieldLookup[_periodicidadeColumn]
        }
    }

    function getCarenciaFaturamento(periodicidade) {
        var _dataCarenciaFaturamento = new Date();
        var _prazoAdicional = 4;
        log.debug("_dataCarenciaFaturamento", _dataCarenciaFaturamento);
        for (var i = 0; i < periodicidade; i++) {
            _dataCarenciaFaturamento.setMonth(_dataCarenciaFaturamento.getMonth() + 1);
            log.debug("_dataCarenciaFaturamento após +1 mês", _dataCarenciaFaturamento);
        }

        _dataCarenciaFaturamento.setDate(_dataCarenciaFaturamento.getDate() - _prazoAdicional);
        log.debug("_dataCarenciaFaturamento após dias", _dataCarenciaFaturamento);
        return _dataCarenciaFaturamento
    }

    /**
     * Pegar Item da Fatura PME. A premissa é que faturas do PME só tenham apenas 1 item
     * @param {Object} opcoes
     * @param {Record} opcoes.faturaObj
     * @param {String | Number} opcoes.faturaId
     */
    function getItemFaturaPme(opcoes) {
        if (!opcoes || typeof opcoes != 'object') throw new Error("Não foi passado o objeto correto para pegar o item da fatura PME");
        var fatura;
        if (!!opcoes.faturaObj) {
            if (opcoes.faturaObj.constructor.name === 'NetSuiteObject') fatura = opcoes.faturaObj;
        }
        if (!!opcoes.faturaId) {
            fatura = record.load({
                type: "invoice",
                id: opcoes.faturaId,
                isDynamic: true
            })
        }

        var itemId = fatura.getSublistValue({
            sublistId: 'item',
            fieldId: 'item',
            line: 0
        });

        var fieldLookupPeriodicidade = search.lookupFields({
            type: "serviceitem",
            id: itemId,
            columns: "custitem_quod_periodicidade"
        });
        log.debug(fieldLookupPeriodicidade)
        var nomePeriodicidade = !!fieldLookupPeriodicidade.custitem_quod_periodicidade[0] ? fieldLookupPeriodicidade.custitem_quod_periodicidade[0].text : '';
        var valorPeriodicidade = getValorPeriodicidade(nomePeriodicidade);
        return {
            itemId: itemId,
            periodicidade: valorPeriodicidade
        }
    }

    function getValorPeriodicidade(nomePeriodicidade) {
        var opcoes = {
            bimestral: 2,
            trimestral: 3,
            semestral: 6
        }
        return opcoes[nomePeriodicidade.toLowerCase()];
    }



    return {
        getInputData: getInputData,
        map: map
    }
});
