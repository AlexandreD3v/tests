/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 * @author: Danilo Nascimento
 * Date: 11/09/2020
 * Version: 1.0
 */


define(['../Api/ACS_Braspag_API', 'N/search', '../Models/ACS_Braspag_Integration_MSR', "../Models/ACS_Braspag_Integration_CTS"],

    function (ACS_Braspag_API, search, msr, cts) {

        var data = {
            id: "985009",
            values: {
              entity: {
                value: "1488453",
                text: "Kaique e Carlos Locações de Automóveis Ltda",
              },
              amount: "2341.56",
              custbody_acs_braspag_cardtoken_ds:
                "53d15602-ee43-4856-a40f-c308024cc23a",
              "custrecord_o2s_cod_pagto_l_forma_pagto.CUSTBODY_ACS_OPPORTUNITY_PAYM_COND_LS": {
                value: "3",
                text: "03 - Cartão de Crédito",
              },
              subsidiary: {
                value: "2",
                text: "Controladora : Gestora de Inteligência de Crédito S.A.",
              },
              custbody_acs_braspag_cardbrand_ds: "Visa",
              "custrecord_sit_parcela_d_dt_vencimen.CUSTRECORD_SIT_PARCELA_L_TRANSACAO":
                "16/10/2020",
              formulanumeric: "6",
            },
          };

        /**
         * Definition of the Suitelet script trigger point.
         * @param {Object} context
         * @param {ServerRequest} context.request - Encapsulation of the incoming request
         * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
         * @Since 2015.2
         */
        function onRequest(context) {
            if(context.request.method === "GET"){
                gerarCobrancaNaBraspag(data);
                return;

                var paymentId = context.request.parameters.paymentId;
                if(!paymentId) {
                    log.debug("Não foi passado o Id do pagamento da Braspag")
                    return;
                }
                log.debug("Retorno BrasPag", ACS_Braspag_API.getPayment( paymentId ));
            }
        }

        function gerarCobrancaNaBraspag(data) {
            var provider = msr.getProvider(data.values.subsidiary.value, data.values["custrecord_o2s_cod_pagto_l_forma_pagto.CUSTBODY_ACS_OPPORTUNITY_PAYM_COND_LS"].value);
            log.audit('getProvider', provider);
            if(typeof provider === "object"){
                var paymentBody = msr.getBraspagPaymentData({
                    transactionId: data.id,
                    customer: data.values.entity.text,
                    amount: data.values.amount,
                    cardToken: data.values[cts.TRANSACTION_FIELDS.CARDTOKEN],
                    cardBrand: data.values[cts.TRANSACTION_FIELDS.CARDBRAND],
                    operationType: cts.PAYMENT_CONDITION_MAP[ data.values["custrecord_o2s_cod_pagto_l_forma_pagto.CUSTBODY_ACS_OPPORTUNITY_PAYM_COND_LS"].value],
                    provider:provider,
                    capture:true,
                    withCardToken:true,
                    operationInstallments: data.values.formulanumeric
                });
                log.debug("paymentBody", paymentBody)
                var requestTime = new Date();
                var newPayment = ACS_Braspag_API.newPayment(JSON.stringify(paymentBody));
                newPayment.responseTime = new Date();
                newPayment.requestTime = requestTime;
                newPayment.invoice = data.id;
                newPayment.subsidiary = data.values.subsidiary;
                log.audit('newPayment', JSON.stringify(newPayment));
                msr.processNewPayment(newPayment, provider);
            }
        }

        return {
            onRequest: onRequest
        }
    }
);