/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 * author: Erick Munekata
 * Date: 22/11/2019
 * Version: 1.0
 */


define(['../Models/ACS_Braspag_InvoiceNotification_MSR'],

    /**

     */
    function (msr) {

        /**
         * Definition of the Suitelet script trigger point.
         * @param {Object} context
         * @param {ServerRequest} context.request - Encapsulation of the incoming request
         * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
         * @Since 2015.2
         */
        function onRequest(context) {
            if(context.request.method === "POST"){
                log.audit('Parameters:', context.request.parameters);
                log.audit('Body:', context.request.body);
                msr.processNotification(context.request.body);
            }
        }

        return {
            onRequest: onRequest
        }
    }
);