/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope
 * author: Erick Munekata
 * Date: 02/12/2019
 * Version: 1.0
 */

define(['N/runtime', 'N/ui/serverWidget', 'N/record', '../Models/ACS_Braspag_Integration_CTS', '../Models/ACS_Braspag_Integration_MSR'],
    function (runtime, sw, record, cts, msr) {

        function beforeLoad(context){

            var id = context.newRecord.id,
                role = runtime.getCurrentUser().role,
                subsidiary = runtime.getCurrentUser().subsidiary,
                disableField;

            try{

                if (runtime.executionContext == runtime.ContextType.USER_INTERFACE) {

                    var subsidiaryRT = record.load({type: record.Type.SUBSIDIARY, id: subsidiary});
                    var braspagBilletRole = subsidiaryRT.getValue(cts.SUBSIDIARY.BRASPAG_BILLET_ROLE);

                    if (!!braspagBilletRole) {

                        if (context.type == context.UserEventType.CREATE)
                            if (role != braspagBilletRole) disableField = true;

                        if (context.type == context.UserEventType.EDIT || context.type == context.UserEventType.XEDIT) {
                            var installments = msr.getInvoiceInstallments(id);
                            var haveOpenReopen;
                            haveOpenReopen = msr.checkOpenReopenInstallments(installments);

                            if (!haveOpenReopen || role != braspagBilletRole) disableField = true;
                        }

                        if (disableField) {
                            var form = context.form;
                            var braspagBillet = form.getField({id: cts.TRANSACTION_FIELDS.USEBRASPAGBILLET});
                            braspagBillet.updateDisplayType({displayType: sw.FieldDisplayType.DISABLED});
                        }
                    }
                }
            }catch(e){
                log.error(e.name, e.message);
                throw e;
            }
        }

        function beforeSubmit(context){

            var role = runtime.getCurrentUser().role,
                subsidiary = runtime.getCurrentUser().subsidiary;

            try{
                if (context.type == context.UserEventType.EDIT || context.type == context.UserEventType.XEDIT){

                    var id = context.newRecord.id;
                    var installments = msr.getInvoiceInstallments(id);

                    if (installments.length > 0){

                        // Verifica se tem installments com status diferente de open que usem boleto cnab
                        var haveOpenReopen, useBraspagBilletAfter, useBraspagBilletBefore;
                        haveOpenReopen = msr.checkOpenReopenInstallments(installments);
                        useBraspagBilletAfter = context.newRecord.getValue(cts.TRANSACTION_FIELDS.USEBRASPAGBILLET);
                        useBraspagBilletBefore = context.oldRecord.getValue(cts.TRANSACTION_FIELDS.USEBRASPAGBILLET);
                        if(!haveOpenReopen && useBraspagBilletAfter && !useBraspagBilletBefore)
                            throw cts.ERROR.INSTALLMENTS_WITH_STATUS_DIFFERENT_FROM_OPEN;

                        var subsidiaryRT = record.load({type: record.Type.SUBSIDIARY, id: subsidiary});
                        var braspagBilletRole = subsidiaryRT.getValue(cts.SUBSIDIARY.BRASPAG_BILLET_ROLE);

                        if(!!braspagBilletRole){
                            var oldValue = context.oldRecord.getValue(cts.TRANSACTION_FIELDS.USEBRASPAGBILLET),
                                newValue = context.newRecord.getValue(cts.TRANSACTION_FIELDS.USEBRASPAGBILLET);

                            if (role != braspagBilletRole && oldValue != newValue)
                                throw cts.ERROR.BRASPAG_BILLET_WRONG_ROLE;
                        }
                    }
                }
            }catch(e){
                log.error('ACS_Braspag_InvoiceBilletCheck_UE - error', e);
                throw e.name + ': ' + e.message;
            }
        }

        return {
            beforeLoad: beforeLoad,
            beforeSubmit: beforeSubmit
        }
    }
);