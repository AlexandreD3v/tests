/**
 *@NApiVersion 2.x
 *@NScriptType ClientScript
 *@author felipema90
 */

define(['N/url', 'N/currentRecord', '../Models/ACS_Braspag_Integration_CTS', 'N/search', 'N/record'],

    function(url, cr, cts, search, record) {

        function pageInit(context){}

        function openCardJs(){
            var params = "";
            var method;
            var rec = cr.get();
            var r = record.load({type:rec.type, id: rec.id });
            if( r.type == "opportunity" ){
                method = r.getValue({fieldId: cts.TRANSACTION_FIELDS.ACS_PAYMENT_METHOD});
                params += "&opportunity="+ rec.id;
            }
            if( r.type == "invoice" ){
                params += "&invoice="+ rec.id;
            }
            if( r.type ==  cts.CONTRACT_CHANGE.RECORDTYPE ){
                method = r.getValue({fieldId: cts.CONTRACT_CHANGE.PAYMENT_METHOD });
                params += "&contract="+ rec.id;
            }
            var lookup = search.lookupFields({
                type: cts.PAYMENT_CONDITION.RECORDTYPE,
                id: method,
                columns: cts.PAYMENT_CONDITION.METHOD
            });
            console.log( "method", method )
            var st_url = url.resolveScript(cts.CARDJS_SUITELET_IDS);
            window.location = st_url+ params + "&subsidiary=2&paymentway="+lookup[cts.PAYMENT_CONDITION.METHOD][0].value;
        }
        return {
            pageInit: pageInit,
            openCardJs: openCardJs
        };
    });
