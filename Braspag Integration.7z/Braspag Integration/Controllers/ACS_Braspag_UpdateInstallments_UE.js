/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope
 * author: Erick Munekata
 * Date: 25/11/2019
 * Version: 1.0
 */

define(['N/runtime', 'N/ui/serverWidget', 'N/search', 'N/record', '../Models/ACS_Braspag_Integration_CTS', '../Models/ACS_Braspag_Integration_MSR'],
    function (runtime, sw, search, record, cts, msr) {

        function afterSubmit(context){
            var subsidiary = runtime.getCurrentUser().subsidiary;

            try{
                if (context.type == context.UserEventType.EDIT || context.type == context.UserEventType.XEDIT){

                    var id = context.newRecord.id;
                    var subsidiaryRT = record.load({type: record.Type.SUBSIDIARY, id: subsidiary});
                    var braspagBilletRole = subsidiaryRT.getValue(cts.SUBSIDIARY.BRASPAG_BILLET_ROLE);

                    if(!!braspagBilletRole){
                        var newRecord = context.newRecord;
                        var usabraspag = newRecord.getValue(cts.TRANSACTION_FIELDS.USEBRASPAGBILLET);
                        if(usabraspag == 'T' || usabraspag == true) {
                            var installments = msr.getInvoiceInstallments(id);
                            if (installments.length > 0)
                                msr.updateInstallments(installments);
                        }
                    }
                }
            }catch(e){
                log.error('ACS_Braspag_InvoiceBilletCheck_UE - error', e);
                throw e.name + ': ' + e.message;
            }
        }

        return {
            afterSubmit: afterSubmit
        }
    }
);