/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 *@author felipema90
 */

define(['N/record', '../Models/ACS_Braspag_Integration_CTS', 'N/search'],

    function(record, cts, search) {

        function beforeLoad( context )
        {
            if( context.type == context.UserEventType.VIEW ){
                var paymentMethod;
                if( context.newRecord.type == cts.CONTRACT_CHANGE.RECORDTYPE ){
                    if ( context.newRecord.getValue({fieldId: cts.CONTRACT_CHANGE.TYPE }) == cts.CONTRACT_CHANGE.TYPE_PAYMENTWAY )
                    {
                        if( context.newRecord.getValue({fieldId: cts.CONTRACT_CHANGE.PAYMENT_METHOD }) > 0 &&
                            (!context.newRecord.getValue({fieldId: cts.CONTRACT_CHANGE.CARD_TOKEN }) ||
                             context.newRecord.getValue({fieldId: cts.CONTRACT_CHANGE.CARD_TOKEN }) == "" ) ){
                            paymentMethod = context.newRecord.getValue({fieldId: cts.CONTRACT_CHANGE.PAYMENT_METHOD })
                        }
                    }
                }else{
                    if( context.newRecord.type == "opportunity"  ){
                        if( context.newRecord.getValue({fieldId: cts.TRANSACTION_FIELDS.ACS_PAYMENT_METHOD }) > 0 &&
                             context.newRecord.getValue({fieldId: cts.TRANSACTION_FIELDS.CONTRACT }) == "" &&
                             context.newRecord.getValue({fieldId: cts.TRANSACTION_FIELDS.CARDTOKEN }) == "" ){
                             paymentMethod = context.newRecord.getValue({fieldId: cts.TRANSACTION_FIELDS.ACS_PAYMENT_METHOD })
                        }
                    }
                }
                if( !!paymentMethod ){
                    var lookup = search.lookupFields({
                        type: cts.PAYMENT_CONDITION.RECORDTYPE,
                        id: paymentMethod,
                        columns: cts.PAYMENT_CONDITION.METHOD
                    });
                    if(!!lookup[cts.PAYMENT_CONDITION.METHOD]) {
                        if(lookup[cts.PAYMENT_CONDITION.METHOD].length > 0) {
                            if (lookup[cts.PAYMENT_CONDITION.METHOD][0].value == cts.PAYMENT_CONDITION.CREDIT_CARD ||
                                lookup[cts.PAYMENT_CONDITION.METHOD][0].value == cts.PAYMENT_CONDITION.DEBIT_CARD) {
                                context.form.addButton({
                                    id: 'custpage_acs_tokenization_bt',
                                    label: 'Pré-Autorizar Cartão',
                                    functionName: 'openCardJs'
                                });
                                context.form.clientScriptModulePath = './ACS_Braspag_ShowCardJs_CL.js';
                            }
                        }
                    }
                }
            }

        }

        return {
            beforeLoad: beforeLoad
        };
    });
