/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 * author: Erick Munekata
 * Date: 27/11/2019
 * Version: 1.0
 */

define(['../Models/ACS_Braspag_MaintenanceBillet_MSR'],
    function (msr) {
        function onRequest(context) {
            if (context.request.method === "GET") {
                context.response.writePage(msr.handleGetForm(context));
            }
            else {
                context.response.writePage(msr.handlePost(context));
            }
        }
        return {
            onRequest: onRequest
        };
    }
);