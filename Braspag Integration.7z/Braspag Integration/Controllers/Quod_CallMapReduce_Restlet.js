/**
 *@NApiVersion 2.x
 *@NScriptType Restlet
 */
define(['N/task'], function(task) {

    function _post(context) {
        log.debug('Chamou Restlet')
        const mrTask = task.create({
            taskType: task.TaskType.MAP_REDUCE,
            scriptId: "customscript_acs_braspagbilletsender_mr", 
            params: {
                custscript_o2c_braspag_installs: context 
            }
        })
        const mrTaskId = mrTask.submit()
        log.error({
            title: 'status CORRETO',
            details: task.checkStatus(mrTaskId).status
        })
        var status = task.checkStatus(mrTaskId).status

        while ( status === task.TaskStatus.PENDING || status === task.TaskStatus.PROCESSING) {
            status = task.checkStatus(mrTaskId).status
        }

        log.debug({
            title: 'saiu',
            details: status
        })
           
        if(status == task.TaskStatus.COMPLETE) 
            return 'Ok'
        else 
            return 'Error'
    }

    return {
        post: _post,
    }
});
