/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope
 * author: Erick Munekata
 * Date: 29/11/2019
 * Version: 1.0
 */

define(['N/record', 'N/currentRecord', 'N/ui/dialog', 'N/ui/message', 'N/https', '../Models/ACS_Braspag_MaintenanceBillet_MCL', '../Models/ACS_Braspag_Integration_CTS', 'N/url', 'N/runtime'],

    function (record, currentct, dialog, message, https, mcl, cts, url, runtime) {

        var btnClick = false;

        function fieldChanged(context) {
            // var sublist = context.sublistId,
            //     field = context.fieldId;
            // if (sublist == cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id &&
            //     field == cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS.braspagbillet.id){
            //     var ct = context.currentRecord;
            //     var flag = ct.getCurrentSublistValue({
            //         sublistId: sublist,
            //         fieldId: field
            //     });
            //     if (flag){
            //         var id = ct.getCurrentSublistValue({sublistId: sublist, fieldId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS.id.id});
            //        mcl.updateInvoice(id, context, btnClick);
            //     }
            // }
        }

        function selectAllLines() {
            var ct = currentct.get();
            var linesInvoice = 0, linesInstallment = 0, isbraspag, invoices = 0, install = 0, lineList = [], installs = [], installId, ready, url;

            linesInvoice = ct.getLineCount(cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id)
            linesInstallment = ct.getLineCount(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id)
            if (linesInvoice > 0 || linesInstallment > 0) {
                var option1 = {
                    label: 'Faturas',
                    value: 1
                };
                var option2 = {
                    label: 'Parcelas',
                    value: 2
                };
                var option3 = {
                    label: 'Cancelar',
                    value: 3
                };
                var dialog1 = {
                    title: 'Alerta',
                    message: 'Por favor, selecione de qual das tabelas você deseja selecionar todas as linhas:',
                    buttons: [option1, option2, option3]
                };

                dialog.create(dialog1)
                    .then(function (result) {
                        if (result === 1) {
                            for (var i = 0; i < linesInvoice; i++) {
                                ct.selectLine({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, line: i });
                                ct.setCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS.braspagbillet.id, value: true });
                                isbraspag = ct.getCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS.braspagbillet.id });
                                if (!isbraspag) {
                                    ++invoices;
                                    lineList.push(i);
                                }
                            }

                        } else if (result === 2) {
                            for (var i = 0; i < linesInstallment; i++) {
                                ct.selectLine({ sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id, line: i });
                                ct.setCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS.selecao.id, value: true });
                                installId = ct.getCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS.id.id });
                                installs.push(installId)
                                ++install;
                            }

                        } else {
                            return
                        }
                    }).catch(function (e) { });
            }
        }

        function unselectAllLines() {
            var ct = currentct.get();
            var linesInvoice = 0, linesInstallment = 0, isbraspag, invoices = 0, install = 0, lineList = [], installs = [], installId, ready, url;
            linesInvoice = ct.getLineCount(cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id)
            linesInstallment = ct.getLineCount(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id)
            for (var i = 0; i < linesInvoice; i++) {
                ct.selectLine({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, line: i });
                ct.setCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS.braspagbillet.id, value: false });
                isbraspag = ct.getCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS.braspagbillet.id });
                if (!isbraspag) {
                    ++invoices;
                    lineList.push(i);
                }
            }
            for (var i = 0; i < linesInstallment; i++) {
                ct.selectLine({ sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id, line: i });
                ct.setCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS.selecao.id, value: false });
                installId = ct.getCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS.id.id });
                installs.push(installId)
                ++install;
            }

        }

        function changeBillet() {
            var ct = currentct.get();
            var linesInvoice = 0, isbraspag, invoices = 0, lineList = [], ready, url;

            linesInvoice = ct.getLineCount(cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id)
            for (var i = 0; i < linesInvoice; i++) {
                ct.selectLine({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, line: i });
                isbraspag = ct.getCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS.braspagbillet.id });
                if (isbraspag) {
                    ++invoices;
                    lineList.push(i);
                }
            }
            if (invoices > 0) {
                var msg = invoices > 1 ? cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.UPDATE_INVOICES : cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.UPDATE_SINGLE_INVOICE;
                var option1 = {
                    label: 'Sim',
                    value: true
                };
                var option2 = {
                    label: 'Não',
                    value: false
                };
                var dialog1 = {
                    title: cts.MAINTENANCE_BILLET_ST.CONFIRM_SUBMIT_ALL_INVOICES.title,
                    message: cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.UPDATE_INVOICES_CONFIRM + invoices + msg,
                    buttons: [option1, option2]
                };
                dialog.create(dialog1)
                    .then(function (result) {
                        if (result === true) {
                            btnClick = true;
                            for (var i = 0; i < invoices; i++) {
                                ct.selectLine({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, line: lineList[i] });
                                var contextNew = {}
                                contextNew.line = lineList[i]
                                contextNew.sublistId = cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id
                                contextNew.fieldId = cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS.braspagbillet.id
                                var id = ct.getCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INVOICE_SUBLIST.FIELDS.id.id });
                                mcl.updateInvoice(id, contextNew, btnClick);

                            }
                            btnClick = false;
                            dialog.alert({
                                title: "Alteração de Boleto para a Braspag.",
                                message: "Faturas enviadas para alteração com sucesso. Clique em Ok para reiniciar esse formulário."
                            })
                                .then(function () {
                                    clearFilters()
                                })
                        }
                    }).catch(function (e) { });
            }
            else
                dialog.alert(cts.MAINTENANCE_BILLET_ST.ALERT_NO_INVOICES_TO_UPDATE).then(function (result) { console.log('No Results'); }).catch(function (failure) { console.log('Failure') });
        }

        function sendBillet() {
            var ct = currentct.get();
            var linesInstallment = 0, install = 0, installs = [], installId, ready, url, selected;

            linesInstallment = ct.getLineCount(cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id)
            for (var i = 0; i < linesInstallment; i++) {
                ct.selectLine({ sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id, line: i });
                selected = ct.getCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS.selecao.id });
                if (selected) {
                    installId = ct.getCurrentSublistValue({ sublistId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.METADATA.id, fieldId: cts.MAINTENANCE_BILLET_ST.INSTALLMENT_SUBLIST.FIELDS.id.id });
                    installs.push(installId)
                    ++install;
                }
            }
            log.debug('Entrou install', ct.getValue('custpage_urlrest'))

            if (install > 0) {
                var msg = install > 1 ? cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.UPDATE_INSTALLMENT : cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.UPDATE_SINGLE_INSTALLMENT;
                var option1 = {
                    label: 'Sim',
                    value: true
                };
                var option2 = {
                    label: 'Não',
                    value: false
                };
                var dialog1 = {
                    title: cts.MAINTENANCE_BILLET_ST.CONFIRM_SUBMIT_ALL_INSTALLMENTS.title,
                    message: cts.MAINTENANCE_BILLET_ST.CLIENT_MESSAGES.UPDATE_INSTALLMENT_CONFIRM + install + msg,
                    buttons: [option1, option2]
                };
                dialog.create(dialog1)
                    .then(function (result) {
                        if (result) {
                            urlw = window.location.hostname
                            ready = https.post.promise({
                                // url: 'https://' + urlw + '/app/site/hosting/restlet.nl?script=1621&deploy=2',
                                // url: 'https://' + urlw + '/app/site/hosting/restlet.nl?script=2215&deploy=1',
                                url: 'https://' + urlw + ct.getValue('custpage_urlrest'),
                                body: installs,
                            })
                            dialog.alert({
                                title: "Envio de Parcelas para a Braspag.",
                                message: "Parcelas enviadas com sucesso. Clique em Ok para reiniciar esse formulário."
                            })
                                .then(function () {
                                    clearFilters()
                                })
                        } else {
                            return
                        }
                    })
                    .catch(function (e) {
                        log.debug('Err', e)
                        return
                    })
                // if (ready === 1) {
                //     mcl.atualizarLinhas(installs, currentct)
                //     var messageComplete = message.create({
                //         title: "Finalizado",
                //         type: message.Type.CONFIRMATION
                //     })
                //     messageComplete.show({ duration: 50000 });
                // } else {
                //     var messageError = message.create({
                //         title: "Erro de processamento",
                //         type: message.Type.ERROR
                //     })
                //     messageError.show({ duration: 50000 });
                // }
                // }).catch(function (e) {
                //     log.error('sendBillet', e)
                // });
            }
            else
                dialog.alert(cts.MAINTENANCE_BILLET_ST.ALERT_NO_INSTALLMENTS_TO_SEND).then(function (result) { console.log('No Results'); }).catch(function (failure) { console.log('Failure') });
        }

        // dm_37 Início
        function clearFilters() {
            log.debug('Entrou Limpa Filtros')
            try {
                var params = ""
                window.onbeforeunload = function () { }
                window.location.replace(
                    url.resolveScript({
                        scriptId: 'customscript_acs_braspagmainbillet_st',
                        deploymentId: 'customdeploy_acs_braspagmainbillet_st',
                        returnExternalURL: false
                    })
                )
            } catch (error) {
                alert(error.message)
            }
        }
        // dm_37 Fim

        return {
            fieldChanged: fieldChanged,
            selectAllLines: selectAllLines,
            unselectAllLines: unselectAllLines,
            changeBillet: changeBillet,
            sendBillet: sendBillet,
            clearFilters: clearFilters,
        }
    }
);