/**
 * ACS_Braspag_InvoiceSender_MR.js
 *@NApiVersion 2.0
 *@NScriptType MapReduceScript
 *@author felipema90
 *
 */

define(['N/search', '../Models/ACS_Braspag_Integration_MSR', "../Models/ACS_Braspag_Integration_CTS", '../Api/ACS_Braspag_API' ],

    function (search, msr, cts, braspag_api) {

        function getInputData() {
            log.audit('getInputData', '...');
            try{

                return search.load({id:"customsearch_acs_braspaginteginvoicecomm"})
            }catch(e){
                log.error('getInputData', e);
            }
        }

        function map(context) {

            try{
                log.audit('Map', 'Starting Invoice Sender...');
                var data = JSON.parse(context.value);
                
                /**
                 * @example {
                "recordType": "invoice",
                "id": "975826",
                "values": {
                    "entity": {
                    "value": "901992",
                    "text": "GESTORA DE INTELIGÊNCIA DE CRÉDITO"
                    },
                    "amount": "2341.56",
                    "custbody_acs_braspag_cardtoken_ds": "53d15602-ee43-4856-a40f-c308024cc23a",
                    "custrecord_o2s_cod_pagto_l_forma_pagto.CUSTBODY_ACS_OPPORTUNITY_PAYM_COND_LS": {
                    "value": "3",
                    "text": "03 - Cartão de Crédito"
                    },
                    "subsidiary": {
                    "value": "2",
                    "text": "Controladora : Gestora de Inteligência de Crédito S.A."
                    },
                    "custbody_acs_braspag_cardbrand_ds": "Visa",
                    "custrecord_sit_parcela_d_dt_vencimen.CUSTRECORD_SIT_PARCELA_L_TRANSACAO": "12/09/2020",
                    "formulanumeric": "6"
                }
                }
                 */
                log.audit('Dados', data);

                var provider = msr.getProvider(data.values.subsidiary.value, data.values["custrecord_o2s_cod_pagto_l_forma_pagto.CUSTBODY_ACS_OPPORTUNITY_PAYM_COND_LS"].value);
                log.audit('getProvider', provider);
                if(typeof provider === "object"){
                    var paymentBody = msr.getBraspagPaymentData({
                        transactionId: data.id,
                        customer: data.values.entity.text,
                        amount: data.values.amount,
                        cardToken: data.values[cts.TRANSACTION_FIELDS.CARDTOKEN],
                        cardBrand: data.values[cts.TRANSACTION_FIELDS.CARDBRAND],
                        operationType: cts.PAYMENT_CONDITION_MAP[ data.values["custrecord_o2s_cod_pagto_l_forma_pagto.CUSTBODY_ACS_OPPORTUNITY_PAYM_COND_LS"].value],
                        provider:provider,
                        capture:true,
                        withCardToken:true,
                        operationInstallments: data.values.formulanumeric
                    });
                    log.debug("paymentBody", paymentBody)
                    var requestTime = new Date();
                    var newPayment = braspag_api.newPayment(JSON.stringify(paymentBody));
                    newPayment.responseTime = new Date();
                    newPayment.requestTime = requestTime;
                    newPayment.invoice = data.id;
                    newPayment.subsidiary = data.values.subsidiary;
                    log.audit('newPayment', JSON.stringify(newPayment));
                    msr.processNewPayment(newPayment, provider);
                }else{
                    throw cts.ERROR.PROVIDER_NOT_FOUND + data.id;
                }
            }catch(e){
                log.error('map error', e);
                throw e;
            }
        }
        return {
            getInputData: getInputData,
            map: map
        };

    });
