/**
 * ACS_Braspag_API.js
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

define (['N/https', './ACS_Braspag_CTS', 'N/config'],
    /**
     * @class ACS_Braspag_API
     * @param {https} https
     * @param {ACS_Braspag_CTS} Acs_Braspag_CTS
     */
    function ( https, constants, config) {
        var MERCHANT_ID;
        var MERCHANT_KEY;
        /**
        * @function init - initialize the module
        * @returns {void}
        */
        function init() {
            if(!initialized()){
                var genPref     = config.load({ type: config.Type.COMPANY_PREFERENCES});
                MERCHANT_ID     = genPref.getValue({fieldId: constants.GENERAL_PREFERENCES.MERCHANT_ID});
                MERCHANT_KEY    = genPref.getValue({fieldId: constants.GENERAL_PREFERENCES.MERCHANT_KEY});
                if( !MERCHANT_KEY || !MERCHANT_ID ) throw constants.ERRORS["BRASPAG_MERCHANT_CREDENTIALS_MISSING"];
            }
        }
        /**
        * @function initialized - check if module has initialized
        * @returns {Boolean} - true if module is initialized
        */
        function initialized() {
            return typeof MERCHANT_ID !== 'undefined' && typeof MERCHANT_KEY !== 'undefined';
        }
        /**
         * @function makeRequest - make a request to a endpoint of Braspag
         * @param {string} method [required] - method http: get | post | put.
         * @param {string} endPoint [required] - endpoint location.
         * @param {string} body [required] - request content.
         * @returns {string} response - response from Braspag.
         */
        function makeRequest(method, endPoint, body) {
            var requestData = BraspagRequest(endPoint, body);
            var responseData =  https[method](requestData);
            return {
                request:requestData,
                response:responseData
            };
        }
        /**
         *  @class BraspagRequest
         *  @type {Object}
         *  @property {String} endPoint request endPoint
         *  @property {Object} body request body
         *  @property {Object} headers headers of request
         */
        function BraspagRequest(endPoint, body) {
            init();
            if(!!endPoint && !!MERCHANT_KEY && !!MERCHANT_ID ){
                return {
                    url: endPoint, //"http://ptsv2.com/t/edx17-1560317801/post",//endPoint,
                    body: body,
                    headers: {
                        'Content-Type': 'application/json',
                        'MerchantId':MERCHANT_ID,
                        'MerchantKey':MERCHANT_KEY
                    },
                };
            }else{
                throw constants.ERRORS["INVALID_BRASPAG_REQUEST_HEADER"];
            }
        }

        function SalesObject(operationType, withCardToken, operationInstallments){
            this.MerchantOrderId                        = "";
            this.Customer                               = {};
            this.Customer.Name                          = "";
            this.Customer.Identity                      = "";  // numero do documento
            this.Customer.IdentityType                  = "";  //tipo do documento
            this.Customer.Address                       = {};
            this.Customer.Address.Street                = "";
            this.Customer.Address.Number                = "";
            this.Customer.Address.Complement            = "";
            this.Customer.Address.ZipCode               = "";
            this.Customer.Address.City                  = "";
            this.Customer.Address.State                 = "";
            this.Customer.Address.Country               = "";
            this.Customer.Address.District              = ""; //bairro
            this.Payment                                = {};
            this.Payment.Provider                       = "";
            this.Payment.Type                           = "";
            this.Payment.Amount                         = 0.1;
            //Cartão de Crédito ou Cartão de Dédito
            if( operationType === "CreditCard" || operationType === "DebitCard" ){
                this.Customer.Email                         = "";
                this.Customer.Birthdate                     = "";  //yyyy-mm-dd
                this.Customer.DeliveryAddress               = {};
                this.Customer.DeliveryAddress.Street        = "";
                this.Customer.DeliveryAddress.Number        = "";
                this.Customer.DeliveryAddress.Complement    = "";
                this.Customer.DeliveryAddress.ZipCode       = "";
                this.Customer.DeliveryAddress.City          = "";
                this.Customer.DeliveryAddress.State         = "";
                this.Customer.DeliveryAddress.Country       = "";
                this.Customer.DeliveryAddress.District      = ""; //bairro
                this.Payment.Currency                       = "";
                this.Payment.Country                        = "";
                if( withCardToken ){
                    this.Payment[operationType]                 = {};
                    this.Payment[operationType].CardToken       = "";
                    this.Payment[operationType].Brand           = "";
                }else{
                    this.Payment[operationType]                 = {};
                    this.Payment[operationType].CardNumber      = "";
                    this.Payment[operationType].Holder          = "";
                    this.Payment[operationType].ExpirationDate  = "";
                    this.Payment[operationType].SecurityCode    = "";
                    this.Payment[operationType].Brand           = "";
                    this.Payment[operationType].SaveCard        = true;
                }
                this.Payment.Installments                   = operationInstallments || 1;
                this.Payment.Interest                       = "ByMerchant";
                this.Payment.Capture                        = false;
                this.Payment.Authenticate                   = false;
                this.Payment.Recurrent                      = false;
                this.Payment.SoftDescriptor                 = "";
                this.Payment.DoSplit                        = false;
                this.Payment.Credentials                    = {};
                this.Payment.Credentials.code               = "";
                this.Payment.Credentials.key                = "";
                this.Payment.Credentials.password           = "";
                this.Payment.Credentials.username           = "";
                this.Payment.Credentials.signature          = "";
            }
            //BOLETO
            else{
                 // this.Payment[operationType]                    = {};
                 // this.Payment[operationType].BoletoNumber       = "";
                 // this.Payment[operationType].Assignor           = "";
                 // this.Payment[operationType].Demonstrative      = "";
                 this.Payment.ExpirationDate     = "";
                 // this.Payment[operationType].Identification     = "";
                 // this.Payment[operationType].Instructions       = "";
                 // this.Payment[operationType].DaysToFine         = "";
                 // this.Payment[operationType].FineRate           = "";
                 // this.Payment[operationType].FineAmount         = "";
                 // this.Payment[operationType].DaysToInterest     = "";
                 // this.Payment[operationType].InterestRate       = "";
                 // this.Payment[operationType].InterestAmount     = "";
            }
        }

        /**
         * @function newPayment - method to create a transaction on  braspag system
         * @param {string} body [required] - request content.
         * @returns {string} response - response from Braspag.
        */
        function newPayment( body ) {
            return makeRequest('post', constants.ENDPOINT_TRANSACTIONAL + 'v2/sales/', body );
        }
        /**
         * @function voidPayment - method to void a transaction on braspag system
         * @param {string} paymentId [required] - payment id to void
         * @param {string} body [required] - request content
         * @returns {string} response - response from Braspag.
         */
        function voidPayment( paymentId, body ) {
            var parameters = '';
            for (att in body){ parameters += att +'='+body[att]+'&'; }
            return makeRequest('put', constants.ENDPOINT_TRANSACTIONAL + 'v2/sales/'+paymentId+'/void?'+parameters );
        }
        /**
         * @function getPayment - return a transaction of braspag system
         * @param {string} paymentId [required] - payment id to get
         * @returns {string} response - response from Braspag.
         */
        function getPayment( paymentId ) {
            return makeRequest('get', constants.ENDPOINT_QUERY + 'v2/sales/'+paymentId );
        }
    return {
        SalesObject:  SalesObject,
        newPayment  : newPayment,
        voidPayment : voidPayment,
        getPayment  : getPayment
    };
});
