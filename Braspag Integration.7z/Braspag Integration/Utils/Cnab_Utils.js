/**
 * Cnab_Utils.js
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

define ([],
    /**
    * @class Cnab_Utils
    */
    function () {

        /**
        * @function isNull - check if a value is null
        * @param {Object} fieldValue - the value to check
        * @returns {Boolean} - true if value is null
        */
        function isNull(fieldValue) {
        	return (fieldValue == null || fieldValue == undefined || fieldValue == '');
        }

        /**
        * @function getString - convert the value to a string
        * @param {Object} v - the value to convert
        * @returns {String} - value in string
        */
        function getString(v) {
        	if((v + '').length == 1) {
        		return '0' + v;
        	} else {
        		return v;
        	}
        }

        /**
        * @function removeAccents - remove accents from a text
        * @param {String} strToReplace - the value to remove accents
        * @returns {String} - value without accents
        */
        function removeAccents(strToReplace) {
        	var newString = '';
        	if( strToReplace ) {
        		var withAccent = "áàãâäéèêëíìîïóòõôöúùûüçÁÀÃÂÄÉÈÊËÍÌÎÏÓÒÕÖÔÚÙÛÜÇºª";
        		var unaccented = "aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC  ";
        		for(var i = 0; i < strToReplace.length; i++) {
        		    if(withAccent.indexOf(strToReplace.charAt(i)) != -1) {
        		    	newString += unaccented.substr(withAccent.search(strToReplace.substr(i, 1)), 1);
        		    } else {
        		    	newString += strToReplace.substr(i, 1);
        		    }
        		}
        	}
        	return newString;
        }

        /**
        * @function padLeft - add length to a string with a left padding of zeros
        * @param {String} str - string to receive the padding
        * @param {String} zeros - final length
        * @returns {String} - value whith a padding of zeros
        */
        function padLeft(str, zeros) {
        	var pad = '';
        	for(var i = 0; i < zeros; i++) {
        		pad += '0';
        	}
        	str = str.toString();
        	return pad.substring(0, pad.length - str.length) + str;
        }

        /**
        * @function replaceAll - replace ocurrences if a string inside another string
        * @param {String} str - string replace the ocurrences
        * @param {String} find - the ocurrence to replace
        * @param {String} replace - string to replace for
        * @returns {String} - value with value replaced
        */
        function replaceAll(str, find, replace) {
        	if(str.indexOf(find) != -1) {
        		return str.replace(new RegExp('\\' + find, 'gi'), replace);
        	}
        	return str;
        }

        /**
        * @function formatCurrency - format currency
        * @param {String} value - number to format
        * @param {String} n - internal process data
        * @param {String} x - internal process data
        * @param {String} s - internal process data
        * @param {String} c - dot char of currency
        * @returns {String} - formated currency
        */
        function formatCurrency(value, n, x, s, c) {
        	var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')';
        	var num = value.toFixed(Math.max(0, n));
        	return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + s);
        }

        /**
        * @function mod11BillingSantander400 - create a security code from a bank branch
        * @param {String} number - bank branch number
        * @returns {String} - security digit
        */
        function mod11BillingSantander400(number) {
        	number = number.replace(/[^0-9]/g, '');

        	var base = 9;
        	var r = 0;
        	var sum = 0;
        	var factor = 2;

        	for(var i = number.length - 1; i >= 0; i--) {
        		var partial = parseInt(number[i]) * factor;
        		sum += partial;
        		if(factor == base)
        			factor = 1;
        		factor++;
        	}
        	if(r == 0) {
        		sum *= 10;
        		var digit = sum % 11;
        		return digit == 10 ? 0 : digit;
        	}
        	else if(r == 1)
        		return sum % 11;
        }

        function formatValue(mask, value) {
        	var booleanMask;
        	var position = 0;
        	var newValue = "";

        	var exp = /\-|\.|\/|\(|\)| /g;
        	var onlyNumber = value.toString().replace(exp, "");
        	var maskSize = onlyNumber.length;

        	for (i = 0; i <= maskSize; i++) {
        		booleanMask  = ((mask.charAt(i) == "-") || (mask.charAt(i) == ".") || (mask.charAt(i) == "/"));
        		booleanMask  = booleanMask || ((mask.charAt(i) == "(") || (mask.charAt(i) == ")") || (mask.charAt(i) == " "));

        		if(booleanMask) {
        			newValue += mask.charAt(i);
        			maskSize++;
        		} else {
        			newValue += onlyNumber.charAt(position);
        			position++;
        		}
        	}
        	return newValue;
        }

        function guid() {
        	function s4() {
        		return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        	}
        	return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
        }

        function decode64(input) {
        	var output = "";

        	if(input) {
        		var keyStr = "ABCDEFGHIJKLMNOP" + "QRSTUVWXYZabcdef" + "ghijklmnopqrstuv" + "wxyz0123456789+/" + "=";
        		var chr1, chr2, chr3 = "";
        		var enc1, enc2, enc3, enc4 = "";
        		var i = 0;

        		// remove all characters that are not A-Z, a-z, 0-9, +, /, or =
        		var base64test = /[^A-Za-z0-9\+\/\=]/g;
        		if (base64test.exec(input)) {
        			alert("There were invalid base64 characters in the input text.\n" +
        			"Valid base64 characters are A-Z, a-z, 0-9, '+', '/',and '='\n" +
        			"Expect errors in decoding.");
        		}
        		input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

        		do {
        			enc1 = keyStr.indexOf(input.charAt(i++));
        			enc2 = keyStr.indexOf(input.charAt(i++));
        			enc3 = keyStr.indexOf(input.charAt(i++));
        			enc4 = keyStr.indexOf(input.charAt(i++));

        			chr1 = (enc1 << 2) | (enc2 >> 4);
        			chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
        			chr3 = ((enc3 & 3) << 6) | enc4;

        			output = output + String.fromCharCode(chr1);

        			if (enc3 != 64) {
        				output = output + String.fromCharCode(chr2);
        			}
        			if (enc4 != 64) {
        				output = output + String.fromCharCode(chr3);
        			}

        			chr1 = chr2 = chr3 = "";
        			enc1 = enc2 = enc3 = enc4 = "";

        		} while (i < input.length);
        	}

        	return unescape(output);
        }

        return {
            isNull: isNull,
            getString: getString,
            removeAccents: removeAccents,
            padLeft: padLeft,
            replaceAll: replaceAll,
            formatCurrency: formatCurrency,
            mod11BillingSantander400: mod11BillingSantander400,
            formatValue: formatValue,
            guid: guid,
            decode64: decode64
        };
    });
