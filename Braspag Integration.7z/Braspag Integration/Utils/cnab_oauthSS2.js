//this information is supplied during the creation of your application and related linking to the role
/**
 *
 * @NModuleScope public
 *
 **/

define([], function() {

   function getKey(tokenId, tokenSecret, accountId) {
      if (!(this instanceof getKey)) {
         return new getKey(tokenId, tokenSecret, accountId);
      }

      return {
         consumer: {
            public: 'ecea4deccf97db8760e7e8d168a10f59c79670f6594275f0c90fcab6c0b14f32',
            secret: '96ba3730ac8a8e361322dac9d3184d0e9edb090f464c0b310367fff1ec7539cc'
         },
         token: {
            public: tokenId,
            secret: tokenSecret
         },
         realm: accountId
      };

   }

   return {

		getKey:getKey

	};

});
