/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType ClientScript
 */

import { EntryPoints } from "N/types";
import log from "N/log";

export function pageInit(): void { }

export function fieldChanged(ctx: EntryPoints.Client.fieldChangedContext): void {
    check(ctx);
}

export function saveRecord(ctx: EntryPoints.Client.saveRecordContext): void {
    check(ctx);
}

function check(ctx: any):any {
    try {
        if (ctx.fieldId !== 'custbody_quod_id_tran_pasta_projuris') return true;
        if (!isNaN(ctx.currentRecord.getValue({ fieldId: 'custbody_quod_id_tran_pasta_projuris' }))) return true;

        alert('O campo Pasta jurídico deve ser numérico!');
        ctx.currentRecord.setValue({ fieldId: 'custbody_quod_id_tran_pasta_projuris', value: '' });
        return false;
    } catch (error) {
        log.error({ title: "Erro check", details: error });
        throw error;
    }
}
