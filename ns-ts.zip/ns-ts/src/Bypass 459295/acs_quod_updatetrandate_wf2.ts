/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType WorkflowActionScript
 * @author Alexandre J. C. <alexandre.correa@quod.com.br>
 * @date 26/12/2022
 * @description - Bypass do script criado pela ACS para debug.
 */

import log from "N/log";
import search from "N/search";
import record from "N/record";

export function onAction(context: any): void {
    try {
        let payment = context.newRecord,
            paymentDate = payment.getValue({ fieldId: 'trandate' }),
            lineNumber = payment.findSublistLineWithValue({ sublistId: 'apply', fieldId: 'apply', value: true }),
            invoiceId = payment.getSublistValue({ sublistId: 'apply', fieldId: 'internalid', line: lineNumber });

        log.audit({ title: 'beforeSubmit', details: 'paymentDate: ' + paymentDate });
        log.audit({ title: 'beforeSubmit', details: 'invoiceId: ' + invoiceId });

        if (!invoiceId) return;
        let invoice = record.load({ type: record.Type.INVOICE, id: invoiceId, isDynamic: true }),
            billingCycleId = invoice.getValue({ fieldId: 'custbody_acs_opportunity_cycle_ls' });

        if (!billingCycleId) return;
        if (!!isPrePaid(billingCycleId) && !blockUpdate(invoiceId)) {
            disallowDeletion(invoiceId);
            invoice.setValue({ fieldId: 'trandate', value: paymentDate });
            invoice.save({ ignoreMandatoryFields: true });
            log.audit({ title: 'beforeSubmit', details: 'invoice updated' });
        }
    } catch (e) {
        log.audit({ title: 'beforeSubmit', details: e });
        throw e;
    }
}

function isPrePaid(billingCycleId: any) {
    let cycleType: any = search.lookupFields({
        type: 'customrecord_acs_invoice_cycle',
        id: billingCycleId,
        columns: ['custrecord_acs_invoice_type_ls']
    })['custrecord_acs_invoice_type_ls'];
    //log.audit({ title: 'isPrePaid', details: 'cycleType: ' + JSON.stringify(cycleType) });
    // 1 = Recorrência (pré pago)
    return !!cycleType && cycleType.length > 0 && cycleType[0].value == 1;
}

function blockUpdate(invoiceId: any) {
    var mySearch = search.create({
        type: 'customrecord_acs_installment',
        filters: [{
            name: 'custrecord_acs_transaction_ls',
            operator: search.Operator.ANYOF,
            values: invoiceId
        }, {
            name: 'custrecord_acs_cnabstatus_ls',
            operator: search.Operator.ANYOF,
            values: [1, 6, 14, 8, 2] // Enviado, Recebido, Solicitação de cancelamento, Cancelado, Pago
        }]
    });
    var block = mySearch.runPaged().count > 0;
    if (!!block) log.audit({
        title: 'blockUpdate',
        details: 'Não é possivel atualizar a fatura pois há parcelas do cnab com status Enviado, Recebido, Pago parcialmente, ' +
            'Solicitação de cancelamento, Cancelado ou Pago'
    });
    return block;
}

function disallowDeletion(invoiceId: any) {
    search.create({
        type: 'customrecord_sit_parcela',
        filters: [{
            name: 'custrecord_sit_parcela_l_transacao',
            operator: search.Operator.ANYOF,
            values: invoiceId
        }],
        columns: [{
            name: 'custrecord_sit_parcela_i_status'
        }]
    }).run().each(function (result) {
        record.submitFields({
            type: 'customrecord_sit_parcela',
            id: result.id,
            values: {
                'custrecord_sit_parcela_t_perm_exclus': false
            }
        });
        log.audit({ title: 'disallowDeletion', details: 'Installment updated: ' + result.id });
        return true;
    });
}