/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType WorkflowActionScript
 * @author Alexandre J. C. <alexandre.correa@quod.com.br>
 * @date 26/12/2022
 * @description - Bypass do script criado pela ACS para debug.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log", "N/runtime", "N/search", "N/record"], function (require, exports, log_1, runtime_1, search_1, record_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onAction = void 0;
    log_1 = __importDefault(log_1);
    runtime_1 = __importDefault(runtime_1);
    search_1 = __importDefault(search_1);
    record_1 = __importDefault(record_1);
    function onAction(context) {
        try {
            var ctx = runtime_1.default.executionContext;
            log_1.default.audit({ title: 'beforeSubmit', details: 'executionContext: ' + ctx });
            var payment = context.newRecord, paymentDate = payment.getValue({ fieldId: 'trandate' }), lineNumber = payment.findSublistLineWithValue({ sublistId: 'apply', fieldId: 'apply', value: true }), invoiceId = payment.getSublistValue({ sublistId: 'apply', fieldId: 'internalid', line: lineNumber });
            log_1.default.audit({ title: 'beforeSubmit', details: 'paymentDate: ' + paymentDate });
            log_1.default.audit({ title: 'beforeSubmit', details: 'invoiceId: ' + invoiceId });
            if (!invoiceId)
                return;
            var invoice = record_1.default.load({ type: record_1.default.Type.INVOICE, id: invoiceId, isDynamic: true });
            var billingCycleId = invoice.getValue({ fieldId: 'custbody_acs_opportunity_cycle_ls' });
            log_1.default.audit({ title: 'beforeSubmit', details: 'billingCycleId: ' + billingCycleId });
            if (!billingCycleId)
                return;
            if (!!isPrePaid(billingCycleId) && !blockUpdate(invoiceId)) {
                disallowDeletion(invoiceId);
                invoice.setValue({ fieldId: 'trandate', value: paymentDate });
                invoice.save({ ignoreMandatoryFields: true });
                log_1.default.audit({ title: 'beforeSubmit', details: 'invoice updated' });
            }
        }
        catch (e) {
            log_1.default.audit({ title: 'beforeSubmit', details: e });
            throw e;
        }
    }
    exports.onAction = onAction;
    function isPrePaid(billingCycleId) {
        var cycleType = search_1.default.lookupFields({
            type: 'customrecord_acs_invoice_cycle',
            id: billingCycleId,
            columns: ['custrecord_acs_invoice_type_ls']
        })['custrecord_acs_invoice_type_ls'];
        log_1.default.audit({ title: 'isPrePaid', details: 'cycleType: ' + JSON.stringify(cycleType) });
        // 1 = Recorrência (pré pago)
        return !!cycleType && cycleType.length > 0 && cycleType[0].value == 1;
    }
    function blockUpdate(invoiceId) {
        var mySearch = search_1.default.create({
            type: 'customrecord_acs_installment',
            filters: [{
                    name: 'custrecord_acs_transaction_ls',
                    operator: search_1.default.Operator.ANYOF,
                    values: invoiceId
                }, {
                    name: 'custrecord_acs_cnabstatus_ls',
                    operator: search_1.default.Operator.ANYOF,
                    values: [1, 6, 14, 8, 2] // Enviado, Recebido, Solicitação de cancelamento, Cancelado, Pago
                }]
        });
        var block = mySearch.runPaged().count > 0;
        if (!!block)
            log_1.default.audit({
                title: 'blockUpdate',
                details: 'Não é possivel atualizar a fatura pois há parcelas do cnab com status Enviado, Recebido, Pago parcialmente, ' +
                    'Solicitação de cancelamento, Cancelado ou Pago'
            });
        return block;
    }
    function disallowDeletion(invoiceId) {
        search_1.default.create({
            type: 'customrecord_sit_parcela',
            filters: [{
                    name: 'custrecord_sit_parcela_l_transacao',
                    operator: search_1.default.Operator.ANYOF,
                    values: invoiceId
                }],
            columns: [{
                    name: 'custrecord_sit_parcela_i_status'
                }]
        }).run().each(function (result) {
            record_1.default.submitFields({
                type: 'customrecord_sit_parcela',
                id: result.id,
                values: {
                    'custrecord_sit_parcela_t_perm_exclus': false
                }
            });
            log_1.default.audit({ title: 'disallowDeletion', details: 'Installment updated: ' + result.id });
            return true;
        });
    }
});
