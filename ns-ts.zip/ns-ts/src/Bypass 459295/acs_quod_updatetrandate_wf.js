/**
 * @NApiVersion 2.x
 * @NScriptType WorkflowActionScript
 * @scriptName acs_quod_updatetrandate_wf
 * @description
 * @author Mônica Schreiber <monica@activecs.com.br>
 * @license Copyright (c) 2019 Active Cloud Solutions
 * @date 22/11/2022
 */
define([
        'N/log',
        'N/record',
        'N/runtime',
        'N/search'
    ],
    function( log, record, runtime, search ) {

        /**
         * @description
         * @param {Object} context
         * @returns {void}
         */
        function onAction(context) {
            try {
                var ctx = runtime.executionContext;
                log.audit({title: 'beforeSubmit', details: 'executionContext: ' + ctx});
                var payment = context.newRecord;
                var paymentDate = payment.getValue({ fieldId: 'trandate' });
                var lineNumber = payment.findSublistLineWithValue({sublistId: 'apply', fieldId: 'apply', value: true});
                var invoiceId = payment.getSublistValue({sublistId: 'apply', fieldId: 'internalid', line: lineNumber});
                log.audit({title: 'beforeSubmit', details: 'paymentDate: ' + paymentDate});
                log.audit({title: 'beforeSubmit', details: 'invoiceId: ' + invoiceId});
                if (!invoiceId) return;
                var invoice = record.load({type: record.Type.INVOICE, id: invoiceId, isDynamic: true});
                var billingCycleId = invoice.getValue({ fieldId: 'custbody_acs_opportunity_cycle_ls' });
                log.audit({title: 'beforeSubmit', details: 'billingCycleId: ' + billingCycleId});
                if (!billingCycleId) return;
                if (!!isPrePaid(billingCycleId) && !blockUpdate(invoiceId)) {
                    disallowDeletion(invoiceId);
                    invoice.setValue({ fieldId: 'trandate', value: paymentDate });
                    invoice.save({ignoreMandatoryFields: true});
                    log.audit({title: 'beforeSubmit', details: 'invoice updated'});
                }
            } catch (e) {
                log.audit({title: 'beforeSubmit', details: e});
                throw e;
            }
        }

        function isPrePaid(billingCycleId) {
            var cycleType = search.lookupFields({
                type: 'customrecord_acs_invoice_cycle',
                id: billingCycleId,
                columns: ['custrecord_acs_invoice_type_ls']
            })['custrecord_acs_invoice_type_ls'];
            log.audit({title: 'isPrePaid', details: 'cycleType: '+JSON.stringify(cycleType)});
            // 1 = Recorrência (pré pago)
            return !!cycleType && cycleType.length > 0 && cycleType[0].value == 1;
        }

        function blockUpdate(invoiceId) {
            var mySearch = search.create({
                type: 'customrecord_acs_installment',
                filters: [{
                    name: 'custrecord_acs_transaction_ls',
                    operator: search.Operator.ANYOF,
                    values: invoiceId
                },{
                    name: 'custrecord_acs_cnabstatus_ls',
                    operator: search.Operator.ANYOF,
                    values: [1, 6, 15, 14, 8, 2] // Enviado, Recebido, Pago parcialmente, Solicitação de cancelamento, Cancelado, Pago
                }]
            });
            var block = mySearch.runPaged().count > 0;
            if (!!block) log.audit({
                title: 'blockUpdate',
                details: 'Não é possivel atualizar a fatura pois há parcelas do cnab com status Enviado, Recebido, Pago parcialmente, ' +
                    'Solicitação de cancelamento, Cancelado ou Pago'
            });
            return block;
        }

        function disallowDeletion(invoiceId) {
            search.create({
                type: 'customrecord_sit_parcela',
                filters: [{
                    name: 'custrecord_sit_parcela_l_transacao',
                    operator: search.Operator.ANYOF,
                    values: invoiceId
                }],
                columns: [{
                    name: 'custrecord_sit_parcela_i_status'
                }]
            }).run().each(function(result) {
                record.submitFields({
                    type: 'customrecord_sit_parcela',
                    id: result.id,
                    values: {
                        'custrecord_sit_parcela_t_perm_exclus': false
                    }
                });
                log.audit({title: 'disallowDeletion', details: 'Installment updated: '+result.id});
                return true;
            });
        }

        return {
            onAction: onAction
        };
    }
);
