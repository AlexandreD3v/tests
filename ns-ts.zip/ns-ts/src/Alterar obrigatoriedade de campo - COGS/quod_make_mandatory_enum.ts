/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

export enum messages{
    clienteAssMandatory = "O campo COGS - Cliente Associado é obrigatório para o item ",
    itemHasMandatoryField = "O campo COGS - Cliente Associado é obrigatório para este item!"
}