/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType ClientScript
 */

import { EntryPoints } from "N/types";
import log from "N/log";

export function pageInit(context: EntryPoints.Client.pageInitContext): void {
  try {
    if (context.mode != "view" && context.mode != "edit" && context.mode != "create") return;
    checkTipoContrato(context);
  } catch (e) {
    log.error("pageInit Erro", e);
  }
}

export function fieldChanged(
  context: EntryPoints.Client.fieldChangedContext
): void {
  try {
    let campoId = context.fieldId;
    if (campoId !== "custrecord_contratotipo") return;
    checkTipoContrato(context);
  } catch (e) {
    log.error("fieldChanged Erro", e);
  }
}

function checkTipoContrato(context: any) {
  try {
    let tipoDeContrato = context.currentRecord.getValue({
      fieldId: "custrecord_contratotipo",
    });
    log.error("field", tipoDeContrato)
    if (tipoDeContrato === "2" || tipoDeContrato === "1") {
      context.currentRecord.getField({
        fieldId: "custrecord_quod_cf_aprovacaocontrata",
      }).isDisabled = false;
    } else {
      context.currentRecord.getField({
        fieldId: "custrecord_quod_cf_aprovacaocontrata",
      }).isDisabled = true;
    }
  } catch (e) {
    log.error("func Erro", e);
  }
}
