/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType MapReduceScript
 */

import { EntryPoints } from "N/types";
import log from "N/log";
import * as mrFunctions from "./quod_mr_functions";


export function getInputData() {
    try {
        return mrFunctions.getDataMr();
    }
    catch (e) {
        log.error('ERRO getInputData', e);
        throw e;
    }
}

export function map(context: EntryPoints.MapReduce.mapContext) {
    try {
        log.debug('context', context);
        log.debug('idContract', context.key);
        mrFunctions.executeMapTest(context.key);
    }
    catch (error) {
        log.error("Erro Reduce", error);
        throw error;
    }
}

export function summarize(context: EntryPoints.MapReduce.summarizeContext): void {
    log.audit(context.toString() + ' Usage Consumed', context.usage);
    log.audit(context.toString() + ' Concurrency Number ', context.concurrency);
    log.audit(context.toString() + ' Number of Yields', context.yields);
}