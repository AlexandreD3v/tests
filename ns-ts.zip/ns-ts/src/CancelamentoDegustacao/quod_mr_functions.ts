/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

import log from "N/log";
import search from "N/search";
import runtime from "N/runtime";
import record from "N/record";

export function buildFilter(idParam: any, bypassFilter: any, contracttype: any, contractStatus: any) {
    try {
        let checkFiltroBypass = idParam > 0 ? ["idtext", "startswith", idParam] : ["custrecord_acs_quodcontr_end_dt", "onorbefore", "today"];
        log.debug('buildFilter idParam', idParam > 0 ? idParam : 'Vazio');
        log.debug('buildFilter bypassFilter', bypassFilter);
        log.debug('buildFilter contracttype', contracttype);
        log.debug('buildFilter contractStatus', contractStatus);
        log.debug('buildFilter checkFiltroBypass', checkFiltroBypass);

        if (bypassFilter && idParam > 0) return [checkFiltroBypass];

        let retFiltro = [
            ["custrecord_acs_quodcontr_type_ls", "anyof", contracttype],
            "AND",
            checkFiltroBypass,
            "AND",
            ["custrecord_acs_quodcontr_status_ls", "anyof", contractStatus]
        ];
        log.debug("filtro", retFiltro);
        return retFiltro;
    } catch (error) {
        log.error('buildFilter erro', error);
        throw error;
    }
}
export function getDataMr() {
    try {
        return search.create({
            type: "customrecord_acs_quodcontract",
            filters: buildFilter(
                runtime.getCurrentScript().getParameter({ name: 'custscript_quod_id_contrato' }),
                runtime.getCurrentScript().getParameter({ name: 'custscript_quod_bypass_filter' }),
                runtime.getCurrentScript().getParameter({ name: 'custscript_quod_tipo_contrato' }),
                runtime.getCurrentScript().getParameter({ name: 'custscript_quod_status' })
            ),
            columns: [
                search.createColumn({ name: "internalid", label: "ID interno" }),
                search.createColumn({ name: "name", sort: search.Sort.ASC, label: "ID" })
            ]
        });
    } catch (error) {
        log.error('getDataMr erro', error);
        throw error;
    }
}
export function executeMap(idContract: string) {
    try {
        let contractChange = record.create({ type: 'customrecord_acs_contract_change' })
            .setValue('custrecord_acs_contrchange_type_ls', 3)
            .setValue('custrecord_acs_contrchange_contract_ls', idContract)
            .setValue('custrecord_acs_contrchange_termreason_ls', runtime.getCurrentScript().getParameter({ name: 'custscript_quod_mot_resc' }))
            .setText('custrecord_acs_contrchange_obs_ds', runtime.getCurrentScript().getParameter({ name: 'custscript_quod_mot_obs' }).toString())
            .setValue('custrecord_quod_imported_plataform', 'F')
            .save(),
            contractChanged = record.load({ type: "customrecord_acs_quodcontract", id: idContract })
                .setValue('custrecord_acs_contr_cancreason_ls', runtime.getCurrentScript().getParameter({ name: 'custscript_quod_mot_resc' }))
                .setValue('custrecord_quod_checklist_migracao_ok', true)
                .setValue('custrecord_quod_imported_plataform', false)
                .save({ ignoreMandatoryFields: true });

        log.debug('map motObs', runtime.getCurrentScript().getParameter({ name: 'custscript_quod_mot_obs' }));
        log.debug('map rescisao', runtime.getCurrentScript().getParameter({ name: 'custscript_quod_mot_resc' }));
        log.debug('map contractChange', contractChange);
        log.debug('map contractChanged', contractChanged);
    } catch (error) {
        log.error('executeMap erro', error);
        throw error;
    }
}
export function executeMapTest(idContract: string) {
    try {
        let contractChange = {
            'type': 'customrecord_acs_contract_change',
            'custrecord_acs_contrchange_type_ls': runtime.getCurrentScript().getParameter({ name: 'custscript_quod_change_type' }),
            'custrecord_acs_contrchange_contract_ls': idContract,
            'custrecord_acs_contrchange_termreason_ls': runtime.getCurrentScript().getParameter({ name: 'custscript_quod_mot_resc' }),
            'custrecord_acs_contrchange_obs_ds': runtime.getCurrentScript().getParameter({ name: 'custscript_quod_mot_obs' }).toString(),
            'custrecord_quod_imported_plataform': 'F'
        },
            contractChanged = {
                'type': 'customrecord_acs_quodcontract',
                'id': idContract,
                'custrecord_acs_contr_cancreason_ls': runtime.getCurrentScript().getParameter({ name: 'custscript_quod_mot_resc' }),
                'custrecord_quod_checklist_migracao_ok': true,
                'custrecord_quod_imported_plataform': false
            };

        log.debug('map contractChange', contractChange);
        log.debug('map contractChanged', contractChanged);
    } catch (error) {
        log.error('executeMap erro', error);
        throw error;
    }
}

