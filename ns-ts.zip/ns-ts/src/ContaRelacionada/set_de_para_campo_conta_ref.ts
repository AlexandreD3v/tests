/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType MapReduceScript
 * 
 * MR para atualização do campo PLANO DE CONTAS REFERENCIAL 
 */

import { EntryPoints } from "N/types";
import * as contasIds from "./depara_objs_ids";
import search from "N/search";
import record from "N/record";
import log from "N/log";

export function getInputData() {//Fornece os dados para o estágio map
    try {
        return contasIds.idNS;//Envia para o estágio map o array com os ID com número da conta e conta referencial
    } catch (error) {//Tratativa de erro
        log.error('getInputData Erro', error);
        throw error;
    }
}

export function map(context: EntryPoints.MapReduce.mapContext): void {//Processa os dados obtidos no getInputData
    try {
        log.debug('map context.value', context.value);//Recebe um item do array de cada vez

        let accDetIds = JSON.parse(context.value), idRefRec = 0;//Converte para objeto
        search.create({//Busca id do registro de conta referencial
            type:'customrecord_quod_plano_ref_receita',
            filters:["custrecord_quod_num_conta_ref","is",accDetIds[1]]
        }).run().each((ret) =>{
            idRefRec = +ret.id;
            return true;
        });

        search.create({//Busca executada no registro de conta
            type: 'account',//Tipo do registro
            filters: ['number', search.Operator.IS, accDetIds[0]]//Filtro aplicado no campo número da conta
        }).run().each(function (accSr) {
            record.load({//Carrega o registro de conta pelo seu ID
                id: accSr.id,
                type: 'account'
            }).setValue({//Seta o valor da conta referencial na conta
                fieldId: 'custrecord_quod_plano_conta_ref',
                value: idRefRec
            }).save();//Salva a conta
            return true;
        });
    } catch (error) {//Tratativa de erro
        log.error('map Erro', error);
        throw error;
    }
}

export function summarize(context: EntryPoints.MapReduce.summarizeContext): void {//Indica a finalização do processo
    log.error('summarize', context);
}
