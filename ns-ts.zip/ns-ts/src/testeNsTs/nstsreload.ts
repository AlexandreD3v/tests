/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType Suitelet
 */

import { EntryPoints } from "N/types";
import search from 'N/search';

export function onRequest(context: EntryPoints.Suitelet.onRequestContext): void {
    
    let searchObj = search.create({
              type:"",
              columns:[""],
              filters:[""],
              filterExpression:[""],
              id:"",
              isPublic:,
              packageId:"",
              settings:[""],
              title:""
    });
    
    searchObj.run().each(function (obj){
              //TODO logic
              return true;
    })
}
