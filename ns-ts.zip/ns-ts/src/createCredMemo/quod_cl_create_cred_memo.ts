
/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType ClientScript
 * Autor: Alexandre J. C. <alexandre.correa@quod.com.br>
 *
 * Arquivo responsável pela função de direcionamento a criação de Memorando de crédito
 * e execução automática do calculo do imposto no memorando
 */

import { EntryPoints } from "N/types";
import log from "N/log";
import * as clFunctions from "./quod_create_cred_memo_functions";

export function pageInit(context: EntryPoints.Client.pageInitContext) {
    try {
        let isFromBtn = new URL(document.location.href).searchParams.get("fromButtonCredit") == 'T',
            isCredMemo = context.currentRecord.type == 'creditmemo',
            isCreate = context.mode == "copy";

        if (isFromBtn && isCredMemo && isCreate) {
            clFunctions.showCalcProccessMsg();
            clFunctions.generateMemo();
            clFunctions.runSaveButton();
        };
    }
    catch (error) {
        log.error('error', error);
    }
}



