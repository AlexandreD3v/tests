/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType WorkflowActionScript
 * Autor: Alexandre J. C. <alexandre.correa@quod.com.br>
 * 
 * Ação de fluxo de trabalho responsável pela criação de Memorando de crédito
 * e execução automática do calculo do imposto no memorando
 */

import { EntryPoints } from "N/types";
import log from "N/log";
import record from "N/record";

export function onAction(context: EntryPoints.WorkflowAction.onActionContext): void {
  try {
    let trsnRec = record.transform({
      fromId: context.newRecord.id,
      fromType: context.newRecord.type,
      toType: 'creditmemo',
      isDynamic: true
    });
    trsnRec.executeMacro({
      id: 'calculateTax',
      params: { asyncCalculation: true }
    });
    trsnRec.save();
  } catch (error) {
    log.error('error', error);
  }
}
