/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

import { isPaid } from "./quod_create_cred_memo_functions";
import { confirmBox } from "./quod_create_cred_memo_functions";
import log from "N/log";

export function goToMemo(recId: any) {
    try {
        if (isPaid() || !confirmBox()) return;
        let recUrl = '/app/accounting/transactions/custcred.nl?memdoc=0&transform=custinvc&e=T&id=',
            isFromButton = '&fromButtonCredit=T';
        window.location.href = recUrl + recId + isFromButton;
    }
    catch (error) {
        log.error('goToMemo erro', error);
    }
}