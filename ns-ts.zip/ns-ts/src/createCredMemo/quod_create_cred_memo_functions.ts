/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

import currentRecord from "N/currentRecord";
import log from "N/log";
import message from "N/ui/message";

export function generateMemo() {
    try {
        setTimeout(function () {
            currentRecord.get().executeMacro({
                id: 'calculateTax',
                //@ts-ignore
                params: {}
                //@ts-ignore
            });
        }, 3000);
    }
    catch (error) {
        log.error('generateMemo error', error);
    }
};
export function confirmBox() {
    try {
        return confirm('Esta transação já foi total ou parcialmente reembolsada. Se você criar outro reembolso, talvez tenha um reembolso excedente da venda. Clique em OK para continuar.')
    } catch (error) {
        log.error('confirmBox error', error);
        return false;
    }
};
export function showCalcProccessMsg() {
    try {
        message.create({
            type: message.Type.INFORMATION,
            duration: 3000,
            message: 'Aguarde o calculo dos impostos, o registro será salvo automáticamente.',
            title: 'Calculo de impostos'
        }).show();
    }
    catch (error) {
        log.error('showCalcProccessMsg error', error);
    }
};
export function runSaveButton() {
    try {
        setTimeout(function () {
            jQuery('#btn_multibutton_submitter').click();
        }, 3100);
    }
    catch (error) {
        log.error('runSaveButton error', error);
    }
};
export function isPaid() {
    try {
        //@ts-ignore
        return getFormElementViaFormName('main_form', 'balreadyrefunded').value == 'T' ? true : false;
    } catch (error) {
        log.error('runSaveButton error', error);
        throw error;
    }
};
