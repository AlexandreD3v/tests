/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType UserEventScript
 * Autor: Alexandre J. C. <alexandre.correa@quod.com.br>
 *
 * Arquivo responsável pelo botão de direcionamento a criação de Memorando de crédito
 * para a execução automática do calculo do imposto no memorando
 */

import { EntryPoints } from "N/types";
import log from "N/log";

export function beforeLoad(context: EntryPoints.UserEvent.beforeLoadContext): void {
    try {
        if (!context.newRecord.getValue({ fieldId: 'custbody_quod_provisao_receita' })) return;
        context.form.clientScriptModulePath = './quod_button_goToCredMemo_function.js';
        context.form.addButton({
            label: 'Estorno de provisão',
            functionName: 'goToMemo(' + context.newRecord.id + ')',
            id: 'custpage_quod_cred_memo'
        });
    } catch (error) {
        log.error('beforeLoad error', error)
        throw error;
    }
}
