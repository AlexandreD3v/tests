/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType UserEventScript
 * Author: Alexandre J. Corrêa - 04/11/2022
 */

import log from "N/log";
import runtime from "N/runtime";
import { EntryPoints } from "N/types";

export function beforeLoad(context: EntryPoints.UserEvent.beforeLoadContext): void {
    try {
        let idRole = 1069;
        //idUsrAJC = 1524172;
        //if (runtime.getCurrentUser().role == idRole || runtime.getCurrentUser().id == idUsrAJC) hideButons(context);
        if (runtime.getCurrentUser().role == idRole) hideButons(context);
    } catch (error) {
        log.error("Erro beforeLoad: ", error);
    }
}
function hideButons(context: EntryPoints.UserEvent.beforeLoadContext) {
    try {
        runtime.getCurrentScript().getParameter({ name: 'custscript_quod_id_item' }).toString().split(',')
        .forEach((element) => {
            context.form.getButton({ id: element.trim() }).isHidden = true;
        });
    } catch (error) {
        log.error("Erro hideButons: ", error);
    }
}

