/**
 * @NApiVersion 2.0
 * Autor : Alexandre J. Corrêa <alexandre.correa@quod.com.br>
 * @since 13/07/2022
 * @version 2.x
 */

import record from "N/record";
import log from "N/log";
import search from "N/search";
import * as rlEnum from "./quod_projuris_rl_enum";
import * as interfaces from "./quod_projuris_interfaces";

export function create_acs_bankaccountRecord(
    acc: interfaces.Campos_acs_bankaccountObj,
    vendorId?: any,
    accRet?: any
) {
    try {
        log.error({ title: "acc", details: acc })
        let create_acs_bankaccount = record.create({
            type: rlEnum.nsRecTypes.acsBankAcc,
            isDynamic: true,
        }),
            id_acs_bankaccount = 0;

        //create_acs_bankaccount.setValue(rlEnum.nsColunms.accCodigo, "" + acc.codigo);
        create_acs_bankaccount.setValue(rlEnum.nsColunms.accConta, "" + acc.conta);
        create_acs_bankaccount.setValue(rlEnum.nsColunms.accDigitoConta, "" + acc.digitoConta);
        create_acs_bankaccount.setValue(rlEnum.nsColunms.accAgencia, "" + acc.agencia);

        if (Number(accRet.idDet) > 0) {
            create_acs_bankaccount.setValue(rlEnum.nsColunms.accBanco, accRet.idDet)
        } else {
            let iddetalhe = _fetch_acs_bankDetId(acc.codigo);
            log.error('iddetalhe', iddetalhe)
            create_acs_bankaccount.setValue(rlEnum.nsColunms.accBanco, "" + iddetalhe);
        }
        if (isNaN(acc.banco)) create_acs_bankaccount.setValue(rlEnum.nsColunms.accBancoName, "" + acc.banco);
        if (+rlEnum.nsColunms.accDigitoBanco > 0) create_acs_bankaccount.setValue(rlEnum.nsColunms.accDigitoBanco, "" + acc.digitoBanco);
        if (vendorId > 0) create_acs_bankaccount.setValue(rlEnum.nsColunms.accFornecedor, "" + vendorId);

        log.error("create_acs_bankaccount antes de save", create_acs_bankaccount)
        id_acs_bankaccount = create_acs_bankaccount.save({ ignoreMandatoryFields: true });

        log.error("BANCO CRIADO COM SUCESSO", id_acs_bankaccount);
        return id_acs_bankaccount > 0 ? id_acs_bankaccount : rlEnum.retStatusObj.erroCreateAcc.cod;
    } catch (error) {
        log.error(rlEnum.retStatusObj.erroCreateAcc.msg, error)
        return rlEnum.retStatusObj.erroCreateAcc.cod;
    }
}

//Função responsável pela busca do banco
export function _fetch_acs_bankaccount(obj_acs_bankaccount: interfaces.Campos_acs_bankaccountObj, vendId: any) {
    try {
        let filtro = [
            [rlEnum.nsColunms.accVendor, search.Operator.ANYOF, "@NONE@", "" + vendId],
            "AND",
            [rlEnum.nsColunms.accAgencia, search.Operator.STARTSWITH, "" + obj_acs_bankaccount.agencia],
            "AND",
            [rlEnum.nsColunms.accConta, search.Operator.STARTSWITH, "" + obj_acs_bankaccount.conta],
            "AND",
            [rlEnum.nsColunms.accDigitoConta, search.Operator.STARTSWITH, obj_acs_bankaccount.digitoConta],
            "AND",
            /* [rlEnum.nsColunms.accBanco, search.Operator.ANYOF, "" + obj_acs_bankaccount.banco],
            "AND", */
            [rlEnum.nsColunms.accCodigo, search.Operator.STARTSWITH, obj_acs_bankaccount.codigo],
            "AND",
            buildFilterDigitoBanco(obj_acs_bankaccount.digitoBanco)
        ],
            accId: any = { id: 0, idVendor: 0 };
        log.error("filtro", filtro);
        search.create({
            type: rlEnum.nsRecTypes.acsBankAcc,
            filters: filtro,
            columns: [
                rlEnum.nsColunms.accFornecedor,
                search.createColumn({
                    name: "internalid",
                    join: "CUSTRECORD_ACS_BA_BANK_LS"
                })
            ]
        }).run().each(function (acc) {
            accId.id = +acc.id;
            accId.idDet = acc.getValue({ name: 'internalid' })
            accId.idVendor = acc.getValue({ name: rlEnum.nsColunms.accFornecedor })
            return true;
        });
        return accId;
    } catch (error) {
        log.error({ details: error, title: "Erro _fetch_acs_bankaccount" });
        return rlEnum.retStatusObj.erroFetchAcc.cod;
    }
}
export function _fetch_acs_bankDetId(cod: any) {
    try {
        let filtro = [
            [rlEnum.nsColunms.accBancoDet, search.Operator.STARTSWITH, "" + cod]
        ],
            idDet: any[] = [];
        log.error("filtro", filtro);
        search.create({
            type: rlEnum.nsRecTypes.acsBankDet,
            filters: filtro
        }).run().each(function (det) {
            idDet.push(+det.id)
            return true;
        });
        return idDet.length > 0 ? idDet[0] : rlEnum.retStatusObj.erroFetchAccDet;
    } catch (error) {
        log.error({ details: error, title: "Erro _fetch_acs_bankDetId" });
        return rlEnum.retStatusObj.erroFetchAccDet.cod;
    }
}

//Função responsável pela verificaão das informações bancárias
export function setContaBancaria(accountRet: any, idVendor: number) {
    try {
        if (accountRet.idVendor == idVendor || accountRet.idVendor > 0) return 0;

        let accRec = record.load({
            id: accountRet.id,
            type: rlEnum.nsRecTypes.acsBankAcc,
        }).setValue({
            fieldId: rlEnum.nsColunms.accFornecedor,
            value: idVendor
        }),
            idRet = accRec.save({ ignoreMandatoryFields: true });
        return idRet > 0 ? idRet : rlEnum.retStatusObj.erroSetAcc;

    } catch (error) {
        log.error(rlEnum.retStatusObj.erroSetAcc.msg, error);
        return rlEnum.retStatusObj.erroSetAcc.cod;
    }
}

function buildFilterDigitoBanco(digitoBanco: string | undefined) {
    return Number(digitoBanco) > 0 ? [rlEnum.nsColunms.accDigitoBanco, search.Operator.STARTSWITH, digitoBanco] : [rlEnum.nsColunms.accDigitoBanco, search.Operator.ISEMPTY, ""];
}
