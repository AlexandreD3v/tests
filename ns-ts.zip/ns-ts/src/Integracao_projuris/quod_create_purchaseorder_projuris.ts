/**
 * @NApiVersion 2.x
 * @NScriptType Restlet  
 * Review - Alexandre J. Corrêa <alexandre.correa@quod.com.br>
 * @since 13/07/2022
 * @version 2.0
 */

import * as vendorModule from "./quod_create_update_vendor.js";
import * as poModule from "./quod_create_update_purchaseorder.js";
import * as accModule from "./quod_create_update_acs_bankaccount.js";
import log from "N/log";
import * as interfaces from "./quod_projuris_interfaces";
import * as utils from "./utils.js";
import * as rlEnum from "./quod_projuris_rl_enum.js";

let objRespRestlet: interfaces.RespRestletObj = {};

//Realiza a consulta do pedido de venda a partir do externalid - deve executar a busca pelo purchaseOrder(pedido de compra/PO) (se presente) e retornar o status
export function get(context: any) {
    try {
        if (!context.externalid) return { erro: rlEnum.retStatusObj.erroGetPo };//Verifica se o ID externo foi informado como parâmetro

        let searchRes:any = poModule._fetchPoGet(context.externalid);

        if (searchRes.internalid) {//Se localizado, realiza a busca do status e retorna com suceso
            objRespRestlet.status = "Successo"
            objRespRestlet.statusPedido = searchRes.approvalstatus?.valueOf;
            objRespRestlet.statusPedidoId = searchRes.approvalstatus;
            objRespRestlet.codigo = 1
            objRespRestlet.message = "Pedido de Compra localizado com sucesso"
            objRespRestlet.internalid = searchRes.internalid
            objRespRestlet.externalid = context.externalid
        } else {//Se não, retorna o status de erro por não encontrar o registro
            objRespRestlet.status = "Error"
            objRespRestlet.statusPedido = "Não localizado"
            objRespRestlet.codigo = 4
            objRespRestlet.message = "Pedido de Compra não localizado"
            objRespRestlet.externalid = context.externalid
        }
        return objRespRestlet;

    } catch (error) {//Tratativa de exceções
        objRespRestlet.status = "Error"
        objRespRestlet.codigo = 3
        objRespRestlet.message = "" + error
        objRespRestlet.externalid = context.externalid
        return objRespRestlet;
    }
    return objRespRestlet;
}

//Realiza o cadastro do fornecedor (caso não exista) e do PO (caso não exista)
export function post(receivedPo: interfaces.receivedCtxPo) {
    try {
        log.error("receivedPo", receivedPo);
        if (!receivedPo.pedidoDeCompra || utils.validaArray(receivedPo.pedidoDeCompra)) return { pedido: receivedPo.pedidoDeCompra, erro: rlEnum.retStatusObj.erroJsonPedido };
        if (!receivedPo.pedidoDeCompra.fornecedor) return { pedido: receivedPo, vendor: receivedPo.pedidoDeCompra.fornecedor, erro: rlEnum.retStatusObj.erroJsonVendor };
        let checkPo: any = poModule._fetchPo(receivedPo.pedidoDeCompra.externalid),//checa a existencia do pedido de compra
            fetchVendorId: any, vendorId, accRetObj: any;

        log.error("checkPo", checkPo);
        if (checkPo < 0 || Number(checkPo.cod) < 0) return { msg: rlEnum.retStatusObj.erroFetchPo, externalId: receivedPo.pedidoDeCompra.externalid };
        if (checkPo > 0) return { msg: rlEnum.retStatusObj.pedidoExistente, externalId: receivedPo.pedidoDeCompra.externalid };

        fetchVendorId = vendorModule._fetchVendor(receivedPo.pedidoDeCompra.fornecedor.documento);//Busca pela existencia do fornecedor
        if (fetchVendorId < -1 || Number(fetchVendorId.cod) < -1) return { msg: rlEnum.retStatusObj.erroFetchVendor, obj: fetchVendorId, externalId: receivedPo.pedidoDeCompra.externalid }

        //Verifica a busca do fornecedor, caso ele não exista é criado
        vendorId = fetchVendorId > 0 ? fetchVendorId : vendorModule.createVendorRecord(receivedPo.pedidoDeCompra.fornecedor);
        if (vendorId < -1 || Number(vendorId.cod) < -1) return { msg: rlEnum.retStatusObj.erroCreateAcc, obj: fetchVendorId, externalId: receivedPo.pedidoDeCompra.externalid }

        if (receivedPo.pedidoDeCompra.fornecedor.contabancaria) {
            accRetObj = accModule._fetch_acs_bankaccount(receivedPo.pedidoDeCompra.fornecedor.contabancaria, vendorId);//Busca pela existencia do banco
            if (Number(accRetObj) <= 0) return { msg: rlEnum.retStatusObj.erroFetchAcc, obj: accRetObj, externalId: receivedPo.pedidoDeCompra.externalid };

            log.error("accRetObj", accRetObj);
            let vendorIsZero = Number(accRetObj.idVendor) == 0,
                vandorIsEquals = Number(accRetObj.idVendor == vendorId),
                checkAcc: any = accRetObj.id > 0 && (vendorIsZero || vandorIsEquals) ? accModule.setContaBancaria(accRetObj, vendorId) : accModule.create_acs_bankaccountRecord(receivedPo.pedidoDeCompra.fornecedor.contabancaria, vendorId, accRetObj);
            if (checkAcc < 0 || Number(checkAcc.cod < 0)) return { msg: rlEnum.retStatusObj.erroSetAcc, obj: checkAcc, externalId: receivedPo.pedidoDeCompra.externalid };
        }

        return poModule.createPoRecord(receivedPo.pedidoDeCompra, vendorId);

    } catch (error) {
        return utils.errorMessage(objRespRestlet, 3, error);
    }
}