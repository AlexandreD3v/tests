/**
 * @NApiVersion 2.x
 * @NScriptType Restlet  
 * Review - Alexandre J. Corrêa <alexandre.correa@quod.com.br>
 * @since 13/07/2022
 * @version 2.0
 */

import * as interfaces from "./quod_projuris_interfaces";
import log from "N/log";
import * as acc from "./quod_create_update_acs_bankaccount";

export function post(args: any) {
    try {
        log.error("args", args.acc);
        if (!args.acc.agencia || !args.acc.banco || !args.acc.conta) return { msg: "erro - faltam informações" };

        let accObj: interfaces.Campos_acs_bankaccountObj = {
            agencia: args.acc.agencia,
            banco: args.acc.banco,
            digitoBanco: "",
            conta: args.acc.conta,
            digitoConta: args.acc.digitoConta,
            codigo: args.acc.codigo,
        },
            idAcc:any = acc._fetch_acs_bankaccount(accObj,0),
            // idAcc : any = {id:+retfetch.id,error:retfetch.error ? retfetch.error : ""},
            //idAcc: any = retfetch,
            idAccN:any,
            respRet: interfaces.RespRestletObj = {};

        if (Number(idAcc) <= 0) return { msg: "Erro localização", idAcc };



        idAccN = idAcc.id > 0 ? acc.setContaBancaria(idAcc,1529031) : +acc.create_acs_bankaccountRecord(accObj,0, idAcc);
        log.error("id conta", idAcc);
        log.error("id contaN", idAccN);
        return { respRet, idAcc, idAccN };
    } catch (error) {
        log.error("Erro post", error);
        return error;
    }
}