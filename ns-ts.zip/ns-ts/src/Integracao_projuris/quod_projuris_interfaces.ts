/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

export interface poObject {
    externalid: number,
    fornecedor: CamposVendorObj,
    dataVencimento: string,
    descricao: number,
    departamento: number,
    tipoDeCompra: boolean,
    tipoDeDocumento: number,
    numeroProcesso: string,
    numeroRequisicao: string,
    itens: [{
        item: number,
        valor: number
    }],
    anexo: [{
        nome: string,
        conteudo: string
    }],
    numeroPastaProjuris: number
}
export interface receivedCtxPo {
    pedidoDeCompra: poObject
}

export interface Campos_acs_bankaccountObj {
    banco?: any,
    digitoBanco?: string,
    conta?: string,
    agencia?: string,
    digitoConta?: string,
    codigo?: string
}

export interface CamposVendorObj {
    nomeempresa: string,
    nomepessoa?:string
    documento: string,
    subsidiariaprincipal: string,
    contabancaria?: Campos_acs_bankaccountObj
}

export interface VendorReqObj {
    fornecedor: CamposVendorObj
}

export interface RespRestletObj { //Obj utilizado para salvar o status e resposta da requisição
    status?: string,
    statusPedido?: any,
    statusPedidoId?: any,
    codigo?: any,
    message?: any,
    internalid?: any,
    externalid?: any,
    entity?: any
};

export interface CamposPoObj {
    itens: string;
    anexo: string;
    externalid: string;
    fornecedor: string;
    data: string;
    dataVencimento: string;
    descricao: string;
    departamento: string;
    tipoDeCompra: string;
    tipoDeDocumento: string;
    numeroProcesso: string;
    numeroRequisicao: string;
    numeroPastaProjuris: string;
};

export interface CamposPoNSObj {
    externalid: string;
    entity: string;
    trandate: string;
    duedate: string;
    custbody_acs_justificativa_compra: string;
    department: string;
    custbody_acs_impostos: string;
    custbody_o2s_transaction_l_tip_doc_fis: string;
    anexo: string;
    item: string;
    numeroProcesso: string;
    numeroRequisicao: string;
    numeroPastaProjuris: string;
}
