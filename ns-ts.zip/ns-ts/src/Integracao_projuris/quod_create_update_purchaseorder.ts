/**
 * @NApiVersion 2.1
 * @author Rafael Oliveira <rafael.oliveira@quod.com.br>
 * @since 19/05/2021
 * @version 1.0 
 * Review - Alexandre J. Corrêa <alexandre.correa@quod.com.br>
 * @since 13/07/2022
 * @version 2.0
 */

import record from "N/record";
import log from "N/log";
import search from "N/search";
import * as interfaces from "./quod_projuris_interfaces";
import * as utils from "./utils"
import * as rlEnum from "./quod_projuris_rl_enum";

export function createPoRecord(
    poObj: interfaces.poObject,
    idVendor: number
) {
    try {
        let createPurchaseOrder = record.create({
            type: record.Type.PURCHASE_ORDER,
            isDynamic: true,
        }),
            dataVencimentoFormatada = utils.formatDate(poObj.dataVencimento),
            idPurchaseOrder;

        //log.error({ title: 'dateformat2', details: poObj.duedate })
        log.error({ title: 'dateformat21', details: dataVencimentoFormatada })
        createPurchaseOrder.setValue("customform", "179");
        createPurchaseOrder.setValue("employee", "1302472");
        createPurchaseOrder.setValue("externalid", poObj.externalid);
        createPurchaseOrder.setValue("entity", idVendor);
        createPurchaseOrder.setValue("duedate", dataVencimentoFormatada);
        createPurchaseOrder.setValue("custbody_acs_justificativa_compra", poObj.descricao);
        createPurchaseOrder.setValue("department", poObj.departamento);
        createPurchaseOrder.setValue("custbody_acs_impostos", poObj.tipoDeCompra);
        createPurchaseOrder.setValue("custbody_o2s_transaction_l_tip_doc_fis", poObj.tipoDeDocumento);
        createPurchaseOrder.setValue("custbody_quod_numero_processo_judicial", poObj.numeroProcesso);
        createPurchaseOrder.setValue("custbody_quod_numero_requisicao", poObj.numeroRequisicao);
        createPurchaseOrder.setValue("custbody_quod_id_tran_pasta_projuris", poObj.numeroPastaProjuris);

        for (var i = 0; i < poObj.itens.length; i++) {
            createPurchaseOrder.selectNewLine({ sublistId: 'item' });
            createPurchaseOrder.setCurrentSublistValue({ sublistId: 'item', fieldId: 'item', value: poObj.itens[i].item });
            createPurchaseOrder.setCurrentSublistValue({ sublistId: 'item', fieldId: 'rate', value: poObj.itens[i].valor });
            createPurchaseOrder.commitLine({ sublistId: 'item' });

        }

        idPurchaseOrder = createPurchaseOrder.save();


        let checkAddAtt: any = utils.adicionarAnexo(poObj.anexo, idPurchaseOrder);
        if (Number(checkAddAtt.cod) < 0) return { msg: rlEnum.retStatusObj.erroSetAcc, obj: checkAddAtt, externalId: poObj.externalid };


        return {
            status: rlEnum.retStatusObj.sucesso,
            externalid: poObj.externalid,
            internalid: idPurchaseOrder,
            message: "Pedido de Compra criado com sucesso"
        };

    } catch (error) {
        log.error("Erro ao tentar criar o pedido de compra", error);
        return {
            status: rlEnum.retStatusObj.erroCreatePo,
            externalid: poObj.externalid,
            internalid: poObj.externalid,
            erro: error
        };
    }
}

export function _fetchPo(idExt: any) {
    try {
        let srcPo, searchResultCount, poExists, idRet = 0;
        srcPo = search.create({//Variavel que salva a busca
            type: "purchaseorder",
            filters:
                [
                    ["type", search.Operator.ANYOF, "PurchOrd"],
                    "AND",
                    ["externalid", search.Operator.ANYOF, idExt],
                    "AND",
                    ["mainline", search.Operator.IS, "T"]
                ]
        });

        searchResultCount = srcPo.runPaged().count;//Variável que guarda o número de resultados        
        poExists = searchResultCount > 0;
        log.error("poExists", poExists);
        if (!poExists) return 0;

        log.error("searchResultCount", searchResultCount);
        srcPo.run().each(function (pedido) {
            idRet = +pedido.id;
            return true;
        })
        log.error("element idRet", idRet);
        return idRet > 0 ? idRet : rlEnum.retStatusObj.erroFetchPo;
    } catch (error) {
        log.error({ details: error, title: rlEnum.retStatusObj.erroFetchPo.msg });
        return rlEnum.retStatusObj.erroFetchPo.cod;
    }
}


export function _fetchPoGet(idExt: any) {
    try {
        let searchId = search.create({
            type: "purchaseorder",
            columns: ["internalid"],
            filters: [[
                ["type", "anyof", "PurchOrd"],
                "AND",
                ["externalid", "anyof", idExt],
                "AND",
                ["mainline", "is", "T"]
            ]]
        }).run().getRange({ start: 0, end: 1 });
        return search.lookupFields(
            {
                columns: ["internalid", "approvalstatus"],
                id: searchId[0].getValue({ name: "internalid" }),
                type: "purchaseorder"
            }
        );
    } catch (error) {
        log.error({ details: error, title: rlEnum.retStatusObj.erroGetFetchPo.msg });
        return rlEnum.retStatusObj.erroGetFetchPo.cod;
    }
}
