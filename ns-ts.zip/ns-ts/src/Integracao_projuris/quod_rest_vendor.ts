/**
 * @NApiVersion 2.x
 * @NScriptType Restlet  
 * Review - Alexandre J. Corrêa <alexandre.correa@quod.com.br>
 * @since 13/07/2022
 * @version 2.0
 */

import log from "N/log";
import * as vendorModule from "./quod_create_update_vendor";
import * as accModule from "./quod_create_update_acs_bankaccount";
import * as interfaces from "./quod_projuris_interfaces";

export function post(args: interfaces.VendorReqObj) {
    try {
        log.error("args", args);

        let checkVendor = vendorModule._fetchVendor(args.fornecedor.documento),
            objAcc: any = args.fornecedor.contabancaria,
            vendorId: any,
            accId: any;

        vendorId = Number(checkVendor) > 0 ? checkVendor : vendorModule.createVendorRecord(args.fornecedor);
        accId = objAcc != 0 ? accModule._fetch_acs_bankaccount(objAcc,vendorId) : 0;//Busca pela existencia do banco
        vendorId = vendorId == -1 ? vendorModule._fetchVendor(args.fornecedor.documento) : vendorId;

        if (objAcc) accId > 0 ? accModule.setContaBancaria(accId, +checkVendor) : accModule.create_acs_bankaccountRecord(objAcc, vendorId);
        if (+checkVendor > 0) return { msg: "O fornecedor já existe!", id: checkVendor };

        log.error("checkVendor", checkVendor);
        return { msg: checkVendor };
    } catch (error) {
        log.error("Erro post", error);
        return error;
    }
}