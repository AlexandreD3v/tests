/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

export enum retCod {
    sucesso = 1,
    erroDesconhecido = 0,
    erroJsonPedido = -1,
    erroJsonVendor = -2,
    erroFetchPo = -3,
    pedidoExistente = -4,
    erroFetchVendor = -5,
    erroCreateVendor = -6,
    erroFetchAcc = -7,
    erroSetAcc = -8,
    erroCreateAcc = -9,
    erroFetchAccDet = -10,
    erroAddAttachment = -11,
    erroCreatePo = -12,
    erroGetPo = -13,
    erroGetFetchPo = -14,
};

export enum retMsg {
    sucesso = "Sucesso",
    erroDesconhecido = "Erro desconhecido, entre em contato com o Administrador.",
    erroJsonPedido = "JSON do pedido não atende aos requisitos, por favor revisá-lo.",
    erroJsonVendor = "JSON do fornecedor não atende aos requisitos, por favor revisá-lo.",
    erroFetchPo = "Erro ao localizar o pedido de compra.",
    pedidoExistente = "O pedido de compra já existe!",
    erroFetchVendor = "Erro ao localizar fornecedor!",
    erroCreateVendor = "Erro ao criar o fornecedor.",
    erroFetchAcc = "Erro ao localizar a conta bancária para o fornecedor.",
    erroSetAcc = "Erro ao definir a conta bancária para o fornecedor.",
    erroCreateAcc = "Erro ao criar a conta bancária.",
    erroFetchAccDet = "Erro ao localizar o detalhe da conta bancária para o fornecedor.",
    erroAddAttachment = "Erro ao adicionar os anexos.",
    erroCreatePo = "Erro ao criar o pedido de compra.",
    erroGetPo = "Erro GET - id externo não foi enviado.",
    erroGetFetchPo = "Erro GET - pedido não localizado.",
}

export const retStatusObj = {
    sucesso: { cod: retCod.sucesso, msg: retMsg.sucesso },
    erroDesconhecido: { cod: retCod.erroDesconhecido, msg: retMsg.erroDesconhecido },
    erroJsonPedido: { cod: retCod.erroJsonPedido, msg: retMsg.erroJsonPedido },
    erroJsonVendor: { cod: retCod.erroJsonVendor, msg: retMsg.erroJsonVendor },
    erroFetchPo: { cod: retCod.erroFetchPo, msg: retMsg.erroFetchPo },
    pedidoExistente: { cod: retCod.pedidoExistente, msg: retMsg.pedidoExistente },
    erroFetchVendor: { cod: retCod.erroFetchVendor, msg: retMsg.erroFetchVendor },
    erroCreateVendor: { cod: retCod.erroCreateVendor, msg: retMsg.erroCreateVendor },
    erroFetchAcc: { cod: retCod.erroFetchAcc, msg: retMsg.erroFetchAcc },
    erroSetAcc: { cod: retCod.erroSetAcc, msg: retMsg.erroSetAcc },
    erroCreateAcc: { cod: retCod.erroCreateAcc, msg: retMsg.erroCreateAcc },
    erroFetchAccDet: { cod: retCod.erroFetchAccDet, msg: retMsg.erroFetchAccDet },
    erroAddAttachment: { cod: retCod.erroAddAttachment, msg: retMsg.erroAddAttachment },
    erroCreatePo: { cod: retCod.erroCreatePo, msg: retMsg.erroCreatePo },
    erroGetPo: { cod: retCod.erroGetPo, msg: retMsg.erroGetPo },
    erroGetFetchPo: { cod: retCod.erroGetFetchPo, msg: retMsg.erroGetFetchPo },
}

export const nsColunms = {
    accVendor : "custrecord_acs_ba_vendor_ls",
    accConta : "custrecord_acs_ba_number_ds",
    accAgencia : "custrecord_acs_ba_bankbranch_ds",
    accBanco : "custrecord_acs_ba_bank_ls",
    accBancoDet : "custrecord_acs_bd_bankid_ds",
    accBancoName : "name",
    accFornecedor : "custrecord_acs_ba_vendor_ls",
    //accCodigo : "customrecord_acs_bankdetails.custrecord_acs_bd_bankid_ds",
    accCodigo : "custrecord_acs_ba_bank_ls.custrecord_acs_bd_bankid_ds",
    accDigitoBanco : "custrecord_acs_ba_checkdigibankbranch_ds",
    accDigitoConta : "custrecord_acs_ba_checkdigitnumber_ds"
};

export const nsRecTypes = {
    acsBankAcc : "customrecord_acs_bankaccount",
    acsBankDet : "customrecord_acs_bankdetails",
}



