/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

import * as interfaces from "./quod_projuris_interfaces";
import log from "N/log";
import file from "N/file";
import record from "N/record";
import * as rlEnum from "./quod_projuris_rl_enum";
import format from "N/format";

export function errorMessage(objRet: interfaces.RespRestletObj, cod: number, e: any) {
    log.error(objRet.message, e)
    objRet = {
        status: "Error",
        codigo: cod,
        message: "" + e,
        internalid: -1
        //externalid: vendObj.documento
    }
    return objRet;
}

export function validaArray(obj: any) {
    let existsEmpty = false;
    Object.keys(obj).forEach(function (param) {
        if (!obj[param]) existsEmpty = true;
    });
    return existsEmpty;
};

export function adicionarAnexo(context: string | any[], idPedido: number) {
    try {

        for (var i = 0; i < context.length; i++) {

            var nomeArquivo = context[i].nome
            var conteudo = context[i].conteudo

            var arquivo = file.create({
                name: nomeArquivo,
                fileType: file.Type.PDF,
                contents: conteudo,
                description: `Arquivo de anexo Projuris, pedido de compra ${idPedido}`,
                folder: 46324,
                isOnline: true
            });

            var arquivoid = arquivo.save();
            record.attach({
                record: {
                    type: 'file',
                    id: arquivoid
                },
                to: {
                    type: record.Type.PURCHASE_ORDER,
                    id: idPedido
                }
            });

        }
        return true;

    } catch (error) {
        log.error('Erro adicionarAnexo',error);
        return rlEnum.retStatusObj.erroAddAttachment;
    }
}

export function formatDate(dataRecebida: any) {
    log.error({ title: 'date 1', details: dataRecebida });
    let dataFormatada = format.parse({
        value: dataRecebida,
        type: format.Type.DATE
    });
    log.error({ title: 'dateformat', details: dataFormatada })
    return dataFormatada;
}