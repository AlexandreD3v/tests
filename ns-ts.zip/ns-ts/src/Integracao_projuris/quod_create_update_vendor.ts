/**
 * @NApiVersion 2.0
 * @author Rafael Oliveira <rafael.oliveira@quod.com.br>
 * @since 19/05/2021
 * @version 1.2
 * Review - Alexandre J. Corrêa <alexandre.correa@quod.com.br>
 * @since 13/07/2022
 * @version 2.x
 */

import record from "N/record";
import log from "N/log";
import search from "N/search";
import * as interfaces from "./quod_projuris_interfaces";
import * as rlEnum from "./quod_projuris_rl_enum.js";

export function createVendorRecord(
    vendObj: interfaces.CamposVendorObj
) {
    try {
        let createVendor = record.create({
            type: record.Type.VENDOR,
            isDynamic: true
        }),
            tipoDocumento = "",
            idVendor;
        if (String(vendObj.documento).length > 14) {
            tipoDocumento = "custentity_psg_br_cnpj";
            createVendor.setValue("companyname", vendObj.nomeempresa);
        }
        else {
            let splitName = String(vendObj.nomepessoa ? vendObj.nomepessoa : vendObj.nomeempresa).split(" "),
                lastname = splitName.length > 3 ? String(splitName.slice(2, splitName.length)).replace(",", " ") : String(splitName[2]);
            tipoDocumento = "custentity_psg_br_cpf";
            createVendor.setValue({ fieldId: "companyname", value: String(vendObj.nomeempresa) });
            if (splitName.length > 2) {
                createVendor.setValue({ fieldId: "firstname", value: String(splitName[0]) });
                createVendor.setValue({ fieldId: "middlename", value: String(splitName[1]) });
                createVendor.setValue({ fieldId: "lastname", value: lastname });
            }
            else {
                createVendor.setValue("firstname", splitName[0]);
                createVendor.setValue("lastname", splitName[1]);
            }
        }
        createVendor.setValue(tipoDocumento, vendObj.documento);
        createVendor.setValue("isperson", tipoDocumento == "custentity_psg_br_cnpj" ? "F" : "T");
        createVendor.setValue("subsidiary", vendObj.subsidiariaprincipal);

        idVendor = createVendor.save();

        return idVendor > 0 ? idVendor : rlEnum.retStatusObj.erroCreateVendor;

    } catch (error) {
        log.error("Erro ao tentar criar o fornecedor", error)
        return rlEnum.retStatusObj.erroCreateVendor.cod;
    }
}

//Função responsável pela busca do fornecedor pelo CNPJ
export function _fetchVendor(documento: any) {
    try {
        let tipoDocumento = checkIdFieldDocumento(documento),
            srcVendor = search.create({//Variavel que salva a busca
                type: "vendor",
                filters:
                    [
                        [tipoDocumento, "contains", documento]
                    ]
            }),
            searchResultCount = srcVendor.runPaged().count,//Variável que guarda o número de resultados
            listaresult = searchResultCount > 0 ? +srcVendor.run().getRange({
                start: 0,
                end: searchResultCount
            })[0].id : 0;

        return listaresult > 0 ? listaresult : 0;
    } catch (error) {
        log.error({ details: error, title: "Erro _fetchVendor" });
        return rlEnum.retStatusObj.erroFetchVendor.cod;
    }
}

function checkIdFieldDocumento(documento: any) {
    return String(documento).length > 14 ? "custentity_psg_br_cnpj" : "custentity_psg_br_cpf"
};

