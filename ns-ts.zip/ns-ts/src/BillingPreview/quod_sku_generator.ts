/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType UserEventScript
 */

import { EntryPoints } from "N/types";
import log from "N/log";
import record from "N/record";

export function afterSubmit(ctx: EntryPoints.UserEvent.afterSubmitContext): void {
    try {
        let skuFieldValue = ctx.newRecord.getValue({ fieldId: 'custitem_quod_sku' }),
            recObj,
            generatedSkuValue,
            CTX_ISNOT_EDIT = ctx.type !== ctx.UserEventType.EDIT,
            CTX_ISNOT_CREATE = ctx.type !== ctx.UserEventType.CREATE,
            SKU_ISNOT_EMPTY = skuFieldValue !== '';

        if (CTX_ISNOT_CREATE && CTX_ISNOT_EDIT || SKU_ISNOT_EMPTY) return;

        recObj = record.load({ id: ctx.newRecord.id, type: ctx.newRecord.type });
        generatedSkuValue = ascii_to_hexa(ctx.newRecord.id);

        recObj.setValue({ fieldId: 'custitem_quod_sku', value: generatedSkuValue }).save();

    } catch (error) {
        log.error('Erro afterSubmit SKU Generator', error);
        throw error;
    }
}

function ascii_to_hexa(id_to_convert: number) {
    try {
        return pad(id_to_convert.toString(16).toUpperCase(), 6, "0");
    } catch (error) {
        log.error('ascii_to_hexa error', error);
        return "-1";
    }
}

function pad(str: string, size: number, filler?: string) {
    try {
        if (str.length > size) {
            log.error('Erro pad', 'SKU muito longo!')
            throw 'Erro - SKU muito longo!';
        }
        while (size > str.length) {
            str = filler + "" + str;
            size--;
        }
        return str;
    } catch (error) {
        log.error('pad error', error);
        return "-1";
    }
}