/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

import nSearch from "N/search";
import nLog from "N/log";
import * as nsFields from "./rl_nsFields";
import * as rlEnum from "./rl_enum";

export function searchConsumoByContractAndItem(idContrato: number, idItem: any) {
   try {
      let retConsumos = 0;
      nSearch.create({
         type: nsFields.fields.consumosRecId,
         filters:
            [
               [nsFields.fields.colConractUsageIdContrato, nSearch.Operator.ANYOF, idContrato],
               "AND",
               [nsFields.fields.colIdItemContratoConsumo, nSearch.Operator.ANYOF, idItem]
            ],
         columns:
            [
               nSearch.createColumn({
                  name: nsFields.fields.colItemUsage,
                  summary: nSearch.Summary.SUM,
                  label: "Quantidade Consumida"
               })
            ]
      }).run().each(function (consumos) {
         retConsumos = Number(consumos.getValue({ name: nsFields.fields.colItemUsage, summary: nSearch.Summary.SUM }));
         return true;
      });

      return retConsumos;
   } catch (error) {
      errorFunction('searchConsumoByContractAndItem Erro', error);
      return rlEnum.idStatusRetorno.erroConsumos;
   }
};

export function getItemIdBySku(skuItem: string) {
   try {
      return nSearch.create({
         type: nsFields.fields.itemRecId,
         filters:
            [
               [nsFields.fields.colItemSku, nSearch.Operator.STARTSWITH, skuItem]
            ]
      }).run().getRange({ start: 0, end: 1 })[0].id;
   } catch (error) {
      return errorFunction('getItemIdBySku', error);
   }
};

export function getTabelaComFaixaID(idContrato: number, idItem: any) {
   try {
      let ret = 0;
      nSearch.create({
         type: nsFields.fields.tabelaPrecoRecId,
         filters:
            [
               [nsFields.fields.colItemContratoTabela, nSearch.Operator.ANYOF, idContrato],
               "AND",
               [nsFields.fields.colItemContratoFaixa, nSearch.Operator.ANYOF, idItem]
            ],
         columns: [
            nSearch.createColumn({
               name: nsFields.fields.colInternallId,
               sort: nSearch.Sort.ASC,
               label: "ID"
            }),
            nSearch.createColumn({
               name: nsFields.fields.strIdFieldTipoFaixa,
               sort: nSearch.Sort.ASC,
               label: "Tipo"
            }),
         ]
      }).run().each(function (tabela: any) {
         let tipoIsFaixa = tabela.getValue({ name: nsFields.fields.strIdFieldTipoFaixa }) == 1,
            tabelaId = tabela.getValue({ name: nsFields.fields.colInternallId }),
            isFaixaAndHasTabela = tipoIsFaixa && tabelaId > 0;

         ret = isFaixaAndHasTabela ? tabelaId : rlEnum.idStatusRetorno.erroFullService;
         return true;
      });
      return ret > 0 ? ret : rlEnum.idStatusRetorno.erroTabela;
   } catch (error) {
      errorFunction('getTabelaComFaixaID', error);
      return rlEnum.idStatusRetorno.erroIndefinido;
   }
};

export function getValorUnitarioPorFaixa(tabelaId: any, qtde: any) {
   try {
      let ret = 0;
      nSearch.create({
         type: "customrecord_acs_pricerange_table",
         filters:
            [
               [nsFields.fields.colPriceTable, nSearch.Operator.ANYOF, tabelaId],
               "AND",
               [nsFields.fields.colFaixaQtdeMinima, nSearch.Operator.LESSTHANOREQUALTO, qtde],
               "AND",
               [nsFields.fields.colFaixaQtdeMax, nSearch.Operator.GREATERTHANOREQUALTO, qtde]
            ],
         columns:
            [
               nSearch.createColumn({ name: nsFields.fields.colFaixaPrecoUn, label: "Preço Unitário" })
            ]
      }).run().each(function (tab: any) {
         ret = +tab.getValue({ name: nsFields.fields.colFaixaPrecoUn });
         return true;
      });
      return ret > 0 ? ret : rlEnum.idStatusRetorno.erroFaixa;
   } catch (error) {
      return errorFunction("getValorUnitarioPorFaixa", error);
   }
};

export function getMetodoTarifacao(itemContratoId: any) {
   try {
      let ret = 0,
         sr = nSearch.create({
            type: nsFields.fields.itemContratoRecId,
            filters:
               [
                  [nsFields.fields.colItemContratoTarif, nSearch.Operator.ANYOF, itemContratoId]
               ],
            columns:
               [
                  nSearch.createColumn({
                     name: nsFields.fields.strIdCampoMetodoTarifacao,
                     join: nsFields.fields.custRecItemContratoId.toUpperCase(),
                     label: "Método de Tarifação"
                  })
               ]
         });

      if (sr.runPaged().count == 0) return 1;

      sr.run().each(function (itenContrato: any) {
         ret = itenContrato.getValue({ name: nsFields.fields.strIdCampoMetodoTarifacao });
         return true;
      });
      return ret > 0 ? ret : rlEnum.idStatusRetorno.erroTarifacao;
   } catch (error) {
      errorFunction('Erro getMetodoTarifacao', error);
      return rlEnum.idStatusRetorno.erroTarifacao;
   }
};

export function buildRetorno(item?: any, valorUn?: any, qtdeConsumoFaixa?: any, valorEstimadoItem?: any, statusEnviado?: { cod: number, msg: string }, err?: any) {
   try {
      if (statusEnviado?.cod == 0) nLog.error("Erro recebido", err);
      return {
         id: item.id,
         SKU: item.SKU,
         valorUn: valorUn,
         hit: item.hit,
         nohit: item.nohit,
         consumosFaturaveis: +qtdeConsumoFaixa,
         estimativa: valorEstimadoItem,
         status: statusEnviado
      }
   } catch (error) {
      return errorFunction('Erro buildRetorno', error);
   }
};

export function calculateQuantidadeConsumosByMetodoTarifacao(consumosItem: any, item: { id: any; hit: number; nohit: number; }, metodoTarif: number) {
   try {
      let ret;
      switch (metodoTarif) {
         case 3:
         case 2:
            ret = item.nohit + item.hit + consumosItem;
            break;
         case 1:
         default:
            ret = item.hit + consumosItem;
            break;
      }
      return ret > 0 ? ret : rlEnum.idStatusRetorno.erroCalculoConsumosTarifacao;
   } catch (error) {
      errorFunction('Erro calculateQuantidadeConsumosByMetodoTarifacao', error);
      return rlEnum.idStatusRetorno.erroCalculoConsumosTarifacao;
   }
};

export function getPricePreview(valorUn: any, consumosItem: any, item: { id: any; hit: number; nohit: number; }, metodoTarif: any) {
   try {
      let ret;
      switch (metodoTarif) {
         case 3:
            ret = (item.nohit + item.hit + consumosItem) * valorUn;
            break;
         case 2:
         case 1:
         default:
            ret = (item.hit + consumosItem) * valorUn;
            break;
      }
      return ret > 0 ? ret : rlEnum.idStatusRetorno.erroCalculoPrecoPreview;
   } catch (error) {
      errorFunction('Erro getPricePreview', error);
      return rlEnum.idStatusRetorno.erroCalculoPrecoPreview;
   }
};

export function errorFunction(origem: any, msg: any) {
   try {
      nLog.error(origem, msg);
      throw msg;
   } catch (error) {
      nLog.error("errorFunction", error);
      throw error;
   }
};

export function statusRetObj(status: any): { cod: number, msg: string } {
   let ret: any;
   switch (status) {
      case rlEnum.idStatusRetorno.erroFaixa:
         ret = { cod: rlEnum.idStatusRetorno.erroFaixa, msg: rlEnum.msgRetorno.erroFaixa };
         break;

      case rlEnum.idStatusRetorno.erroTabela:
         ret = { cod: rlEnum.idStatusRetorno.erroTabela, msg: rlEnum.msgRetorno.erroTabela };
         break;

      case rlEnum.idStatusRetorno.sucesso:
         ret = { cod: rlEnum.idStatusRetorno.sucesso, msg: rlEnum.msgRetorno.sucesso };
         break;

      case rlEnum.idStatusRetorno.erroFullService:
         ret = { cod: rlEnum.idStatusRetorno.erroFullService, msg: rlEnum.msgRetorno.erroFullService };
         break;

      case rlEnum.idStatusRetorno.erroIdContrato:
         ret = { cod: rlEnum.idStatusRetorno.erroIdContrato, msg: rlEnum.msgRetorno.erroIdContrato };
         break;

      case rlEnum.idStatusRetorno.erroListaItens:
         ret = { cod: rlEnum.idStatusRetorno.erroListaItens, msg: rlEnum.msgRetorno.erroListaItens };
         break;

      case rlEnum.idStatusRetorno.erroTarifacao:
         ret = { cod: rlEnum.idStatusRetorno.erroTarifacao, msg: rlEnum.msgRetorno.erroTarifacao };
         break;

      case rlEnum.idStatusRetorno.erroConsumos:
         ret = { cod: rlEnum.idStatusRetorno.erroConsumos, msg: rlEnum.msgRetorno.erroConsumos };
         break;

      case rlEnum.idStatusRetorno.erroCalculoConsumosTarifacao:
         ret = { cod: rlEnum.idStatusRetorno.erroCalculoConsumosTarifacao, msg: rlEnum.msgRetorno.erroCalculoConsumosTarifacao };
         break;

      case rlEnum.idStatusRetorno.erroCalculoPrecoPreview:
         ret = { cod: rlEnum.idStatusRetorno.erroCalculoPrecoPreview, msg: rlEnum.msgRetorno.erroCalculoPrecoPreview };
         break;

      default:
         ret = { cod: rlEnum.idStatusRetorno.erroIndefinido, msg: rlEnum.msgRetorno.erroIndefinido };
         break;
   }
   return ret;
};

export function checkForErrors(valueToCheck: any, itemArrToAdd: any, i: any) {
   try {
      if (+valueToCheck <= 0) {
         itemArrToAdd.push(buildRetorno(i, 0, 0, 0, statusRetObj(valueToCheck)));
         return true;
      }
      return false;
   } catch (error) {
      return buildRetorno(i, 0, 0, 0, statusRetObj(rlEnum.idStatusRetorno.erroIndefinido));
   }
};