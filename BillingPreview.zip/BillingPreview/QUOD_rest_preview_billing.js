/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType Restlet
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/log"], function (require, exports, log_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.put = exports.delete_ = exports.post = exports.get = void 0;
    log_1 = __importDefault(log_1);
    function get(getContext) {
        try {
            log_1.default.audit("get", getContext);
        }
        catch (error) {
            throw error;
        }
    }
    exports.get = get;
    function post(postContext) {
        try {
            log_1.default.audit("post", postContext);
        }
        catch (error) {
            throw error;
        }
    }
    exports.post = post;
    function delete_(deleteContext) {
        try {
            log_1.default.audit("delete_", deleteContext);
        }
        catch (error) {
            throw error;
        }
    }
    exports.delete_ = delete_;
    function put(putContext) {
        try {
            log_1.default.audit("put", putContext);
        }
        catch (error) {
            throw error;
        }
    }
    exports.put = put;
});
