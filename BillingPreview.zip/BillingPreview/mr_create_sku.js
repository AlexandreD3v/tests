/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 */

define(['N/search', 'N/log', 'N/record', "./quod_sku_functions"], function (search, record, record, functions) {

    function getInputData() {
        try {
            return search.create({
                type: "servicesaleitem",
                filters: [
                    ["type", "anyof", "Service"],
                    "AND",
                    ["subtype", "anyof", "Sale"]
                ]
            });
        } catch (e) {
            log.error('Erro GID', e)
        }
    }

    function map(mapCtx) {
        try {
            record.load({
                type: "servicesaleitem",
                id: mapCtx.key
            }).save(); 
        } catch (e) {
            log.error('Erro Map', e)
        }
    }

    function summarize(context) {
        log.audit(context.toString() + ' Usage Consumed', context.usage);
        log.audit(context.toString() + ' Concurrency Number ', context.concurrency);
        log.audit(context.toString() + ' Number of Yields', context.yields);
    }

    return {
        getInputData: getInputData,
        map: map,
        summarize: summarize
    };

});