/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType Restlet
 * Autor: Alexandre J. Corrêa
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
define(["require", "exports", "./rl_functions", "./rl_enum"], function (require, exports, rlFunctions, rlEnum) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.post = void 0;
    rlFunctions = __importStar(rlFunctions);
    rlEnum = __importStar(rlEnum);
    function post(postCtx) {
        try {
            if (postCtx.id < 1)
                return rlFunctions.buildRetorno(postCtx, 0, 0, 0, rlFunctions.statusRetObj(rlEnum.idStatusRetorno.erroIdContrato));
            if (postCtx.items.length < 1)
                return rlFunctions.buildRetorno(postCtx, 0, 0, 0, rlFunctions.statusRetObj(rlEnum.idStatusRetorno.erroListaItens));
            var idContrato_1 = postCtx.id, itensListPreview = postCtx.items, itensRet_1 = [], valorTotalPreview_1 = 0;
            itensListPreview.forEach(function (item) {
                var tabela, metodoTarif, consumosItem, qtdeConsumoFaixa, valorUn, valorEstimadoItem;
                tabela = rlFunctions.getTabelaComFaixaID(idContrato_1, item.id);
                if (rlFunctions.checkForErrors(tabela, itensRet_1, item))
                    return;
                metodoTarif = rlFunctions.getMetodoTarifacao(item.id);
                if (rlFunctions.checkForErrors(metodoTarif, itensRet_1, item))
                    return;
                consumosItem = rlFunctions.searchConsumoByContractAndItem(idContrato_1, item.id);
                if (consumosItem < 0) {
                    if (rlFunctions.checkForErrors(consumosItem, itensRet_1, item))
                        return;
                }
                qtdeConsumoFaixa = rlFunctions.calculateQuantidadeConsumosByMetodoTarifacao(consumosItem, item, Number(metodoTarif));
                if (rlFunctions.checkForErrors(qtdeConsumoFaixa, itensRet_1, item))
                    return;
                valorUn = rlFunctions.getValorUnitarioPorFaixa(tabela, qtdeConsumoFaixa);
                if (rlFunctions.checkForErrors(valorUn, itensRet_1, item))
                    return;
                valorEstimadoItem = rlFunctions.getPricePreview(valorUn, consumosItem, item, metodoTarif);
                if (rlFunctions.checkForErrors(valorEstimadoItem, itensRet_1, item))
                    return;
                valorTotalPreview_1 = valorTotalPreview_1 + Number(valorEstimadoItem);
                itensRet_1.push(rlFunctions.buildRetorno(item, valorUn, qtdeConsumoFaixa, valorEstimadoItem, rlFunctions.statusRetObj(rlEnum.idStatusRetorno.sucesso)));
            });
            return { id: postCtx.id, valorTotal: valorTotalPreview_1, itens: itensRet_1 };
        }
        catch (error) {
            return rlFunctions.buildRetorno(postCtx, 0, 0, 0, rlFunctions.statusRetObj(rlEnum.idStatusRetorno.erroIndefinido), error);
        }
    }
    exports.post = post;
    ;
});
