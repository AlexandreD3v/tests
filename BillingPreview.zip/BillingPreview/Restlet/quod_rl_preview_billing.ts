/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType Restlet
 * Autor: Alexandre J. Corrêa
 */

import * as rlFunctions from "./rl_functions";
import * as rlEnum from "./rl_enum";

export function post(postCtx: any): any {
    try {
        if (postCtx.id < 1) return rlFunctions.buildRetorno(postCtx, 0, 0, 0, rlFunctions.statusRetObj(rlEnum.idStatusRetorno.erroIdContrato));
        if (postCtx.items.length < 1) return rlFunctions.buildRetorno(postCtx, 0, 0, 0, rlFunctions.statusRetObj(rlEnum.idStatusRetorno.erroListaItens));
        let idContrato = postCtx.id,
            itensListPreview: [] = postCtx.items,
            itensRet: any = [],
            valorTotalPreview = 0;

        itensListPreview.forEach(function (item: { id: any, hit: number, nohit: number, SKU?: any }) {
            let tabela, metodoTarif, consumosItem, qtdeConsumoFaixa, valorUn, valorEstimadoItem;

            tabela = rlFunctions.getTabelaComFaixaID(idContrato, item.id);
            if (rlFunctions.checkForErrors(tabela, itensRet, item)) return;
            
            metodoTarif = rlFunctions.getMetodoTarifacao(item.id);
            if (rlFunctions.checkForErrors(metodoTarif, itensRet, item)) return;
            
            consumosItem = rlFunctions.searchConsumoByContractAndItem(idContrato, item.id);
            if(consumosItem < 0){
                if (rlFunctions.checkForErrors(consumosItem, itensRet, item)) return; 
            }
            
            qtdeConsumoFaixa = rlFunctions.calculateQuantidadeConsumosByMetodoTarifacao(consumosItem, item, Number(metodoTarif));
            if (rlFunctions.checkForErrors(qtdeConsumoFaixa, itensRet, item)) return;

            valorUn = rlFunctions.getValorUnitarioPorFaixa(tabela, qtdeConsumoFaixa);
            if (rlFunctions.checkForErrors(valorUn, itensRet, item)) return;
            
            valorEstimadoItem = rlFunctions.getPricePreview(valorUn, consumosItem, item, metodoTarif);
            if (rlFunctions.checkForErrors(valorEstimadoItem, itensRet, item)) return;
            
            valorTotalPreview = valorTotalPreview + Number(valorEstimadoItem);

            itensRet.push(rlFunctions.buildRetorno(item, valorUn, qtdeConsumoFaixa, valorEstimadoItem, rlFunctions.statusRetObj(rlEnum.idStatusRetorno.sucesso)));

        });
        return { id: postCtx.id, valorTotal: valorTotalPreview, itens: itensRet };
    } catch (error) {
        return rlFunctions.buildRetorno(postCtx, 0, 0, 0, rlFunctions.statusRetObj(rlEnum.idStatusRetorno.erroIndefinido), error);
    }
};

