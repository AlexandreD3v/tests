/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

export enum msgRetorno {
    erroTabela = "Estimativa não realizada - tabela de preços não foi localizada.",
    erroFullService = "Estimativa não realizada - item com tabela do tipo Full Service.",
    erroFaixa = "Estimativa não realizada - faixa de consumo não localizada.",
    erroIdContrato = "Estimativa não realizada - falta o id do contrato.",
    erroListaItens = "Estimativa não realizada - falta a lista de itens a serem estimados.",
    erroTarifacao = "Estimativa não realizada - problema ao localizar a tarifação.",
    erroConsumos = "Estimativa não realizada - problema ao localizar consumos do contrato.",
    erroCalculoConsumosTarifacao = "Estimativa não realizada - problema ao localizar consumos por método de tarifação.",
    erroCalculoPrecoPreview = "Estimativa não realizada - problema ao calcular consumos por método de tarifação.",
    erroIndefinido = "Erro desconhecido - entre em contato com o administrador",
    sucesso = "Sucesso",
};

export enum idStatusRetorno {
    erroTabela = -1,
    erroFullService = -2,
    erroFaixa = -3,
    erroIdContrato = -4,
    erroListaItens = -5,
    erroTarifacao = -6,
    erroConsumos = -7,
    erroCalculoConsumosTarifacao = -8,
    erroCalculoPrecoPreview = -9,
    erroIndefinido = 0,
    sucesso = 1
};

