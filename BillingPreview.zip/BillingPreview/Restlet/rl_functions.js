/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
define(["require", "exports", "N/search", "N/log", "./rl_nsFields", "./rl_enum"], function (require, exports, search_1, log_1, nsFields, rlEnum) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.checkForErrors = exports.statusRetObj = exports.errorFunction = exports.getPricePreview = exports.calculateQuantidadeConsumosByMetodoTarifacao = exports.buildRetorno = exports.getMetodoTarifacao = exports.getValorUnitarioPorFaixa = exports.getTabelaComFaixaID = exports.getItemIdBySku = exports.searchConsumoByContractAndItem = void 0;
    search_1 = __importDefault(search_1);
    log_1 = __importDefault(log_1);
    nsFields = __importStar(nsFields);
    rlEnum = __importStar(rlEnum);
    function searchConsumoByContractAndItem(idContrato, idItem) {
        try {
            var retConsumos_1 = 0;
            search_1.default.create({
                type: nsFields.fields.consumosRecId,
                filters: [
                    [nsFields.fields.colConractUsageIdContrato, search_1.default.Operator.ANYOF, idContrato],
                    "AND",
                    [nsFields.fields.colIdItemContratoConsumo, search_1.default.Operator.ANYOF, idItem]
                ],
                columns: [
                    search_1.default.createColumn({
                        name: nsFields.fields.colItemUsage,
                        summary: search_1.default.Summary.SUM,
                        label: "Quantidade Consumida"
                    })
                ]
            }).run().each(function (consumos) {
                retConsumos_1 = Number(consumos.getValue({ name: nsFields.fields.colItemUsage, summary: search_1.default.Summary.SUM }));
                return true;
            });
            return retConsumos_1;
        }
        catch (error) {
            errorFunction('searchConsumoByContractAndItem Erro', error);
            return rlEnum.idStatusRetorno.erroConsumos;
        }
    }
    exports.searchConsumoByContractAndItem = searchConsumoByContractAndItem;
    ;
    function getItemIdBySku(skuItem) {
        try {
            return search_1.default.create({
                type: nsFields.fields.itemRecId,
                filters: [
                    [nsFields.fields.colItemSku, search_1.default.Operator.STARTSWITH, skuItem]
                ]
            }).run().getRange({ start: 0, end: 1 })[0].id;
        }
        catch (error) {
            return errorFunction('getItemIdBySku', error);
        }
    }
    exports.getItemIdBySku = getItemIdBySku;
    ;
    function getTabelaComFaixaID(idContrato, idItem) {
        try {
            var ret_1 = 0;
            search_1.default.create({
                type: nsFields.fields.tabelaPrecoRecId,
                filters: [
                    [nsFields.fields.colItemContratoTabela, search_1.default.Operator.ANYOF, idContrato],
                    "AND",
                    [nsFields.fields.colItemContratoFaixa, search_1.default.Operator.ANYOF, idItem]
                ],
                columns: [
                    search_1.default.createColumn({
                        name: nsFields.fields.colInternallId,
                        sort: search_1.default.Sort.ASC,
                        label: "ID"
                    }),
                    search_1.default.createColumn({
                        name: nsFields.fields.strIdFieldTipoFaixa,
                        sort: search_1.default.Sort.ASC,
                        label: "Tipo"
                    }),
                ]
            }).run().each(function (tabela) {
                var tipoIsFaixa = tabela.getValue({ name: nsFields.fields.strIdFieldTipoFaixa }) == 1, tabelaId = tabela.getValue({ name: nsFields.fields.colInternallId }), isFaixaAndHasTabela = tipoIsFaixa && tabelaId > 0;
                ret_1 = isFaixaAndHasTabela ? tabelaId : rlEnum.idStatusRetorno.erroFullService;
                return true;
            });
            return ret_1 > 0 ? ret_1 : rlEnum.idStatusRetorno.erroTabela;
        }
        catch (error) {
            errorFunction('getTabelaComFaixaID', error);
            return rlEnum.idStatusRetorno.erroIndefinido;
        }
    }
    exports.getTabelaComFaixaID = getTabelaComFaixaID;
    ;
    function getValorUnitarioPorFaixa(tabelaId, qtde) {
        try {
            var ret_2 = 0;
            search_1.default.create({
                type: "customrecord_acs_pricerange_table",
                filters: [
                    [nsFields.fields.colPriceTable, search_1.default.Operator.ANYOF, tabelaId],
                    "AND",
                    [nsFields.fields.colFaixaQtdeMinima, search_1.default.Operator.LESSTHANOREQUALTO, qtde],
                    "AND",
                    [nsFields.fields.colFaixaQtdeMax, search_1.default.Operator.GREATERTHANOREQUALTO, qtde]
                ],
                columns: [
                    search_1.default.createColumn({ name: nsFields.fields.colFaixaPrecoUn, label: "Preço Unitário" })
                ]
            }).run().each(function (tab) {
                ret_2 = +tab.getValue({ name: nsFields.fields.colFaixaPrecoUn });
                return true;
            });
            return ret_2 > 0 ? ret_2 : rlEnum.idStatusRetorno.erroFaixa;
        }
        catch (error) {
            return errorFunction("getValorUnitarioPorFaixa", error);
        }
    }
    exports.getValorUnitarioPorFaixa = getValorUnitarioPorFaixa;
    ;
    function getMetodoTarifacao(itemContratoId) {
        try {
            var ret_3 = 0, sr = search_1.default.create({
                type: nsFields.fields.itemContratoRecId,
                filters: [
                    [nsFields.fields.colItemContratoTarif, search_1.default.Operator.ANYOF, itemContratoId]
                ],
                columns: [
                    search_1.default.createColumn({
                        name: nsFields.fields.strIdCampoMetodoTarifacao,
                        join: nsFields.fields.custRecItemContratoId.toUpperCase(),
                        label: "Método de Tarifação"
                    })
                ]
            });
            if (sr.runPaged().count == 0)
                return 1;
            sr.run().each(function (itenContrato) {
                ret_3 = itenContrato.getValue({ name: nsFields.fields.strIdCampoMetodoTarifacao });
                return true;
            });
            return ret_3 > 0 ? ret_3 : rlEnum.idStatusRetorno.erroTarifacao;
        }
        catch (error) {
            errorFunction('Erro getMetodoTarifacao', error);
            return rlEnum.idStatusRetorno.erroTarifacao;
        }
    }
    exports.getMetodoTarifacao = getMetodoTarifacao;
    ;
    function buildRetorno(item, valorUn, qtdeConsumoFaixa, valorEstimadoItem, statusEnviado, err) {
        try {
            if ((statusEnviado === null || statusEnviado === void 0 ? void 0 : statusEnviado.cod) == 0)
                log_1.default.error("Erro recebido", err);
            return {
                id: item.id,
                SKU: item.SKU,
                valorUn: valorUn,
                hit: item.hit,
                nohit: item.nohit,
                consumosFaturaveis: +qtdeConsumoFaixa,
                estimativa: valorEstimadoItem,
                status: statusEnviado
            };
        }
        catch (error) {
            return errorFunction('Erro buildRetorno', error);
        }
    }
    exports.buildRetorno = buildRetorno;
    ;
    function calculateQuantidadeConsumosByMetodoTarifacao(consumosItem, item, metodoTarif) {
        try {
            var ret = void 0;
            switch (metodoTarif) {
                case 3:
                case 2:
                    ret = item.nohit + item.hit + consumosItem;
                    break;
                case 1:
                default:
                    ret = item.hit + consumosItem;
                    break;
            }
            return ret > 0 ? ret : rlEnum.idStatusRetorno.erroCalculoConsumosTarifacao;
        }
        catch (error) {
            errorFunction('Erro calculateQuantidadeConsumosByMetodoTarifacao', error);
            return rlEnum.idStatusRetorno.erroCalculoConsumosTarifacao;
        }
    }
    exports.calculateQuantidadeConsumosByMetodoTarifacao = calculateQuantidadeConsumosByMetodoTarifacao;
    ;
    function getPricePreview(valorUn, consumosItem, item, metodoTarif) {
        try {
            var ret = void 0;
            switch (metodoTarif) {
                case 3:
                    ret = (item.nohit + item.hit + consumosItem) * valorUn;
                    break;
                case 2:
                case 1:
                default:
                    ret = (item.hit + consumosItem) * valorUn;
                    break;
            }
            return ret > 0 ? ret : rlEnum.idStatusRetorno.erroCalculoPrecoPreview;
        }
        catch (error) {
            errorFunction('Erro getPricePreview', error);
            return rlEnum.idStatusRetorno.erroCalculoPrecoPreview;
        }
    }
    exports.getPricePreview = getPricePreview;
    ;
    function errorFunction(origem, msg) {
        try {
            log_1.default.error(origem, msg);
            throw msg;
        }
        catch (error) {
            log_1.default.error("errorFunction", error);
            throw error;
        }
    }
    exports.errorFunction = errorFunction;
    ;
    function statusRetObj(status) {
        var ret;
        switch (status) {
            case rlEnum.idStatusRetorno.erroFaixa:
                ret = { cod: rlEnum.idStatusRetorno.erroFaixa, msg: rlEnum.msgRetorno.erroFaixa };
                break;
            case rlEnum.idStatusRetorno.erroTabela:
                ret = { cod: rlEnum.idStatusRetorno.erroTabela, msg: rlEnum.msgRetorno.erroTabela };
                break;
            case rlEnum.idStatusRetorno.sucesso:
                ret = { cod: rlEnum.idStatusRetorno.sucesso, msg: rlEnum.msgRetorno.sucesso };
                break;
            case rlEnum.idStatusRetorno.erroFullService:
                ret = { cod: rlEnum.idStatusRetorno.erroFullService, msg: rlEnum.msgRetorno.erroFullService };
                break;
            case rlEnum.idStatusRetorno.erroIdContrato:
                ret = { cod: rlEnum.idStatusRetorno.erroIdContrato, msg: rlEnum.msgRetorno.erroIdContrato };
                break;
            case rlEnum.idStatusRetorno.erroListaItens:
                ret = { cod: rlEnum.idStatusRetorno.erroListaItens, msg: rlEnum.msgRetorno.erroListaItens };
                break;
            case rlEnum.idStatusRetorno.erroTarifacao:
                ret = { cod: rlEnum.idStatusRetorno.erroTarifacao, msg: rlEnum.msgRetorno.erroTarifacao };
                break;
            case rlEnum.idStatusRetorno.erroConsumos:
                ret = { cod: rlEnum.idStatusRetorno.erroConsumos, msg: rlEnum.msgRetorno.erroConsumos };
                break;
            case rlEnum.idStatusRetorno.erroCalculoConsumosTarifacao:
                ret = { cod: rlEnum.idStatusRetorno.erroCalculoConsumosTarifacao, msg: rlEnum.msgRetorno.erroCalculoConsumosTarifacao };
                break;
            case rlEnum.idStatusRetorno.erroCalculoPrecoPreview:
                ret = { cod: rlEnum.idStatusRetorno.erroCalculoPrecoPreview, msg: rlEnum.msgRetorno.erroCalculoPrecoPreview };
                break;
            default:
                ret = { cod: rlEnum.idStatusRetorno.erroIndefinido, msg: rlEnum.msgRetorno.erroIndefinido };
                break;
        }
        return ret;
    }
    exports.statusRetObj = statusRetObj;
    ;
    function checkForErrors(valueToCheck, itemArrToAdd, i) {
        try {
            if (+valueToCheck <= 0) {
                itemArrToAdd.push(buildRetorno(i, 0, 0, 0, statusRetObj(valueToCheck)));
                return true;
            }
            return false;
        }
        catch (error) {
            return buildRetorno(i, 0, 0, 0, statusRetObj(rlEnum.idStatusRetorno.erroIndefinido));
        }
    }
    exports.checkForErrors = checkForErrors;
    ;
});
