/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.fields = void 0;
    exports.fields = {
        consumosRecId: "customrecord_acs_contract_usage",
        tabelaPrecoRecId: "customrecord_acs_price_table",
        colConractUsageIdContrato: "custrecord_acs_contrusage_contract_ls",
        custRecItemContratoId: "custrecord_acs_itemcontr_list_ls",
        colIdItemContratoConsumo: "custrecord_acs_contrusage_item_ls.custrecord_acs_itemcontr_list_ls",
        colItemUsage: "custrecord_acs_contrusage_qnt_nu",
        strIdFieldTipoFaixa: "custrecord_acs_pricetable_prec_ls",
        colItemContratoTabela: "custrecord_acs_pricetable_contract_ls",
        colItemContratoFaixa: "custrecord_acs_pricetable_itemcont_ls.custrecord_acs_itemcontr_list_ls",
        colInternallId: "internalid",
        colPriceTable: "custrecord_acs_pricetable_ls",
        colFaixaQtdeMinima: "custrecord_acs_priceqntmin_nu",
        colFaixaQtdeMax: "custrecord_acs_priceqnt_max_nu",
        colFaixaPrecoUn: "custrecord_acs_priceunt_cu",
        strIdCampoMetodoTarifacao: "custitem_quod_metodo_de_tarifacao",
        itemContratoRecId: "customrecord_acs_quodcontract_item",
        colItemContratoTarif: "custrecord_acs_itemcontr_ls",
        itemRecId: "item",
        colItemSku: "custitem_quod_sku"
    };
});
