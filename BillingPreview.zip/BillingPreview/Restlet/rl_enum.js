/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.idStatusRetorno = exports.msgRetorno = void 0;
    var msgRetorno;
    (function (msgRetorno) {
        msgRetorno["erroTabela"] = "Estimativa n\u00E3o realizada - tabela de pre\u00E7os n\u00E3o foi localizada.";
        msgRetorno["erroFullService"] = "Estimativa n\u00E3o realizada - item com tabela do tipo Full Service.";
        msgRetorno["erroFaixa"] = "Estimativa n\u00E3o realizada - faixa de consumo n\u00E3o localizada.";
        msgRetorno["erroIdContrato"] = "Estimativa n\u00E3o realizada - falta o id do contrato.";
        msgRetorno["erroListaItens"] = "Estimativa n\u00E3o realizada - falta a lista de itens a serem estimados.";
        msgRetorno["erroTarifacao"] = "Estimativa n\u00E3o realizada - problema ao localizar a tarifa\u00E7\u00E3o.";
        msgRetorno["erroConsumos"] = "Estimativa n\u00E3o realizada - problema ao localizar consumos do contrato.";
        msgRetorno["erroCalculoConsumosTarifacao"] = "Estimativa n\u00E3o realizada - problema ao localizar consumos por m\u00E9todo de tarifa\u00E7\u00E3o.";
        msgRetorno["erroCalculoPrecoPreview"] = "Estimativa n\u00E3o realizada - problema ao calcular consumos por m\u00E9todo de tarifa\u00E7\u00E3o.";
        msgRetorno["erroIndefinido"] = "Erro desconhecido - entre em contato com o administrador";
        msgRetorno["sucesso"] = "Sucesso";
    })(msgRetorno = exports.msgRetorno || (exports.msgRetorno = {}));
    ;
    var idStatusRetorno;
    (function (idStatusRetorno) {
        idStatusRetorno[idStatusRetorno["erroTabela"] = -1] = "erroTabela";
        idStatusRetorno[idStatusRetorno["erroFullService"] = -2] = "erroFullService";
        idStatusRetorno[idStatusRetorno["erroFaixa"] = -3] = "erroFaixa";
        idStatusRetorno[idStatusRetorno["erroIdContrato"] = -4] = "erroIdContrato";
        idStatusRetorno[idStatusRetorno["erroListaItens"] = -5] = "erroListaItens";
        idStatusRetorno[idStatusRetorno["erroTarifacao"] = -6] = "erroTarifacao";
        idStatusRetorno[idStatusRetorno["erroConsumos"] = -7] = "erroConsumos";
        idStatusRetorno[idStatusRetorno["erroCalculoConsumosTarifacao"] = -8] = "erroCalculoConsumosTarifacao";
        idStatusRetorno[idStatusRetorno["erroCalculoPrecoPreview"] = -9] = "erroCalculoPrecoPreview";
        idStatusRetorno[idStatusRetorno["erroIndefinido"] = 0] = "erroIndefinido";
        idStatusRetorno[idStatusRetorno["sucesso"] = 1] = "sucesso";
    })(idStatusRetorno = exports.idStatusRetorno || (exports.idStatusRetorno = {}));
    ;
});
