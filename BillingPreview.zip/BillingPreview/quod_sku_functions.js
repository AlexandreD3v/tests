/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 */

define(["N/log"], function (log) {
    
    function ascii_to_hexa(id_to_convert) {
        try {
            return pad(id_to_convert.toString(16).toUpperCase(), 6, "0");
        }
        catch (error) {
            log.error('ascii_to_hexa error', error);
            throw error;
        }
    }
    function pad(str, size, filler) {
        try {
            if (str.length > size) {
                log.error('Erro pad', 'SKU muito longo!');
                throw 'Erro - SKU muito longo!';
            }
            while (size > str.length) {
                str = filler + "" + str;
                size--;
            }
            return str;
        }
        catch (error) {
            log.error('pad error', error);
            throw error;
        }
    }
    return{
        ascii_to_hexa:ascii_to_hexa,
        pad:pad
    }
});
