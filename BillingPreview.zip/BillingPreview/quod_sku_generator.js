/**
 * @copyright © 2022, Oracle and/or its affiliates. All rights reserved.
 *
 * @NApiVersion 2.x
 * @NModuleScope Public
 * @NScriptType UserEventScript
 */

define(["N/runtime", "N/log", "N/record", "./quod_sku_functions", "N/ui/serverWidget"], function (runtime, log, record, functions) {
    function afterSubmit(ctx) {
        try {
            if (runtime.accountId == "4860171_SB1" && (ctx.type !== ctx.UserEventType.EDIT && ctx.type !== ctx.UserEventType.CREATE || ctx.newRecord.getValue({ fieldId: 'custitem_quod_sku' }) !== '')) return;
            record.load({ id: ctx.newRecord.id, type: ctx.newRecord.type })
                .setValue({ fieldId: 'externalid', value: functions.ascii_to_hexa(ctx.newRecord.id) })
                .save();
        }
        catch (error) {
            log.error('Erro afterSubmit SKU Generator', error);
            throw error;
        }
    }
    return {
        afterSubmit: afterSubmit
    }
});
